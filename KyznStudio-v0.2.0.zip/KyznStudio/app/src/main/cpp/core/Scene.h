// KyznStudio - model scene: entity, hierarki, serialisasi, animasi
#pragma once
#include <string>
#include <vector>
#include "Json.h"
#include "Math.h"

namespace kyzn {

enum class Kind { Block, Sphere, Cylinder, Cone, Floor, Spawn, Tree, House, Rock, Pole, Crate, Barrel, Tank, Container, Group, Script, Sound, Count };
enum class MatType { Plastic, Metal, Wood, Grass, Concrete, Neon, Count };
enum class AnimType { None, Spin, Bob, Patrol, Count };

struct KindInfo { const char* name; Vec3 size; Vec3 color; bool geometry; bool solid; };
struct MatInfo { const char* name; float rough, metal; Vec3 color; };
const KindInfo& kindInfo(Kind k);
const MatInfo& matInfo(MatType m);
const char* animName(AnimType a);
bool kindFromName(const std::string& n, Kind& out);
bool matFromName(const std::string& n, MatType& out);
bool animFromName(const std::string& n, AnimType& out);

struct Entity {
    int id = 0;
    std::string name;
    Kind kind = Kind::Block;
    int parent = 0;
    Vec3 pos, rot, scale{1, 1, 1};              // lokal; scale = ukuran (size) untuk part
    Vec3 color{.64f, .64f, .65f};
    MatType mat = MatType::Plastic;
    int tex = 0;                                 // 0 = tanpa texture, 1.. = texture prosedural
    float transparency = 0, reflectance = 0;
    bool visible = true, castShadow = true, receiveShadow = true;
    bool collider = true, rigidbody = false, kinematic = false, useGravity = true;
    float mass = 1;
    AnimType anim = AnimType::None;
    float animSpeed = 1, animAmount = 2;
    std::string tag = "Untagged", layer = "Default";
    // Script / Sound
    std::string code, clip = "explosion";
    bool enabled = true, playOnStart = false;
    int attached = 0;                            // id entity tempat script menempel (0 = global)
    // runtime (tidak diserialisasi)
    Vec3 vel, base;
    bool dead = false;
};

struct Lighting {
    float brightness = 1, clockTime = 14, fogEnd = 260;
    Vec3 ambient{.54f, .59f, .68f};
    bool shadows = true;
};

Json entityToJson(const Entity& e);
bool entityFromJson(const Json& j, Entity& e, std::string* err = nullptr);

class Scene {
public:
    std::vector<Entity> entities;
    Lighting lighting;
    int nextId = 1;

    int create(Kind k, const std::string& name = "");
    Entity* find(int id);
    const Entity* find(int id) const;
    Entity* findByName(const std::string& name);
    std::string uniqueName(const std::string& base) const;
    std::vector<int> childrenOf(int id) const;

    void destroy(int id);                              // group: anak naik ke parent-nya
    int add(Entity e);                                 // masukkan salinan entity (id baru, parent 0, nama unik)
    int duplicate(int id);                             // rekursif untuk group
    int group(const std::vector<int>& ids);            // buat Group di centroid, kembalikan id group (0 jika gagal)
    bool setParent(int id, int parent);                // pertahankan posisi dunia; false bila siklus
    bool isDescendant(int id, int maybeAncestor) const;

    Mat4 local(const Entity& e) const;
    Mat4 world(int id) const;
    bool worldBounds(int id, Vec3& mn, Vec3& mx) const;  // AABB dunia (untuk kind bergeometri)

    void beginPlay();                                  // simpan posisi dasar animasi
    void animate(float t, float dt);
    void purgeDead();

    Json toJson() const;
    bool fromJson(const Json& j, std::string* err = nullptr);
};

// Riwayat undo/redo berbasis snapshot JSON.
class History {
public:
    void push(const std::string& snapshot);
    bool undo(Scene& s);
    bool redo(Scene& s);
    size_t undoSize() const { return u.size(); }
    size_t redoSize() const { return r.size(); }
private:
    std::vector<std::string> u, r;
};

}  // namespace kyzn
