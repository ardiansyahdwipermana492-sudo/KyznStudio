#include "Script.h"

#ifdef KYZN_LUA
extern "C" {
#include "lauxlib.h"
#include "lua.h"
#include "lualib.h"
}

namespace kyzn {

struct ScriptRuntime::Impl {
    lua_State* L = nullptr;
    Scene* scene = nullptr;
    Log log, sfx;
    struct Run { int upd; std::string name; };
    std::vector<Run> runs;
    Vec2 in;
    Vec3 pl;
    float t = 0;
};

static ScriptRuntime::Impl* I(lua_State* L) { return static_cast<ScriptRuntime::Impl*>(lua_touserdata(L, lua_upvalueindex(1))); }
static Entity* ent(lua_State* L, int i) { return I(L)->scene->find((int)luaL_checkinteger(L, i)); }
static float num(lua_State* L, int i) { return (float)luaL_checknumber(L, i); }

static int l_print(lua_State* L) {
    int n = lua_gettop(L); std::string s;
    for (int i = 1; i <= n; i++) { size_t len; const char* c = luaL_tolstring(L, i, &len); if (i > 1) s += '\t'; s.append(c, len); lua_pop(L, 1); }
    I(L)->log(s); return 0;
}
static int l_find(lua_State* L) { Entity* e = I(L)->scene->findByName(luaL_checkstring(L, 1)); if (e) lua_pushinteger(L, e->id); else lua_pushnil(L); return 1; }
static int l_getpos(lua_State* L) { Entity* e = ent(L, 1); if (!e) return 0; lua_pushnumber(L, e->pos.x); lua_pushnumber(L, e->pos.y); lua_pushnumber(L, e->pos.z); return 3; }
static int l_setpos(lua_State* L) { if (Entity* e = ent(L, 1)) e->pos = {num(L, 2), num(L, 3), num(L, 4)}; return 0; }
static int l_move(lua_State* L) { if (Entity* e = ent(L, 1)) { e->pos.x += num(L, 2); e->pos.y += num(L, 3); e->pos.z += num(L, 4); } return 0; }
static int l_getrot(lua_State* L) { Entity* e = ent(L, 1); if (!e) return 0; lua_pushnumber(L, e->rot.x); lua_pushnumber(L, e->rot.y); lua_pushnumber(L, e->rot.z); return 3; }
static int l_setrot(lua_State* L) { if (Entity* e = ent(L, 1)) e->rot = {num(L, 2), num(L, 3), num(L, 4)}; return 0; }
static int l_rotate(lua_State* L) { if (Entity* e = ent(L, 1)) { e->rot.x += num(L, 2); e->rot.y += num(L, 3); e->rot.z += num(L, 4); } return 0; }
static int l_setscale(lua_State* L) { if (Entity* e = ent(L, 1)) e->scale = {num(L, 2), num(L, 3), num(L, 4)}; return 0; }
static int l_setcolor(lua_State* L) { if (Entity* e = ent(L, 1)) e->color = {num(L, 2), num(L, 3), num(L, 4)}; return 0; }
static int l_setvisible(lua_State* L) { if (Entity* e = ent(L, 1)) e->visible = lua_toboolean(L, 2) != 0; return 0; }
static int l_destroy(lua_State* L) { if (Entity* e = ent(L, 1)) e->dead = true; return 0; }
static int l_input(lua_State* L) { lua_pushnumber(L, I(L)->in.x); lua_pushnumber(L, I(L)->in.y); return 2; }
static int l_player(lua_State* L) { auto* d = I(L); lua_pushnumber(L, d->pl.x); lua_pushnumber(L, d->pl.y); lua_pushnumber(L, d->pl.z); return 3; }
static int l_time(lua_State* L) { lua_pushnumber(L, I(L)->t); return 1; }
static int l_sfx(lua_State* L) { I(L)->sfx(luaL_checkstring(L, 1)); return 0; }

static const struct { const char* n; lua_CFunction f; } kFns[] = {
    {"print", l_print}, {"find", l_find}, {"getpos", l_getpos}, {"setpos", l_setpos}, {"move", l_move},
    {"getrot", l_getrot}, {"setrot", l_setrot}, {"rotate", l_rotate}, {"setscale", l_setscale}, {"setcolor", l_setcolor},
    {"setvisible", l_setvisible}, {"destroy", l_destroy}, {"input", l_input}, {"player", l_player}, {"time", l_time}, {"sfx", l_sfx},
};

static void hook(lua_State* L, lua_Debug*) { luaL_error(L, "script terlalu lama (loop tak berujung?)"); }
static int safeCall(lua_State* L, int nargs) {
    lua_sethook(L, hook, LUA_MASKCOUNT, 3000000);
    int r = lua_pcall(L, nargs, 0, 0);
    lua_sethook(L, nullptr, 0, 0);
    return r;
}

ScriptRuntime::ScriptRuntime() {}
ScriptRuntime::~ScriptRuntime() { stop(); }
bool ScriptRuntime::available() { return true; }

bool ScriptRuntime::start(Scene& s, Log log, Log sfx) {
    stop();
    d.reset(new Impl);
    d->scene = &s; d->log = log; d->sfx = sfx;
    lua_State* L = d->L = luaL_newstate();
    if (!L) { log("[Lua] gagal membuat state"); return false; }
    luaL_requiref(L, "_G", luaopen_base, 1); lua_pop(L, 1);
    luaL_requiref(L, "math", luaopen_math, 1); lua_pop(L, 1);
    luaL_requiref(L, "string", luaopen_string, 1); lua_pop(L, 1);
    luaL_requiref(L, "table", luaopen_table, 1); lua_pop(L, 1);
    for (auto& e : s.entities) {
        if (e.kind != Kind::Script || !e.enabled) continue;
        lua_newtable(L);
        int env = lua_gettop(L);
        for (auto& f : kFns) { lua_pushlightuserdata(L, d.get()); lua_pushcclosure(L, f.f, 1); lua_setfield(L, env, f.n); }
        for (const char* lib : {"math", "string", "table"}) { lua_getglobal(L, lib); lua_setfield(L, env, lib); }
        for (const char* fn : {"tostring", "tonumber", "type", "pairs", "ipairs", "next", "select", "assert", "error", "pcall"}) { lua_getglobal(L, fn); lua_setfield(L, env, fn); }
        lua_pushinteger(L, e.attached); lua_setfield(L, env, "self");
        if (luaL_loadstring(L, e.code.c_str()) != LUA_OK) { log("[Lua] " + e.name + ": " + lua_tostring(L, -1)); lua_settop(L, env - 1); continue; }
        lua_pushvalue(L, env); lua_setupvalue(L, -2, 1);     // _ENV = tabel sandbox
        if (safeCall(L, 0) != LUA_OK) { log("[Lua] " + e.name + ": " + lua_tostring(L, -1)); lua_settop(L, env - 1); continue; }
        int upd = LUA_NOREF;
        lua_getfield(L, env, "onUpdate");
        if (lua_isfunction(L, -1)) upd = luaL_ref(L, LUA_REGISTRYINDEX); else lua_pop(L, 1);
        lua_getfield(L, env, "onStart");
        if (lua_isfunction(L, -1)) { if (safeCall(L, 0) != LUA_OK) { log("[Lua] " + e.name + ": " + lua_tostring(L, -1)); lua_pop(L, 1); } }
        else lua_pop(L, 1);
        lua_settop(L, env - 1);
        d->runs.push_back({upd, e.name});
    }
    return true;
}

void ScriptRuntime::update(float dt, Vec2 input, const Vec3& pp) {
    if (!d || !d->L) return;
    lua_State* L = d->L;
    d->in = input; d->pl = pp; d->t += dt;
    for (auto& r : d->runs) {
        if (r.upd == LUA_NOREF) continue;
        lua_rawgeti(L, LUA_REGISTRYINDEX, r.upd);
        lua_pushnumber(L, dt);
        if (safeCall(L, 1) != LUA_OK) {
            d->log("[Lua] " + r.name + ": " + lua_tostring(L, -1)); lua_pop(L, 1);
            luaL_unref(L, LUA_REGISTRYINDEX, r.upd); r.upd = LUA_NOREF;
        }
    }
}

void ScriptRuntime::stop() {
    if (d && d->L) lua_close(d->L);
    d.reset();
}

std::string ScriptRuntime::check(const std::string& code) {
    lua_State* L = luaL_newstate();
    if (!L) return "gagal membuat Lua state";
    std::string err;
    if (luaL_loadstring(L, code.c_str()) != LUA_OK) err = lua_tostring(L, -1);
    lua_close(L);
    return err;
}

}  // namespace kyzn

#else  // ---- stub tanpa Lua ----

namespace kyzn {
struct ScriptRuntime::Impl {};
ScriptRuntime::ScriptRuntime() {}
ScriptRuntime::~ScriptRuntime() {}
bool ScriptRuntime::available() { return false; }
bool ScriptRuntime::start(Scene& s, Log log, Log) {
    for (auto& e : s.entities) if (e.kind == Kind::Script && e.enabled) { log("[Lua] build ini tanpa Lua, script dilewati"); break; }
    return false;
}
void ScriptRuntime::update(float, Vec2, const Vec3&) {}
void ScriptRuntime::stop() {}
std::string ScriptRuntime::check(const std::string&) { return ""; }
}  // namespace kyzn

#endif
