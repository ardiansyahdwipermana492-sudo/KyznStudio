// KyznStudio - runtime scripting (Lua 5.4). Tanpa -DKYZN_LUA, kelas ini menjadi stub.
#pragma once
#include <functional>
#include <memory>
#include <string>
#include "Scene.h"

namespace kyzn {

class ScriptRuntime {
public:
    using Log = std::function<void(const std::string&)>;
    struct Impl;                                   // opaque
    ScriptRuntime();
    ~ScriptRuntime();
    ScriptRuntime(const ScriptRuntime&) = delete;
    ScriptRuntime& operator=(const ScriptRuntime&) = delete;

    static bool available();
    bool start(Scene& s, Log log, Log sfx);        // muat semua script aktif lalu panggil onStart()
    void update(float dt, Vec2 input, const Vec3& playerPos);
    void stop();
    static std::string check(const std::string& code);   // "" jika sintaks OK

private:
    std::unique_ptr<Impl> d;
};

}  // namespace kyzn
