#include "Game.h"

namespace kyzn {

bool GameSession::start(Scene& s, ScriptRuntime::Log log, ScriptRuntime::Log sfx) {
    s.beginPlay();
    spawn = {0, 0, 0};
    for (auto& e : s.entities) {
        Vec3 mn, mx;
        if (e.kind == Kind::Spawn && s.worldBounds(e.id, mn, mx)) { spawn = {(mn.x + mx.x) * .5f, mx.y, (mn.z + mx.z) * .5f}; break; }
    }
    player = PlayerState();
    player.pos = spawn;
    time = 0;
    for (auto& e : s.entities) if (e.kind == Kind::Sound && e.playOnStart && e.enabled) sfx(e.clip);
    script.start(s, log, sfx);
    active = true;
    return true;
}
void GameSession::stop() { script.stop(); active = false; }

void GameSession::update(Scene& s, float dt, const GameInput& in) {
    if (!active) return;
    time += dt;
    Vec3 fwd(-std::sin(yaw), 0, -std::cos(yaw)), right(std::cos(yaw), 0, -std::sin(yaw));
    Vec3 wish = fwd * in.move.y + right * in.move.x;
    if (length(wish) > 1.f) wish = normalize(wish);
    physics.rebuild(s);
    physics.stepPlayer(player, wish, in.jump, dt);
    if (player.pos.y < -50.f) { player.pos = spawn; player.vel = {}; }
    physics.stepBodies(s, dt);
    s.animate(time, dt);
    script.update(dt, in.move, player.pos);
    s.purgeDead();
}

CamPose GameSession::camera() const {
    return {player.pos + Vec3(std::sin(yaw) * 9.f, 5.f, std::cos(yaw) * 9.f), player.pos + Vec3(0, 1.2f, 0)};
}

}  // namespace kyzn
