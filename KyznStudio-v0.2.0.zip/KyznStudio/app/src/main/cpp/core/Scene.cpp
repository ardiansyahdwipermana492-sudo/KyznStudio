#include "Scene.h"
#include <algorithm>
#include <cctype>
#include <cmath>

namespace kyzn {

const KindInfo& kindInfo(Kind k) {
    static const KindInfo T[] = {
        {"Block", {4, 1, 2}, {.64f, .64f, .65f}, true, true},
        {"Sphere", {3, 3, 3}, {.64f, .64f, .65f}, true, true},
        {"Cylinder", {2, 4, 2}, {.64f, .64f, .65f}, true, true},
        {"Cone", {3, 4, 3}, {.64f, .64f, .65f}, true, true},
        {"Floor", {24, .5f, 24}, {.42f, .45f, .5f}, true, true},
        {"Spawn", {4, .4f, 4}, {.18f, .53f, 1.f}, true, false},
        {"Tree", {4, 8, 4}, {.25f, .48f, .24f}, true, true},
        {"House", {10, 6, 8}, {.73f, .66f, .54f}, true, true},
        {"Rock", {3, 2.4f, 3}, {.54f, .56f, .6f}, true, true},
        {"Pole", {3, 10, 3}, {.35f, .27f, .19f}, true, true},
        {"Crate", {2, 2, 2}, {.6f, .48f, .29f}, true, true},
        {"Barrel", {1.2f, 1.6f, 1.2f}, {.71f, .28f, .23f}, true, true},
        {"Tank", {4.4f, 4.4f, 6}, {.49f, .51f, .53f}, true, true},
        {"Container", {6, 2.6f, 2.4f}, {1, 1, 1}, true, true},
        {"Group", {1, 1, 1}, {1, 1, 1}, false, false},
        {"Script", {1, 1, 1}, {1, 1, 1}, false, false},
        {"Sound", {1, 1, 1}, {1, 1, 1}, false, false},
    };
    return T[(int)k];
}
const MatInfo& matInfo(MatType m) {
    static const MatInfo T[] = {
        {"Plastic", .6f, 0.f, {.64f, .64f, .65f}}, {"Metal", .3f, .9f, {.6f, .64f, .68f}},
        {"Wood", .85f, 0.f, {.54f, .42f, .27f}},   {"Grass", 1.f, 0.f, {.36f, .55f, .23f}},
        {"Concrete", .95f, 0.f, {.6f, .62f, .65f}}, {"Neon", .3f, 0.f, {.21f, 1.f, .7f}},
    };
    return T[(int)m];
}
const char* animName(AnimType a) {
    static const char* N[] = {"none", "spin", "bob", "patrol"};
    return N[(int)a];
}
bool kindFromName(const std::string& n, Kind& out) {
    for (int i = 0; i < (int)Kind::Count; i++) if (n == kindInfo((Kind)i).name) { out = (Kind)i; return true; }
    return false;
}
bool matFromName(const std::string& n, MatType& out) {
    for (int i = 0; i < (int)MatType::Count; i++) if (n == matInfo((MatType)i).name) { out = (MatType)i; return true; }
    return false;
}
bool animFromName(const std::string& n, AnimType& out) {
    for (int i = 0; i < (int)AnimType::Count; i++) if (n == animName((AnimType)i)) { out = (AnimType)i; return true; }
    return false;
}

static std::string stripDigits(std::string s) {
    while (s.size() > 1 && std::isdigit((unsigned char)s.back())) s.pop_back();
    return s;
}

int Scene::create(Kind k, const std::string& name) {
    const KindInfo& ki = kindInfo(k);
    Entity e;
    e.id = nextId++;
    e.kind = k;
    e.name = uniqueName(name.empty() ? ki.name : name);
    e.scale = ki.size;
    e.color = ki.color;
    e.collider = ki.solid;
    entities.push_back(e);
    return e.id;
}
Entity* Scene::find(int id) {
    for (auto& e : entities) if (e.id == id) return &e;
    return nullptr;
}
const Entity* Scene::find(int id) const {
    for (auto& e : entities) if (e.id == id) return &e;
    return nullptr;
}
Entity* Scene::findByName(const std::string& name) {
    for (auto& e : entities) if (e.name == name) return &e;
    return nullptr;
}
std::string Scene::uniqueName(const std::string& base) const {
    auto exists = [&](const std::string& n) { for (auto& e : entities) if (e.name == n) return true; return false; };
    if (!exists(base)) return base;
    for (int n = 2;; n++) { std::string c = base + std::to_string(n); if (!exists(c)) return c; }
}
std::vector<int> Scene::childrenOf(int id) const {
    std::vector<int> r;
    for (auto& e : entities) if (e.parent == id && e.id != id) r.push_back(e.id);
    return r;
}
bool Scene::isDescendant(int id, int anc) const {
    for (int guard = 0; id && guard < 128; guard++) {
        const Entity* e = find(id);
        if (!e) return false;
        id = e->parent;
        if (id == anc) return true;
    }
    return false;
}
bool Scene::setParent(int id, int parent) {
    Entity* e = find(id);
    if (!e || id == parent) return false;
    if (parent && (!find(parent) || isDescendant(parent, id))) return false;
    Vec3 wp = world(id).position();
    e->parent = parent;
    Mat4 pw = parent ? world(parent) : Mat4::identity();
    e->pos = pw.inverse().point(wp);
    return true;
}
void Scene::destroy(int id) {
    Entity* e = find(id);
    if (!e) return;
    int par = e->parent;
    bool isGroup = e->kind == Kind::Group;
    for (int c : childrenOf(id)) {
        if (isGroup) setParent(c, par);
        else destroy(c);
    }
    for (auto& s : entities) if (s.attached == id) s.attached = 0;
    entities.erase(std::remove_if(entities.begin(), entities.end(), [&](const Entity& x) { return x.id == id; }), entities.end());
}
int Scene::duplicate(int id) {
    const Entity* src = find(id);
    if (!src) return 0;
    Entity c = *src;
    std::vector<int> kids = childrenOf(id);
    c.id = nextId++;
    c.name = uniqueName(stripDigits(src->name));
    if (c.parent == 0) { c.pos.x += 2; c.pos.z += 2; }
    entities.push_back(c);
    int newId = c.id;
    for (int k : kids) {
        int d = duplicate(k);
        if (Entity* dc = find(d)) dc->parent = newId;
    }
    return newId;
}
int Scene::group(const std::vector<int>& ids) {
    std::vector<int> ok;
    Vec3 sum;
    for (int id : ids) {
        const Entity* e = find(id);
        if (!e || e->parent != 0 || !kindInfo(e->kind).geometry) continue;
        if (std::find(ok.begin(), ok.end(), id) != ok.end()) continue;
        ok.push_back(id); sum += e->pos;
    }
    if (ok.size() < 2) return 0;
    Vec3 c = sum / (float)ok.size();
    int gid = create(Kind::Group);
    Entity* g = find(gid);
    g->pos = c;
    for (int id : ok) { Entity* e = find(id); e->parent = gid; e->pos = e->pos - c; }
    return gid;
}
Mat4 Scene::local(const Entity& e) const { return Mat4::trs(e.pos, e.rot, e.scale); }
Mat4 Scene::world(int id) const {
    Mat4 m = Mat4::identity();
    for (int guard = 0; id && guard < 128; guard++) {
        const Entity* e = find(id);
        if (!e) break;
        m = local(*e) * m;
        id = e->parent;
    }
    return m;
}
bool Scene::worldBounds(int id, Vec3& mn, Vec3& mx) const {
    const Entity* e = find(id);
    if (!e || !kindInfo(e->kind).geometry) return false;
    Mat4 w = world(id);
    bool first = true;
    for (int i = 0; i < 8; i++) {
        Vec3 p = w.point({(i & 1) ? .5f : -.5f, (i & 2) ? .5f : -.5f, (i & 4) ? .5f : -.5f});
        if (first) { mn = mx = p; first = false; } else { mn = vmin(mn, p); mx = vmax(mx, p); }
    }
    return true;
}
void Scene::beginPlay() {
    for (auto& e : entities) { e.base = e.pos; e.vel = {}; e.dead = false; }
}
void Scene::animate(float t, float dt) {
    for (auto& e : entities) {
        switch (e.anim) {
            case AnimType::Spin: e.rot.y = std::fmod(e.rot.y + e.animSpeed * 60.f * dt, 360.f); break;
            case AnimType::Bob: e.pos.y = e.base.y + std::sin(t * e.animSpeed * 2.f) * e.animAmount; break;
            case AnimType::Patrol: e.pos.x = e.base.x + std::sin(t * e.animSpeed) * e.animAmount * 2.f; break;
            default: break;
        }
    }
}
void Scene::purgeDead() {
    std::vector<int> ids;
    for (auto& e : entities) if (e.dead) ids.push_back(e.id);
    for (int id : ids) destroy(id);
}

static Json v3j(const Vec3& v) { Json a = Json::array(); a.push(v.x); a.push(v.y); a.push(v.z); return a; }
static Vec3 j3v(const Json& j, const Vec3& def) {
    if (j.size() < 3) return def;
    return {(float)j.at(0).num(), (float)j.at(1).num(), (float)j.at(2).num()};
}

Json entityToJson(const Entity& e) {
    Json o = Json::object();
    o.set("id", e.id); o.set("name", e.name); o.set("kind", kindInfo(e.kind).name); o.set("parent", e.parent);
    o.set("pos", v3j(e.pos)); o.set("rot", v3j(e.rot)); o.set("scale", v3j(e.scale)); o.set("color", v3j(e.color));
    o.set("mat", matInfo(e.mat).name); o.set("tex", e.tex);
    o.set("transparency", e.transparency); o.set("reflectance", e.reflectance);
    o.set("visible", e.visible); o.set("castShadow", e.castShadow); o.set("receiveShadow", e.receiveShadow);
    o.set("collider", e.collider); o.set("rigidbody", e.rigidbody); o.set("kinematic", e.kinematic);
    o.set("useGravity", e.useGravity); o.set("mass", e.mass);
    o.set("anim", animName(e.anim)); o.set("animSpeed", e.animSpeed); o.set("animAmount", e.animAmount);
    o.set("tag", e.tag); o.set("layer", e.layer);
    if (e.kind == Kind::Script) { o.set("code", e.code); o.set("enabled", e.enabled); o.set("attached", e.attached); }
    if (e.kind == Kind::Sound) { o.set("clip", e.clip); o.set("playOnStart", e.playOnStart); }
    return o;
}

bool entityFromJson(const Json& o, Entity& e, std::string* err) {
    Kind k;
    if (!kindFromName(o["kind"].str(), k)) { if (err) *err = "kind tidak dikenal: " + o["kind"].str(); return false; }
    e = Entity();
    e.id = (int)o["id"].num(0);
    e.kind = k; e.name = o["name"].str(kindInfo(k).name); e.parent = (int)o["parent"].num(0);
    e.pos = j3v(o["pos"], {}); e.rot = j3v(o["rot"], {}); e.scale = j3v(o["scale"], {1, 1, 1}); e.color = j3v(o["color"], e.color);
    matFromName(o["mat"].str("Plastic"), e.mat);
    e.tex = (int)o["tex"].num(0);
    e.transparency = (float)o["transparency"].num(0); e.reflectance = (float)o["reflectance"].num(0);
    e.visible = o["visible"].boolean(true); e.castShadow = o["castShadow"].boolean(true); e.receiveShadow = o["receiveShadow"].boolean(true);
    e.collider = o["collider"].boolean(kindInfo(k).solid); e.rigidbody = o["rigidbody"].boolean(false);
    e.kinematic = o["kinematic"].boolean(false); e.useGravity = o["useGravity"].boolean(true); e.mass = (float)o["mass"].num(1);
    animFromName(o["anim"].str("none"), e.anim);
    e.animSpeed = (float)o["animSpeed"].num(1); e.animAmount = (float)o["animAmount"].num(2);
    e.tag = o["tag"].str("Untagged"); e.layer = o["layer"].str("Default");
    e.code = o["code"].str(); e.enabled = o["enabled"].boolean(true); e.attached = (int)o["attached"].num(0);
    e.clip = o["clip"].str("explosion"); e.playOnStart = o["playOnStart"].boolean(false);
    return true;
}

int Scene::add(Entity e) {
    e.id = nextId++;
    e.parent = 0;
    e.name = uniqueName(e.name.empty() ? kindInfo(e.kind).name : e.name);
    entities.push_back(e);
    return e.id;
}

Json Scene::toJson() const {
    Json r = Json::object();
    r.set("version", 1);
    r.set("nextId", nextId);
    Json L = Json::object();
    L.set("brightness", lighting.brightness);
    L.set("clockTime", lighting.clockTime);
    L.set("fogEnd", lighting.fogEnd);
    L.set("ambient", v3j(lighting.ambient));
    L.set("shadows", lighting.shadows);
    r.set("lighting", L);
    Json arr = Json::array();
    for (auto& e : entities) arr.push(entityToJson(e));
    r.set("entities", arr);
    return r;
}

bool Scene::fromJson(const Json& j, std::string* err) {
    if (j.type() != Json::Obj || j["entities"].type() != Json::Arr) { if (err) *err = "format scene tidak valid"; return false; }
    Scene t;
    t.nextId = std::max(1, (int)j["nextId"].num(1));
    const Json& L = j["lighting"];
    t.lighting.brightness = (float)L["brightness"].num(1);
    t.lighting.clockTime = (float)L["clockTime"].num(14);
    t.lighting.fogEnd = (float)L["fogEnd"].num(260);
    t.lighting.ambient = j3v(L["ambient"], t.lighting.ambient);
    t.lighting.shadows = L["shadows"].boolean(true);
    for (auto& o : j["entities"].items()) {
        Entity e;
        if (!entityFromJson(o, e, err)) return false;
        if (e.id <= 0 || t.find(e.id)) { if (err) *err = "id entity tidak valid/duplikat"; return false; }
        t.entities.push_back(e);
        t.nextId = std::max(t.nextId, e.id + 1);
    }
    for (auto& e : t.entities) {                       // rapikan referensi rusak
        if (e.parent && !t.find(e.parent)) e.parent = 0;
        if (e.attached && !t.find(e.attached)) e.attached = 0;
        if (e.parent && t.isDescendant(e.parent, e.id)) e.parent = 0;
    }
    *this = std::move(t);
    return true;
}

void History::push(const std::string& s) {
    u.push_back(s); r.clear();
    if (u.size() > 60) u.erase(u.begin());
}
bool History::undo(Scene& s) {
    if (u.empty()) return false;
    Json j; std::string snap = u.back();
    if (!Json::parse(snap, j)) return false;
    std::string cur = s.toJson().dump();
    if (!s.fromJson(j)) return false;
    u.pop_back(); r.push_back(cur);
    return true;
}
bool History::redo(Scene& s) {
    if (r.empty()) return false;
    Json j; std::string snap = r.back();
    if (!Json::parse(snap, j)) return false;
    std::string cur = s.toJson().dump();
    if (!s.fromJson(j)) return false;
    r.pop_back(); u.push_back(cur);
    return true;
}

}  // namespace kyzn
