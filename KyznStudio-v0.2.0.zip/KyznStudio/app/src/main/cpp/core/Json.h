// KyznStudio - JSON mini (parse + dump) tanpa dependensi
#pragma once
#include <cstdio>
#include <cstdlib>
#include <string>
#include <utility>
#include <vector>

namespace kyzn {

class Json {
public:
    enum Type { Null, Bool, Num, Str, Arr, Obj };
    Json() = default;
    Json(bool v) : t(Bool), b(v) {}
    Json(int v) : t(Num), n(v) {}
    Json(double v) : t(Num), n(v) {}
    Json(float v) : t(Num), n(v) {}
    Json(const char* v) : t(Str), s(v) {}
    Json(const std::string& v) : t(Str), s(v) {}
    static Json array() { Json j; j.t = Arr; return j; }
    static Json object() { Json j; j.t = Obj; return j; }

    Type type() const { return t; }
    bool isNull() const { return t == Null; }
    double num(double def = 0) const { return t == Num ? n : (t == Bool ? (b ? 1 : 0) : def); }
    bool boolean(bool def = false) const { return t == Bool ? b : (t == Num ? n != 0 : def); }
    std::string str(const std::string& def = "") const { return t == Str ? s : def; }
    size_t size() const { return t == Arr ? a.size() : (t == Obj ? o.size() : 0); }
    const Json& at(size_t i) const { static Json nul; return (t == Arr && i < a.size()) ? a[i] : nul; }
    const Json& operator[](const std::string& k) const {
        static Json nul;
        if (t == Obj) for (auto& kv : o) if (kv.first == k) return kv.second;
        return nul;
    }
    bool has(const std::string& k) const { if (t == Obj) for (auto& kv : o) if (kv.first == k) return true; return false; }
    Json& set(const std::string& k, Json v) {
        t = Obj;
        for (auto& kv : o) if (kv.first == k) { kv.second = std::move(v); return kv.second; }
        o.emplace_back(k, std::move(v)); return o.back().second;
    }
    Json& push(Json v) { t = Arr; a.push_back(std::move(v)); return a.back(); }
    const std::vector<Json>& items() const { return a; }

    std::string dump(int indent = -1) const { std::string out; write(out, indent, 0); return out; }

    static bool parse(const std::string& text, Json& out, std::string* err = nullptr) {
        Parser p{text.c_str(), text.c_str() + text.size(), err};
        p.ws();
        if (!p.value(out)) return false;
        p.ws();
        if (p.c != p.e) return p.fail("data berlebih setelah JSON");
        return true;
    }

private:
    Type t = Null; bool b = false; double n = 0; std::string s;
    std::vector<Json> a; std::vector<std::pair<std::string, Json>> o;

    static void esc(std::string& out, const std::string& v) {
        out += '"';
        for (unsigned char ch : v) {
            switch (ch) {
                case '"': out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\n': out += "\\n"; break;
                case '\r': out += "\\r"; break;
                case '\t': out += "\\t"; break;
                default:
                    if (ch < 0x20) { char buf[8]; std::snprintf(buf, sizeof buf, "\\u%04x", ch); out += buf; }
                    else out += (char)ch;
            }
        }
        out += '"';
    }
    void write(std::string& out, int ind, int lvl) const {
        auto nl = [&](int l) { if (ind >= 0) { out += '\n'; out.append((size_t)(ind * l), ' '); } };
        switch (t) {
            case Null: out += "null"; break;
            case Bool: out += b ? "true" : "false"; break;
            case Num: {
                char buf[40];
                if (n == (long long)n && n > -1e15 && n < 1e15) std::snprintf(buf, sizeof buf, "%lld", (long long)n);
                else std::snprintf(buf, sizeof buf, "%.7g", n);
                out += buf; break;
            }
            case Str: esc(out, s); break;
            case Arr:
                out += '[';
                for (size_t i = 0; i < a.size(); i++) { if (i) out += ','; nl(lvl + 1); a[i].write(out, ind, lvl + 1); }
                if (!a.empty()) nl(lvl);
                out += ']'; break;
            case Obj:
                out += '{';
                for (size_t i = 0; i < o.size(); i++) {
                    if (i) out += ',';
                    nl(lvl + 1); esc(out, o[i].first); out += ind >= 0 ? ": " : ":"; o[i].second.write(out, ind, lvl + 1);
                }
                if (!o.empty()) nl(lvl);
                out += '}'; break;
        }
    }
    struct Parser {
        const char* c; const char* e; std::string* err;
        bool fail(const char* m) { if (err) *err = m; return false; }
        void ws() { while (c < e && (*c == ' ' || *c == '\n' || *c == '\t' || *c == '\r')) c++; }
        bool lit(const char* w) { size_t l = std::char_traits<char>::length(w); if ((size_t)(e - c) >= l && std::string(c, l) == w) { c += l; return true; } return false; }
        bool str(std::string& out) {
            if (c >= e || *c != '"') return fail("string diharapkan");
            c++;
            while (c < e && *c != '"') {
                if (*c == '\\') {
                    c++; if (c >= e) return fail("escape rusak");
                    switch (*c) {
                        case 'n': out += '\n'; break; case 't': out += '\t'; break; case 'r': out += '\r'; break;
                        case 'b': out += '\b'; break; case 'f': out += '\f'; break;
                        case 'u': {
                            if (e - c < 5) return fail("unicode rusak");
                            unsigned v = (unsigned)std::strtoul(std::string(c + 1, 4).c_str(), nullptr, 16); c += 4;
                            if (v < 0x80) out += (char)v;
                            else if (v < 0x800) { out += (char)(0xC0 | (v >> 6)); out += (char)(0x80 | (v & 63)); }
                            else { out += (char)(0xE0 | (v >> 12)); out += (char)(0x80 | ((v >> 6) & 63)); out += (char)(0x80 | (v & 63)); }
                            break;
                        }
                        default: out += *c;
                    }
                    c++;
                } else out += *c++;
            }
            if (c >= e) return fail("string tidak ditutup");
            c++; return true;
        }
        bool value(Json& out) {
            ws();
            if (c >= e) return fail("data kosong");
            if (*c == '{') {
                c++; out = Json::object(); ws();
                if (c < e && *c == '}') { c++; return true; }
                for (;;) {
                    ws(); std::string k; if (!str(k)) return false; ws();
                    if (c >= e || *c != ':') return fail("':' diharapkan");
                    c++; Json v; if (!value(v)) return false;
                    out.set(k, std::move(v)); ws();
                    if (c < e && *c == ',') { c++; continue; }
                    if (c < e && *c == '}') { c++; return true; }
                    return fail("',' atau '}' diharapkan");
                }
            }
            if (*c == '[') {
                c++; out = Json::array(); ws();
                if (c < e && *c == ']') { c++; return true; }
                for (;;) {
                    Json v; if (!value(v)) return false;
                    out.push(std::move(v)); ws();
                    if (c < e && *c == ',') { c++; continue; }
                    if (c < e && *c == ']') { c++; return true; }
                    return fail("',' atau ']' diharapkan");
                }
            }
            if (*c == '"') { std::string s; if (!str(s)) return false; out = Json(s); return true; }
            if (lit("true")) { out = Json(true); return true; }
            if (lit("false")) { out = Json(false); return true; }
            if (lit("null")) { out = Json(); return true; }
            char* end = nullptr; double d = std::strtod(c, &end);
            if (end == c) return fail("token tidak dikenal");
            c = end; out = Json(d); return true;
        }
    };
};

}  // namespace kyzn
