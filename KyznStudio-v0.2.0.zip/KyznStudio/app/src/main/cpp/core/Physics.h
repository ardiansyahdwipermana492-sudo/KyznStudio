// KyznStudio - fisika AABB: gravitasi, tumpukan, pemain (step-up, lompat)
#pragma once
#include <vector>
#include "Scene.h"

namespace kyzn {

struct PlayerState {
    Vec3 pos, vel;
    float yaw = 0, radius = .45f, height = 1.8f;
    bool grounded = false;
};

class Physics {
public:
    struct Box { int id; Vec3 mn, mx; };
    void rebuild(const Scene& s);
    float groundHeight(float x, float z, float footY, float radius, int ignoreId = 0) const;
    bool blocked(float x, float z, float footY, float radius, float height, int ignoreId = 0) const;
    void stepPlayer(PlayerState& p, const Vec3& wishDir, bool jump, float dt) const;
    void stepBodies(Scene& s, float dt);
    const std::vector<Box>& boxes() const { return list; }
    static constexpr float kGravity = 26.f, kStepUp = .5f, kJump = 9.5f, kSpeed = 7.f;
private:
    std::vector<Box> list;
};

}  // namespace kyzn
