#include "Physics.h"

namespace kyzn {

void Physics::rebuild(const Scene& s) {
    list.clear();
    for (auto& e : s.entities) {
        if (!e.collider || !e.visible) continue;
        Vec3 mn, mx;
        if (s.worldBounds(e.id, mn, mx)) list.push_back({e.id, mn, mx});
    }
}
float Physics::groundHeight(float x, float z, float footY, float r, int ignore) const {
    float best = 0.f;                                    // bidang tanah y=0
    for (auto& b : list) {
        if (b.id == ignore) continue;
        if (x > b.mn.x - r && x < b.mx.x + r && z > b.mn.z - r && z < b.mx.z + r && b.mx.y <= footY + kStepUp && b.mx.y > best) best = b.mx.y;
    }
    return best;
}
bool Physics::blocked(float x, float z, float footY, float r, float h, int ignore) const {
    for (auto& b : list) {
        if (b.id == ignore) continue;
        if (x > b.mn.x - r && x < b.mx.x + r && z > b.mn.z - r && z < b.mx.z + r && b.mx.y > footY + kStepUp && b.mn.y < footY + h) return true;
    }
    return false;
}
void Physics::stepPlayer(PlayerState& p, const Vec3& wish, bool jump, float dt) const {
    Vec3 d = wish * (kSpeed * dt);
    if (d.x != 0.f && !blocked(p.pos.x + d.x, p.pos.z, p.pos.y, p.radius, p.height)) p.pos.x += d.x;
    if (d.z != 0.f && !blocked(p.pos.x, p.pos.z + d.z, p.pos.y, p.radius, p.height)) p.pos.z += d.z;
    if (length(wish) > .05f) p.yaw = std::atan2(wish.x, wish.z) * kR2D;
    p.vel.y -= kGravity * dt;
    p.pos.y += p.vel.y * dt;
    float g = groundHeight(p.pos.x, p.pos.z, p.pos.y, p.radius);
    if (p.pos.y <= g) { p.pos.y = g; p.vel.y = 0; p.grounded = true; } else p.grounded = false;
    if (jump && p.grounded) { p.vel.y = kJump; p.grounded = false; }
}
void Physics::stepBodies(Scene& s, float dt) {
    for (auto& e : s.entities) {
        if (!e.rigidbody || e.kinematic || e.parent != 0 || !kindInfo(e.kind).geometry) continue;
        if (e.useGravity) e.vel.y -= kGravity * dt;
        e.pos.y += e.vel.y * dt;
        Vec3 mn, mx;
        if (!s.worldBounds(e.id, mn, mx)) continue;
        float half = std::max(mx.x - mn.x, mx.z - mn.z) * .25f;
        float g = groundHeight((mn.x + mx.x) * .5f, (mn.z + mx.z) * .5f, mn.y, half, e.id);
        if (mn.y <= g) { e.pos.y += g - mn.y; e.vel.y = 0; }
    }
}

}  // namespace kyzn
