// KyznStudio - sesi permainan (dipakai Game Preview di editor dan runtime APK hasil publish)
#pragma once
#include "Physics.h"
#include "Script.h"

namespace kyzn {

struct GameInput { Vec2 move; bool jump = false; };   // move.y > 0 = maju
struct CamPose { Vec3 eye, target; };

class GameSession {
public:
    bool start(Scene& s, ScriptRuntime::Log log, ScriptRuntime::Log sfx);
    void stop();
    bool running() const { return active; }
    void update(Scene& s, float dt, const GameInput& in);
    void look(float dYaw) { yaw -= dYaw; }
    CamPose camera() const;

    PlayerState player;
    float yaw = .9f, time = 0;
    Physics physics;
private:
    ScriptRuntime script;
    bool active = false;
    Vec3 spawn;
};

}  // namespace kyzn
