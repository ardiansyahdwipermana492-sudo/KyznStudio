// KyznStudio - pengaturan publish, validasi, dan export paket game
#pragma once
#include <string>
#include <vector>
#include "Scene.h"

namespace kyzn {

struct PublishSettings {
    std::string appName = "My Game", package = "com.kyzn.mygame", versionName = "1.0.0";
    std::string orientation = "portrait", format = "apk", signing = "debug";   // orientation: portrait|landscape|auto
    int versionCode = 1, minSdk = 24, targetSdk = 34, resW = 1080, resH = 1920;
    Json toJson() const;
    static PublishSettings fromJson(const Json& j);
};

struct Issue { bool error; std::string text; };

bool validPackage(const std::string& p);
std::vector<Issue> validate(const Scene& s, const PublishSettings& ps);
bool hasErrors(const std::vector<Issue>& v);

bool makeDirs(const std::string& path);
bool writeFile(const std::string& path, const std::string& data);
bool readFile(const std::string& path, std::string& out);

// Menulis <dir>/game/main.scene.json dan <dir>/game/publish.json
bool exportGame(const Scene& s, const PublishSettings& ps, const std::string& dir, std::vector<std::string>& written, std::string& err);

}  // namespace kyzn
