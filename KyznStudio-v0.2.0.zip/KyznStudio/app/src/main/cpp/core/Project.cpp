#include "Project.h"
#include <cctype>
#include <cerrno>
#include <cstdio>
#include <set>
#include <sys/stat.h>
#include "Script.h"

namespace kyzn {

Json PublishSettings::toJson() const {
    Json j = Json::object();
    j.set("appName", appName); j.set("package", package); j.set("versionName", versionName); j.set("versionCode", versionCode);
    j.set("minSdk", minSdk); j.set("targetSdk", targetSdk); j.set("orientation", orientation); j.set("format", format);
    j.set("signing", signing); j.set("resW", resW); j.set("resH", resH);
    return j;
}
PublishSettings PublishSettings::fromJson(const Json& j) {
    PublishSettings p;
    p.appName = j["appName"].str(p.appName); p.package = j["package"].str(p.package); p.versionName = j["versionName"].str(p.versionName);
    p.versionCode = (int)j["versionCode"].num(p.versionCode); p.minSdk = (int)j["minSdk"].num(p.minSdk); p.targetSdk = (int)j["targetSdk"].num(p.targetSdk);
    p.orientation = j["orientation"].str(p.orientation); p.format = j["format"].str(p.format); p.signing = j["signing"].str(p.signing);
    p.resW = (int)j["resW"].num(p.resW); p.resH = (int)j["resH"].num(p.resH);
    return p;
}

bool validPackage(const std::string& p) {
    if (p.empty() || p.size() > 120) return false;
    int segs = 0; size_t i = 0;
    while (i <= p.size()) {
        size_t j = p.find('.', i); if (j == std::string::npos) j = p.size();
        if (j == i || !std::isalpha((unsigned char)p[i])) return false;
        for (size_t k = i; k < j; k++) { unsigned char c = (unsigned char)p[k]; if (!(std::isalnum(c) || c == '_')) return false; }
        segs++; i = j + 1;
    }
    return segs >= 2;
}

std::vector<Issue> validate(const Scene& s, const PublishSettings& ps) {
    std::vector<Issue> v;
    auto err = [&](const std::string& t) { v.push_back({true, t}); };
    auto warn = [&](const std::string& t) { v.push_back({false, t}); };
    if (ps.appName.empty()) err("Nama app kosong");
    if (!validPackage(ps.package)) err("Package tidak valid (contoh: com.kyzn.mygame)");
    if (ps.versionName.empty()) err("Version name kosong");
    if (ps.versionCode < 1) err("Version code minimal 1");
    if (ps.minSdk < 21 || ps.minSdk > ps.targetSdk) err("Min SDK harus >= 21 dan <= Target SDK");
    if (ps.format != "apk" && ps.format != "aab") err("Format harus apk atau aab");
    if (ps.orientation != "portrait" && ps.orientation != "landscape" && ps.orientation != "auto") err("Orientasi tidak valid");
    if (ps.format == "aab" && ps.signing == "debug") warn("AAB bertanda tangan debug tidak bisa diunggah ke Play Store");
    int solid = 0, spawns = 0;
    std::set<std::string> names;
    for (auto& e : s.entities) {
        if (kindInfo(e.kind).geometry && e.kind != Kind::Spawn) solid++;
        if (e.kind == Kind::Spawn) spawns++;
        if (!names.insert(e.name).second) warn("Nama object ganda: " + e.name);
        if (e.kind == Kind::Script && e.enabled) {
            std::string se = ScriptRuntime::check(e.code);
            if (!se.empty()) err("Script " + e.name + ": " + se);
            if (e.code.find_first_not_of(" \t\r\n") == std::string::npos) warn("Script kosong: " + e.name);
        }
    }
    if (solid == 0) err("Dunia masih kosong, tambahkan minimal 1 object");
    if (spawns == 0) warn("Tidak ada Spawn: pemain muncul di titik 0,0,0");
    if (!ScriptRuntime::available()) warn("Build ini tanpa Lua: script tidak berjalan di game");
    return v;
}
bool hasErrors(const std::vector<Issue>& v) { for (auto& i : v) if (i.error) return true; return false; }

bool makeDirs(const std::string& path) {
    std::string cur;
    for (size_t i = 0; i <= path.size(); i++) {
        if (i == path.size() || path[i] == '/') {
            if (!cur.empty() && cur != "/") { if (mkdir(cur.c_str(), 0775) != 0 && errno != EEXIST) return false; }
        }
        if (i < path.size()) cur += path[i];
    }
    struct stat st; return stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}
bool writeFile(const std::string& path, const std::string& data) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    size_t n = std::fwrite(data.data(), 1, data.size(), f);
    std::fclose(f);
    return n == data.size();
}
bool readFile(const std::string& path, std::string& out) {
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    out.clear(); char buf[4096]; size_t n;
    while ((n = std::fread(buf, 1, sizeof buf, f)) > 0) out.append(buf, n);
    std::fclose(f);
    return true;
}

bool exportGame(const Scene& s, const PublishSettings& ps, const std::string& dir, std::vector<std::string>& written, std::string& err) {
    std::string g = dir + "/game";
    if (!makeDirs(g)) { err = "gagal membuat folder " + g; return false; }
    std::string a = g + "/main.scene.json", b = g + "/publish.json";
    if (!writeFile(a, s.toJson().dump(1))) { err = "gagal menulis " + a; return false; }
    if (!writeFile(b, ps.toJson().dump(1))) { err = "gagal menulis " + b; return false; }
    written = {a, b};
    return true;
}

}  // namespace kyzn
