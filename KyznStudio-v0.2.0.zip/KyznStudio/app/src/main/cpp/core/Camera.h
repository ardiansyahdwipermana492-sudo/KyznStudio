// KyznStudio - kamera perspektif + kamera orbit editor + proyeksi layar
#pragma once
#include "Math.h"

namespace kyzn {

struct Camera {
    Vec3 eye{0, 5, 10}, target{0, 0, 0};
    float fovY = 55, nearZ = .1f, farZ = 900;
    Mat4 view() const { return Mat4::lookAt(eye, target, {0, 1, 0}); }
    Mat4 proj(float aspect) const { return Mat4::perspective(fovY, aspect, nearZ, farZ); }
    Mat4 viewProj(float aspect) const { return proj(aspect) * view(); }
    // nx, ny dalam NDC [-1,1], y ke atas. Ray.d ternormalisasi.
    Ray ray(float aspect, float nx, float ny) const {
        Mat4 inv = viewProj(aspect).inverse();
        Vec3 a = inv.point({nx, ny, -1.f}), b = inv.point({nx, ny, 1.f});
        return {a, normalize(b - a)};
    }
};

// Proyeksi titik dunia ke piksel layar (0,0 = kiri atas). false jika di belakang kamera.
inline bool projectToScreen(const Mat4& vp, const Vec3& p, float w, float h, Vec2& out) {
    float cw = vp.m[3] * p.x + vp.m[7] * p.y + vp.m[11] * p.z + vp.m[15];
    if (cw <= 1e-5f) return false;
    Vec3 n = vp.point(p);
    out.x = (n.x * .5f + .5f) * w;
    out.y = (1.f - (n.y * .5f + .5f)) * h;
    return true;
}

struct OrbitCamera {
    float yaw = .8f, pitch = .35f, dist = 22;
    Vec3 target{0, 2, 0};
    Camera toCamera() const {
        Camera c;
        c.target = target;
        c.eye = target + Vec3(std::sin(yaw) * std::cos(pitch), std::sin(pitch), std::cos(yaw) * std::cos(pitch)) * dist;
        return c;
    }
    void orbit(float dx, float dy) { yaw -= dx * .008f; pitch = clampf(pitch + dy * .006f, .05f, 1.5f); }
    void zoom(float factor) { dist = clampf(dist * factor, 3.f, 160.f); }
    Vec3 forwardXZ() const { return {-std::sin(yaw), 0, -std::cos(yaw)}; }
    Vec3 rightXZ() const { return {std::cos(yaw), 0, -std::sin(yaw)}; }
    void pan(float dx, float dy) {                       // geser kamera di bidang tanah (hand tool)
        float k = dist * .0022f;
        target = target - rightXZ() * (dx * k) + forwardXZ() * (dy * k);
    }
    void move(float strafe, float forward, float up, float dt) {   // joystick editor
        float s = 14.f * dt * clampf(dist / 20.f, .5f, 3.f);
        target = target + rightXZ() * (strafe * s) + forwardXZ() * (forward * s);
        target.y = clampf(target.y + up * dt * 10.f, 0.f, 80.f);
    }
};

}  // namespace kyzn
