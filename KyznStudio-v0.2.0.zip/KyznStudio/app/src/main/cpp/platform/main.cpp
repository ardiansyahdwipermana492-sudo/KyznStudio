// KyznStudio - titik masuk Android (NativeActivity murni, tanpa Java/Kotlin)
#include <android/asset_manager.h>
#include <android/configuration.h>
#include <android/log.h>
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <jni.h>
#include <time.h>
#include <unistd.h>
#include <algorithm>
#include <memory>
#include <string>
#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"
#include "../editor/Editor.h"
#include "../editor/Runtime.h"
#include "../render/Renderer.h"

#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#ifndef EGL_OPENGL_ES3_BIT
#define EGL_OPENGL_ES3_BIT 0x00000040
#endif
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "KyznStudio", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "KyznStudio", __VA_ARGS__)

using namespace kyzn;

struct App {
    android_app* a = nullptr;
    EGLDisplay dpy = EGL_NO_DISPLAY; EGLSurface surf = EGL_NO_SURFACE; EGLContext ctx = EGL_NO_CONTEXT;
    bool ready = false, imguiCtx = false, kb = false;
    std::unique_ptr<Renderer> renderer;
    std::unique_ptr<Editor> editor;
    std::unique_ptr<Runtime> runtime;
    Platform pf;
    Touch touch;
    double last = 0;
    float ui = 2.f;
};
static App G;

// ------------------------------------------------------------ JNI helper
static JNIEnv* jniEnv() {
    JavaVM* vm = G.a->activity->vm; JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) == JNI_OK) return env;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return nullptr;
    return env;
}
static int unicodeFromKey(int action, int keycode, int meta) {
    JNIEnv* env = jniEnv(); if (!env) return 0;
    jclass cls = env->FindClass("android/view/KeyEvent");
    jmethodID ctor = env->GetMethodID(cls, "<init>", "(II)V"), gu = env->GetMethodID(cls, "getUnicodeChar", "(I)I");
    jobject ev = env->NewObject(cls, ctor, action, keycode);
    int u = env->CallIntMethod(ev, gu, meta);
    env->DeleteLocalRef(ev); env->DeleteLocalRef(cls);
    return u;
}
static void setClipboard(const std::string& text) {
    JNIEnv* env = jniEnv(); if (!env) return;
    jobject act = G.a->activity->clazz;
    jclass actCls = env->GetObjectClass(act);
    jmethodID gs = env->GetMethodID(actCls, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
    jstring svc = env->NewStringUTF("clipboard");
    jobject cm = env->CallObjectMethod(act, gs, svc);
    if (!cm) return;
    jclass cmCls = env->GetObjectClass(cm), cdCls = env->FindClass("android/content/ClipData");
    jmethodID np = env->GetStaticMethodID(cdCls, "newPlainText", "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;");
    jstring label = env->NewStringUTF("KyznStudio"), body = env->NewStringUTF(text.c_str());
    jobject clip = env->CallStaticObjectMethod(cdCls, np, label, body);
    jmethodID sp = env->GetMethodID(cmCls, "setPrimaryClip", "(Landroid/content/ClipData;)V");
    env->CallVoidMethod(cm, sp, clip);
    if (env->ExceptionCheck()) { env->ExceptionDescribe(); env->ExceptionClear(); }
}
static bool readAsset(const char* name, std::string& out) {
    AAsset* a = AAssetManager_open(G.a->activity->assetManager, name, AASSET_MODE_BUFFER);
    if (!a) return false;
    out.assign((const char*)AAsset_getBuffer(a), (size_t)AAsset_getLength(a));
    AAsset_close(a);
    return true;
}

// ------------------------------------------------------------ EGL
static bool initEGL() {
    G.dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (G.dpy == EGL_NO_DISPLAY || !eglInitialize(G.dpy, nullptr, nullptr)) { LOGE("eglInitialize gagal"); return false; }
    const EGLint attr[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg; EGLint n = 0;
    if (!eglChooseConfig(G.dpy, attr, &cfg, 1, &n) || n < 1) { LOGE("eglChooseConfig gagal"); return false; }
    EGLint fmt; eglGetConfigAttrib(G.dpy, cfg, EGL_NATIVE_VISUAL_ID, &fmt);
    ANativeWindow_setBuffersGeometry(G.a->window, 0, 0, fmt);
    const EGLint cattr[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    G.ctx = eglCreateContext(G.dpy, cfg, EGL_NO_CONTEXT, cattr);
    G.surf = eglCreateWindowSurface(G.dpy, cfg, G.a->window, nullptr);
    if (G.ctx == EGL_NO_CONTEXT || G.surf == EGL_NO_SURFACE || !eglMakeCurrent(G.dpy, G.surf, G.surf, G.ctx)) { LOGE("EGL context/surface gagal"); return false; }
    eglSwapInterval(G.dpy, 1);
    return true;
}
static void termEGL() {
    if (G.dpy != EGL_NO_DISPLAY) {
        eglMakeCurrent(G.dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (G.ctx != EGL_NO_CONTEXT) eglDestroyContext(G.dpy, G.ctx);
        if (G.surf != EGL_NO_SURFACE) eglDestroySurface(G.dpy, G.surf);
        eglTerminate(G.dpy);
    }
    G.dpy = EGL_NO_DISPLAY; G.ctx = EGL_NO_CONTEXT; G.surf = EGL_NO_SURFACE;
}

// ------------------------------------------------------------ siklus hidup app
static void startApp() {
    int density = AConfiguration_getDensity(G.a->config);
    if (density <= 0 || density > 2000) density = 320;
    G.ui = std::max(1.2f, std::min(3.0f, density / 160.f * .8f));
    if (!G.imguiCtx) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
        ImFont* f = nullptr;
        for (const char* p : {"/system/fonts/Roboto-Regular.ttf", "/system/fonts/NotoSans-Regular.ttf", "/system/fonts/DroidSans.ttf"})
            if (access(p, R_OK) == 0) { f = io.Fonts->AddFontFromFileTTF(p, 15.f * G.ui); if (f) break; }
        if (!f) { ImFontConfig c; c.SizePixels = 15.f * G.ui; io.Fonts->AddFontDefault(&c); }
        G.imguiCtx = true;
    }
    ImGui_ImplAndroid_Init(G.a->window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    G.renderer.reset(new Renderer());
    if (!G.renderer->init()) { LOGE("renderer: %s", G.renderer->error().c_str()); }
    else if (!G.renderer->error().empty()) LOGE("renderer (peringatan): %s", G.renderer->error().c_str());

    const char* dir = G.a->activity->externalDataPath ? G.a->activity->externalDataPath : G.a->activity->internalDataPath;
    G.pf.dataDir = dir ? dir : "";
    G.pf.ui = G.ui;
    G.pf.setClipboard = setClipboard;
    if (!G.editor && !G.runtime) {
        std::string scene, pubJson, err;
        if (readAsset("game/main.scene.json", scene)) {                 // APK hasil publish: langsung jalankan game
            readAsset("game/publish.json", pubJson);
            G.runtime.reset(new Runtime());
            if (!G.runtime->load(scene, pubJson, err)) { LOGE("game gagal dimuat: %s", err.c_str()); G.runtime.reset(); }
        }
        if (!G.runtime) {
            G.editor.reset(new Editor(G.pf));
            G.editor->style();
            G.editor->autoload();
        }
    }
    if (G.editor) G.editor->attach(G.renderer.get());
    if (G.runtime) G.runtime->attach(G.renderer.get());
    G.last = 0;
}
static void stopApp() {
    if (G.editor) { G.editor->autosave(); G.editor->releaseGL(); }
    if (G.runtime) G.runtime->releaseGL();
    if (G.renderer) { G.renderer->shutdown(); G.renderer.reset(); }
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    termEGL();
    G.ready = false;
}

static void frame() {
    if (!G.ready || !G.a->window) return;
    ImGuiIO& io = ImGui::GetIO();
    timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    double now = ts.tv_sec + ts.tv_nsec * 1e-9;
    float dt = G.last > 0 ? (float)(now - G.last) : 1.f / 60.f; G.last = now;
    if (dt > .1f) dt = .1f;
    ImGui_ImplOpenGL3_NewFrame(); ImGui_ImplAndroid_NewFrame(); ImGui::NewFrame();
    float W = io.DisplaySize.x, H = io.DisplaySize.y;
    if (G.runtime) G.runtime->frame(dt, G.touch, W, H, G.ui);
    else if (G.editor) G.editor->frame(dt, G.touch, W, H);
    if (io.WantTextInput != G.kb) {
        G.kb = io.WantTextInput;
        if (G.kb) ANativeActivity_showSoftInput(G.a->activity, ANATIVEACTIVITY_SHOW_SOFT_INPUT_FORCED);
        else ANativeActivity_hideSoftInput(G.a->activity, ANATIVEACTIVITY_HIDE_SOFT_INPUT_NOT_ALWAYS);
    }
    ImGui::Render();
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, (int)W, (int)H);
    glClearColor(.04f, .07f, .15f, 1.f); glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(G.dpy, G.surf);
}

static void onCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window && initEGL()) { startApp(); G.ready = true; }
            break;
        case APP_CMD_TERM_WINDOW: if (G.ready) stopApp(); break;
        case APP_CMD_PAUSE: case APP_CMD_SAVE_STATE: if (G.editor) G.editor->autosave(); break;
        default: break;
    }
}

static void updateTouch(const AInputEvent* ev) {
    int n = (int)AMotionEvent_getPointerCount(ev);
    int act = AMotionEvent_getAction(ev), type = act & AMOTION_EVENT_ACTION_MASK;
    int skip = -1;
    if (type == AMOTION_EVENT_ACTION_POINTER_UP) skip = (act & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    Touch t;
    for (int i = 0; i < n && t.count < 5; i++) {
        if (i == skip) continue;
        t.id[t.count] = AMotionEvent_getPointerId(ev, i);
        t.x[t.count] = AMotionEvent_getX(ev, i); t.y[t.count] = AMotionEvent_getY(ev, i);
        t.count++;
    }
    if (type == AMOTION_EVENT_ACTION_UP || type == AMOTION_EVENT_ACTION_CANCEL) t.count = 0;
    G.touch = t;
}
static int32_t onInput(android_app*, AInputEvent* ev) {
    int type = AInputEvent_getType(ev);
    if (type == AINPUT_EVENT_TYPE_MOTION) updateTouch(ev);
    else if (type == AINPUT_EVENT_TYPE_KEY && G.imguiCtx && AKeyEvent_getAction(ev) == AKEY_EVENT_ACTION_DOWN && ImGui::GetIO().WantTextInput) {
        int u = unicodeFromKey(AKEY_EVENT_ACTION_DOWN, AKeyEvent_getKeyCode(ev), AKeyEvent_getMetaState(ev));
        if (u >= 32 && u != 127) ImGui::GetIO().AddInputCharacter((unsigned)u);
    }
    return G.imguiCtx ? ImGui_ImplAndroid_HandleInputEvent(ev) : 0;
}

void android_main(android_app* app) {
    G.a = app;
    app->onAppCmd = onCmd;
    app->onInputEvent = onInput;
    for (;;) {
        int events; android_poll_source* src;
        while (ALooper_pollAll(G.ready ? 0 : -1, nullptr, &events, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) { if (G.ready) stopApp(); return; }
        }
        frame();
    }
}
