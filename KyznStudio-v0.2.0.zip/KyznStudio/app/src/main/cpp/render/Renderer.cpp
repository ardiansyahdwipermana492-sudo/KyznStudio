#include "Renderer.h"
#include <cmath>
#include <cstdio>
#include <cstring>

namespace kyzn {

// ------------------------------------------------------------------ shader
static const char* kLitVS = R"(#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNrm; layout(location=2) in vec2 aUv;
uniform mat4 uVP, uModel, uLightVP; uniform mat3 uNrm;
out vec3 vN; out vec3 vW; out vec2 vUv; out vec4 vLS;
void main(){ vec4 w = uModel * vec4(aPos, 1.0); vW = w.xyz; vN = normalize(uNrm * aNrm); vUv = aUv; vLS = uLightVP * w; gl_Position = uVP * w; }
)";
static const char* kLitFS = R"(#version 300 es
precision highp float; precision highp sampler2DShadow;
in vec3 vN; in vec3 vW; in vec2 vUv; in vec4 vLS;
uniform vec3 uColor, uEye, uLightDir, uLightCol, uAmbSky, uAmbGround, uFogCol;
uniform float uRough, uMetal, uAlpha, uEmis, uFogNear, uFogFar, uShadowOn;
uniform int uUseTex; uniform vec2 uUvScale;
uniform sampler2D uTex; uniform sampler2DShadow uShadow;
out vec4 o;
float shadowTerm(){
  if (uShadowOn < 0.5) return 1.0;
  vec3 p = vLS.xyz / vLS.w * 0.5 + 0.5;
  if (p.z > 1.0 || p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) return 1.0;
  float s = 0.0; vec2 ts = 1.0 / vec2(textureSize(uShadow, 0));
  for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) s += texture(uShadow, vec3(p.xy + vec2(float(i), float(j)) * ts, p.z - 0.0012));
  return mix(0.38, 1.0, s / 9.0);
}
void main(){
  vec3 n = normalize(vN);
  vec3 base = uColor; if (uUseTex == 1) base *= texture(uTex, vUv * uUvScale).rgb;
  float ndl = max(dot(n, -uLightDir), 0.0);
  vec3 hemi = mix(uAmbGround, uAmbSky, n.y * 0.5 + 0.5);
  vec3 v = normalize(uEye - vW); vec3 h = normalize(v - uLightDir);
  float sh = shadowTerm();
  float spec = pow(max(dot(n, h), 0.0), mix(8.0, 96.0, 1.0 - uRough)) * (1.0 - uRough) * 0.6;
  vec3 diff = base * (hemi + uLightCol * ndl * sh);
  vec3 col = mix(diff, diff * base * 2.0, uMetal * 0.6) + uLightCol * spec * sh + base * uEmis;
  float f = clamp((length(uEye - vW) - uFogNear) / (uFogFar - uFogNear), 0.0, 1.0);
  o = vec4(mix(col, uFogCol, f), uAlpha);
}
)";
static const char* kDepthVS = R"(#version 300 es
layout(location=0) in vec3 aPos; uniform mat4 uLightVP, uModel;
void main(){ gl_Position = uLightVP * uModel * vec4(aPos, 1.0); }
)";
static const char* kDepthFS = R"(#version 300 es
precision mediump float; void main(){}
)";
static const char* kSkyVS = R"(#version 300 es
out vec2 vNdc;
void main(){ vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)); vNdc = p * 2.0 - 1.0; gl_Position = vec4(vNdc, 1.0, 1.0); }
)";
static const char* kSkyFS = R"(#version 300 es
precision highp float; in vec2 vNdc; uniform mat4 uInvVP; uniform vec3 uEye, uHor, uTop; out vec4 o;
void main(){ vec4 f = uInvVP * vec4(vNdc, 1.0, 1.0); vec3 d = normalize(f.xyz / f.w - uEye);
  o = vec4(mix(uHor, uTop, pow(clamp(d.y, 0.0, 1.0), 0.55)), 1.0); }
)";
static const char* kGridVS = R"(#version 300 es
uniform mat4 uVP; uniform vec3 uEye; out vec3 vW;
void main(){ vec2 c = vec2(float(gl_VertexID & 1) * 2.0 - 1.0, float((gl_VertexID >> 1) & 1) * 2.0 - 1.0);
  vec3 w = vec3(uEye.x + c.x * 600.0, 0.02, uEye.z + c.y * 600.0); vW = w; gl_Position = uVP * vec4(w, 1.0); }
)";
static const char* kGridFS = R"(#version 300 es
precision highp float; in vec3 vW; uniform vec3 uEye; out vec4 o;
float line(float c, float cell){ float x = c / cell; float w = fwidth(x); float l = abs(fract(x - 0.5) - 0.5) / max(w, 1e-4); return 1.0 - min(l, 1.0); }
void main(){
  float minor = max(line(vW.x, 4.0), line(vW.z, 4.0));
  float major = max(line(vW.x, 20.0), line(vW.z, 20.0));
  float fade = 1.0 - clamp(length(vW.xz - uEye.xz) / 190.0, 0.0, 1.0);
  vec3 col = mix(vec3(0.30, 0.33, 0.38), vec3(0.50, 0.56, 0.66), major);
  o = vec4(col, max(minor * 0.5, major * 0.9) * fade);
}
)";

GLuint Renderer::program(const char* vs, const char* fs, const char* name) {
    auto compile = [&](GLenum t, const char* src) -> GLuint {
        GLuint s = glCreateShader(t);
        glShaderSource(s, 1, &src, nullptr);
        glCompileShader(s);
        GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
        if (!ok) { char buf[1024]; glGetShaderInfoLog(s, sizeof buf, nullptr, buf); err += std::string("shader ") + name + ": " + buf + "\n"; glDeleteShader(s); return 0; }
        return s;
    };
    GLuint v = compile(GL_VERTEX_SHADER, vs), f = compile(GL_FRAGMENT_SHADER, fs);
    if (!v || !f) return 0;
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    glDeleteShader(v); glDeleteShader(f);
    GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) { char buf[1024]; glGetProgramInfoLog(p, sizeof buf, nullptr, buf); err += std::string("link ") + name + ": " + buf + "\n"; glDeleteProgram(p); return 0; }
    return p;
}

// ------------------------------------------------------------------ mesh prosedural
bool Renderer::buildMesh(Mesh& m, const std::vector<float>& v, const std::vector<unsigned short>& idx) {
    glGenVertexArrays(1, &m.vao); glGenBuffers(1, &m.vbo); glGenBuffers(1, &m.ibo);
    glBindVertexArray(m.vao);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo); glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(v.size() * sizeof(float)), v.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(idx.size() * sizeof(unsigned short)), idx.data(), GL_STATIC_DRAW);
    const GLsizei stride = 8 * sizeof(float);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
    glBindVertexArray(0);
    m.count = (int)idx.size();
    return true;
}

namespace {
struct MB {
    std::vector<float> v; std::vector<unsigned short> i;
    void vert(Vec3 p, Vec3 n, float u, float t) { v.insert(v.end(), {p.x, p.y, p.z, n.x, n.y, n.z, u, t}); }
    unsigned short n() const { return (unsigned short)(v.size() / 8); }
    void tri(unsigned short a, unsigned short b, unsigned short c) { i.push_back(a); i.push_back(b); i.push_back(c); }
};
MB cube() {
    MB m;
    struct F { Vec3 n, u, v; } F[6] = {{{1, 0, 0}, {0, 0, -1}, {0, 1, 0}}, {{-1, 0, 0}, {0, 0, 1}, {0, 1, 0}}, {{0, 1, 0}, {1, 0, 0}, {0, 0, -1}},
                                      {{0, -1, 0}, {1, 0, 0}, {0, 0, 1}}, {{0, 0, 1}, {1, 0, 0}, {0, 1, 0}}, {{0, 0, -1}, {-1, 0, 0}, {0, 1, 0}}};
    for (auto& f : F) {
        unsigned short b = m.n();
        for (int k = 0; k < 4; k++) {
            float a = (k & 1) ? .5f : -.5f, c = (k & 2) ? .5f : -.5f;
            m.vert(f.n * .5f + f.u * a + f.v * c, f.n, a + .5f, c + .5f);
        }
        m.tri(b, b + 1, b + 3); m.tri(b, b + 3, b + 2);
    }
    return m;
}
MB sphere(int seg, int rings) {
    MB m;
    for (int r = 0; r <= rings; r++) {
        float ph = kPi * r / rings;
        for (int s = 0; s <= seg; s++) {
            float th = 2 * kPi * s / seg;
            Vec3 n(std::sin(ph) * std::cos(th), std::cos(ph), std::sin(ph) * std::sin(th));
            m.vert(n * .5f, n, (float)s / seg, (float)r / rings);
        }
    }
    for (int r = 0; r < rings; r++)
        for (int s = 0; s < seg; s++) {
            unsigned short a = (unsigned short)(r * (seg + 1) + s), b = (unsigned short)(a + seg + 1);
            m.tri(a, b, a + 1); m.tri(a + 1, b, b + 1);
        }
    return m;
}
MB cylinder(int seg) {
    MB m;
    for (int s = 0; s <= seg; s++) {
        float th = 2 * kPi * s / seg, c = std::cos(th), sn = std::sin(th);
        m.vert({c * .5f, -.5f, sn * .5f}, {c, 0, sn}, (float)s / seg, 0);
        m.vert({c * .5f, .5f, sn * .5f}, {c, 0, sn}, (float)s / seg, 1);
    }
    for (int s = 0; s < seg; s++) { unsigned short a = (unsigned short)(s * 2); m.tri(a, a + 2, a + 1); m.tri(a + 1, a + 2, a + 3); }
    for (int cap = 0; cap < 2; cap++) {
        float y = cap ? .5f : -.5f; Vec3 n(0, cap ? 1.f : -1.f, 0);
        unsigned short c0 = m.n(); m.vert({0, y, 0}, n, .5f, .5f);
        for (int s = 0; s <= seg; s++) { float th = 2 * kPi * s / seg; m.vert({std::cos(th) * .5f, y, std::sin(th) * .5f}, n, std::cos(th) * .5f + .5f, std::sin(th) * .5f + .5f); }
        for (int s = 0; s < seg; s++) { if (cap) m.tri(c0, c0 + 2 + s, c0 + 1 + s); else m.tri(c0, c0 + 1 + s, c0 + 2 + s); }
    }
    return m;
}
MB cone(int seg) {
    MB m;
    for (int s = 0; s <= seg; s++) {
        float th = 2 * kPi * s / seg, c = std::cos(th), sn = std::sin(th);
        Vec3 n = normalize({c, .5f, sn});
        m.vert({c * .5f, -.5f, sn * .5f}, n, (float)s / seg, 0);
        m.vert({0, .5f, 0}, n, (float)s / seg, 1);
    }
    for (int s = 0; s < seg; s++) { unsigned short a = (unsigned short)(s * 2); m.tri(a, a + 2, a + 1); }
    unsigned short c0 = m.n(); Vec3 n(0, -1, 0); m.vert({0, -.5f, 0}, n, .5f, .5f);
    for (int s = 0; s <= seg; s++) { float th = 2 * kPi * s / seg; m.vert({std::cos(th) * .5f, -.5f, std::sin(th) * .5f}, n, std::cos(th) * .5f + .5f, std::sin(th) * .5f + .5f); }
    for (int s = 0; s < seg; s++) m.tri(c0, c0 + 1 + s, c0 + 2 + s);
    return m;
}
}  // namespace

void Renderer::makeMeshes() {
    MB c = cube(), s = sphere(24, 16), cy = cylinder(24), co = cone(24), r = sphere(7, 5);
    buildMesh(meshes[M_CUBE], c.v, c.i); buildMesh(meshes[M_SPHERE], s.v, s.i); buildMesh(meshes[M_CYL], cy.v, cy.i);
    buildMesh(meshes[M_CONE], co.v, co.i); buildMesh(meshes[M_ROCK], r.v, r.i);
}

void Renderer::makeTextures() {
    auto make = [&](int idx, int w, int h, const std::vector<unsigned char>& px) {
        glGenTextures(1, &tex[idx]); glBindTexture(GL_TEXTURE_2D, tex[idx]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
        glGenerateMipmap(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    };
    const int N = 64;
    std::vector<unsigned char> a(N * N * 4), b(N * N * 4), c(N * N * 4);
    unsigned seed = 12345;
    for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++) {
            int k = (y * N + x) * 4;
            unsigned char ck = (((x / 8) + (y / 8)) & 1) ? 216 : 91;                          // checker
            a[k] = a[k + 1] = ck; a[k + 2] = (unsigned char)(ck + (ck > 150 ? 10 : 18)); a[k + 3] = 255;
            bool st = ((x + y) / 8) & 1;                                                       // stripes diagonal kuning-hitam
            b[k] = st ? 230 : 34; b[k + 1] = st ? 180 : 34; b[k + 2] = st ? 34 : 34; b[k + 3] = 255;
            seed = seed * 1664525u + 1013904223u; unsigned char nv = (unsigned char)(120 + ((seed >> 24) % 80));   // noise
            c[k] = c[k + 1] = c[k + 2] = nv; c[k + 3] = 255;
        }
    make(0, N, N, a); make(1, N, N, b); make(2, N, N, c);
    const int W = 256, H = 128;                                                                // container bergaris
    std::vector<unsigned char> d(W * H * 4);
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++) {
            int k = (y * W + x) * 4; bool rib = (x % 12) < 5;
            d[k] = rib ? 35 : 44; d[k + 1] = rib ? 87 : 106; d[k + 2] = rib ? 134 : 163; d[k + 3] = 255;
        }
    make(3, W, H, d);
}

bool Renderer::makeShadow() {
    glGenTextures(1, &shadowTex); glBindTexture(GL_TEXTURE_2D, shadowTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, kShadowSize, kShadowSize, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
    glGenFramebuffers(1, &shadowFbo); glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowTex, 0);
    GLenum none = GL_NONE; glDrawBuffers(1, &none); glReadBuffer(GL_NONE);
    bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (!ok) err += "framebuffer shadow tidak lengkap (shadow dimatikan)\n";
    return ok;
}

bool Renderer::init() {
    err.clear();
    lit.p = program(kLitVS, kLitFS, "lit");
    depthProg = program(kDepthVS, kDepthFS, "depth");
    skyProg = program(kSkyVS, kSkyFS, "sky");
    gridProg = program(kGridVS, kGridFS, "grid");
    if (!lit.p || !depthProg || !skyProg || !gridProg) return false;
    auto L = [&](GLuint p, const char* n) { return glGetUniformLocation(p, n); };
    lit.VP = L(lit.p, "uVP"); lit.Model = L(lit.p, "uModel"); lit.Nrm = L(lit.p, "uNrm"); lit.LightVP = L(lit.p, "uLightVP");
    lit.Color = L(lit.p, "uColor"); lit.Rough = L(lit.p, "uRough"); lit.Metal = L(lit.p, "uMetal"); lit.Alpha = L(lit.p, "uAlpha");
    lit.Emis = L(lit.p, "uEmis"); lit.UseTex = L(lit.p, "uUseTex"); lit.UvScale = L(lit.p, "uUvScale"); lit.Eye = L(lit.p, "uEye");
    lit.LightDir = L(lit.p, "uLightDir"); lit.LightCol = L(lit.p, "uLightCol"); lit.AmbSky = L(lit.p, "uAmbSky"); lit.AmbGround = L(lit.p, "uAmbGround");
    lit.FogCol = L(lit.p, "uFogCol"); lit.FogNear = L(lit.p, "uFogNear"); lit.FogFar = L(lit.p, "uFogFar"); lit.ShadowOn = L(lit.p, "uShadowOn");
    lit.Tex = L(lit.p, "uTex"); lit.Shadow = L(lit.p, "uShadow");
    depthVP = L(depthProg, "uLightVP"); depthModel = L(depthProg, "uModel");
    skyInv = L(skyProg, "uInvVP"); skyEye = L(skyProg, "uEye"); skyHor = L(skyProg, "uHor"); skyTop = L(skyProg, "uTop");
    gridVP = L(gridProg, "uVP"); gridEye = L(gridProg, "uEye");
    makeMeshes(); makeTextures(); makeShadow();
    glGenVertexArrays(1, &emptyVao);
    return true;
}

void Renderer::shutdown() {
    for (auto& m : meshes) { glDeleteVertexArrays(1, &m.vao); glDeleteBuffers(1, &m.vbo); glDeleteBuffers(1, &m.ibo); m = Mesh(); }
    glDeleteTextures(4, tex); glDeleteTextures(1, &shadowTex); glDeleteFramebuffers(1, &shadowFbo);
    glDeleteProgram(lit.p); glDeleteProgram(depthProg); glDeleteProgram(skyProg); glDeleteProgram(gridProg);
    glDeleteVertexArrays(1, &emptyVao);
}

// ------------------------------------------------------------------ render target
bool RenderTarget::resize(int nw, int nh) {
    if (nw < 8 || nh < 8) return false;
    if (nw == w && nh == h && fbo) return true;
    destroy();
    w = nw; h = nh;
    glGenTextures(1, &color); glBindTexture(GL_TEXTURE_2D, color);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenRenderbuffers(1, &depth); glBindRenderbuffer(GL_RENDERBUFFER, depth);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, w, h);
    glGenFramebuffers(1, &fbo); glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, color, 0);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depth);
    bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    return ok;
}
void RenderTarget::destroy() {
    if (fbo) glDeleteFramebuffers(1, &fbo);
    if (color) glDeleteTextures(1, &color);
    if (depth) glDeleteRenderbuffers(1, &depth);
    fbo = color = depth = 0; w = h = 0;
}

// ------------------------------------------------------------------ definisi model komposit
const std::vector<Renderer::Part>& Renderer::parts(Kind k) const {
    static const Vec3 Z(0, 0, 0), O(1, 1, 1);
    static const std::vector<Part> cubeP = {{M_CUBE, Z, O, Z, true, O, 0}}, sphereP = {{M_SPHERE, Z, O, Z, true, O, 0}},
        cylP = {{M_CYL, Z, O, Z, true, O, 0}}, coneP = {{M_CONE, Z, O, Z, true, O, 0}}, rockP = {{M_ROCK, Z, O, Z, true, O, 0}},
        treeP = {{M_CYL, {0, -.325f, 0}, {.16f, .35f, .16f}, Z, false, {.35f, .27f, .19f}, 0}, {M_CONE, {0, .15f, 0}, {.9f, .7f, .9f}, Z, true, O, 0}},
        houseP = {{M_CUBE, {0, -.15f, 0}, {1, .7f, 1}, Z, true, O, 0}, {M_CUBE, {0, .25f, 0}, {1.08f, .1f, 1.08f}, Z, false, {.37f, .35f, .33f}, 0}},
        poleP = {{M_CUBE, Z, {.04f, 1, .04f}, Z, true, O, 0}, {M_CUBE, {0, .42f, 0}, {.4f, .03f, .03f}, Z, true, O, 0}},
        barrelP = {{M_CYL, Z, O, Z, true, O, 0}, {M_CYL, {0, .3f, 0}, {1.04f, .06f, 1.04f}, Z, false, {.17f, .17f, .17f}, 0}},
        tankP = {{M_CYL, Z, O, {90, 0, 0}, true, O, 0}}, containerP = {{M_CUBE, Z, O, Z, true, O, 4}};
    switch (k) {
        case Kind::Block: case Kind::Floor: case Kind::Spawn: case Kind::Crate: return cubeP;
        case Kind::Sphere: return sphereP; case Kind::Cylinder: return cylP; case Kind::Cone: return coneP; case Kind::Rock: return rockP;
        case Kind::Tree: return treeP; case Kind::House: return houseP; case Kind::Pole: return poleP; case Kind::Barrel: return barrelP;
        case Kind::Tank: return tankP; case Kind::Container: return containerP;
        default: return empty;
    }
}

void Renderer::drawMesh(int m) {
    glBindVertexArray(meshes[m].vao);
    glDrawElements(GL_TRIANGLES, meshes[m].count, GL_UNSIGNED_SHORT, nullptr);
}

void Renderer::drawPart(const Mat4& base, const Part& p, const Entity* e, bool shadowPass, float alpha) {
    Mat4 model = base * Mat4::trs(p.pos, p.rot, p.scale);
    if (shadowPass) { glUniformMatrix4fv(depthModel, 1, GL_FALSE, model.m); drawMesh(p.mesh); return; }
    Mat4 inv = model.inverse();
    float n3[9];
    for (int col = 0; col < 3; col++) for (int row = 0; row < 3; row++) n3[col * 3 + row] = inv.m[row * 4 + col];   // inverse-transpose
    glUniformMatrix4fv(lit.Model, 1, GL_FALSE, model.m);
    glUniformMatrix3fv(lit.Nrm, 1, GL_FALSE, n3);
    Vec3 c = (p.tint && e) ? e->color : p.color;
    float rough = .6f, metal = 0.f, emis = 0.f;
    int texIdx = p.texIdx;
    if (e && p.tint) {
        const MatInfo& mi = matInfo(e->mat);
        rough = mi.rough; metal = std::max(mi.metal, e->reflectance); emis = e->mat == MatType::Neon ? .9f : 0.f;
        if (e->tex >= 1 && e->tex <= 3) texIdx = e->tex;
    }
    glUniform3f(lit.Color, c.x, c.y, c.z);
    glUniform1f(lit.Rough, rough); glUniform1f(lit.Metal, metal); glUniform1f(lit.Alpha, alpha); glUniform1f(lit.Emis, emis);
    if (texIdx > 0) {
        glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, tex[texIdx - 1]);
        float k = (texIdx == 4 || !e) ? 1.f : std::max(1.f, std::max(e->scale.x, e->scale.z) * .5f);
        glUniform1i(lit.UseTex, 1); glUniform2f(lit.UvScale, k, k);
    } else glUniform1i(lit.UseTex, 0);
    drawMesh(p.mesh);
}

void Renderer::drawEntities(const Scene& s, bool shadowPass, bool transparent) {
    for (auto& e : s.entities) {
        if (!e.visible || !kindInfo(e.kind).geometry) continue;
        bool isT = e.transparency > .001f;
        if (shadowPass) { if (!e.castShadow || isT || e.kind == Kind::Spawn) continue; }
        else if (isT != transparent) continue;
        Mat4 w = s.world(e.id);
        for (auto& p : parts(e.kind)) drawPart(w, p, &e, shadowPass, 1.f - e.transparency);
    }
}

void Renderer::drawPlayer(const RenderOpts& o, bool shadowPass) {
    if (!o.player) return;
    Mat4 base = Mat4::translate(o.playerPos) * Mat4::rotY(o.playerYaw);
    Part body{M_CYL, {0, .7f, 0}, {.9f, 1.4f, .9f}, {0, 0, 0}, false, {.23f, .51f, .96f}, 0};
    Part head{M_SPHERE, {0, 1.65f, 0}, {.8f, .8f, .8f}, {0, 0, 0}, false, {1.f, .85f, .69f}, 0};
    drawPart(base, body, nullptr, shadowPass, 1.f); drawPart(base, head, nullptr, shadowPass, 1.f);
}

// ------------------------------------------------------------------ render utama
void Renderer::render(const Scene& scene, const Camera& cam, RenderTarget& rt, const RenderOpts& opt) {
    if (!rt.fbo) return;
    const Lighting& L = scene.lighting;
    float a = (L.clockTime - 6.f) / 12.f * kPi, day = std::max(0.f, std::sin(a));
    Vec3 toSun = normalize({std::cos(a) * .8f, std::max(.25f, std::sin(a)), .45f});
    float inten = (.15f + 1.f * day) * L.brightness, ambK = (.25f + .6f * day) * L.brightness;
    Vec3 lightCol = Vec3(1.f, .94f, .84f) * inten, ambSky = L.ambient * ambK, ambGround = L.ambient * (ambK * .35f);
    float aspect = (float)rt.w / (float)rt.h;
    Mat4 vp = cam.viewProj(aspect);
    bool shadowOn = L.shadows && shadowFbo;

    // 1) shadow map
    if (shadowOn) {
        float S = clampf(length(cam.eye - cam.target) * 1.6f, 25.f, 80.f);
        lightVP = Mat4::ortho(-S, S, -S, S, 1.f, 260.f) * Mat4::lookAt(cam.target + toSun * 100.f, cam.target, {0, 1, 0});
        glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo);
        glViewport(0, 0, kShadowSize, kShadowSize);
        glDepthMask(GL_TRUE); glEnable(GL_DEPTH_TEST); glDisable(GL_BLEND); glDisable(GL_CULL_FACE); glDisable(GL_SCISSOR_TEST);
        glClear(GL_DEPTH_BUFFER_BIT);
        glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(2.f, 4.f);
        glUseProgram(depthProg);
        glUniformMatrix4fv(depthVP, 1, GL_FALSE, lightVP.m);
        drawEntities(scene, true, false);
        drawPlayer(opt, true);
        glDisable(GL_POLYGON_OFFSET_FILL);
    }

    // 2) pass utama ke render target
    glBindFramebuffer(GL_FRAMEBUFFER, rt.fbo);
    glViewport(0, 0, rt.w, rt.h);
    glDisable(GL_SCISSOR_TEST); glDisable(GL_CULL_FACE);
    glDepthMask(GL_TRUE); glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL);
    glClearColor(.81f, .835f, .862f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glDisable(GL_DEPTH_TEST);                                   // langit
    glUseProgram(skyProg);
    Mat4 inv = vp.inverse();
    glUniformMatrix4fv(skyInv, 1, GL_FALSE, inv.m);
    glUniform3f(skyEye, cam.eye.x, cam.eye.y, cam.eye.z);
    glUniform3f(skyHor, .81f * ambK * 1.2f, .835f * ambK * 1.2f, .862f * ambK * 1.2f);
    glUniform3f(skyTop, .49f * ambK * 1.2f, .56f * ambK * 1.2f, .66f * ambK * 1.2f);
    glBindVertexArray(emptyVao); glDrawArrays(GL_TRIANGLES, 0, 3);
    glEnable(GL_DEPTH_TEST);

    glUseProgram(lit.p);                                         // uniform per-frame
    glUniformMatrix4fv(lit.VP, 1, GL_FALSE, vp.m);
    glUniformMatrix4fv(lit.LightVP, 1, GL_FALSE, lightVP.m);
    glUniform3f(lit.Eye, cam.eye.x, cam.eye.y, cam.eye.z);
    glUniform3f(lit.LightDir, -toSun.x, -toSun.y, -toSun.z);
    glUniform3f(lit.LightCol, lightCol.x, lightCol.y, lightCol.z);
    glUniform3f(lit.AmbSky, ambSky.x, ambSky.y, ambSky.z);
    glUniform3f(lit.AmbGround, ambGround.x, ambGround.y, ambGround.z);
    glUniform3f(lit.FogCol, .81f * ambK * 1.2f, .835f * ambK * 1.2f, .862f * ambK * 1.2f);
    glUniform1f(lit.FogNear, 40.f); glUniform1f(lit.FogFar, std::max(60.f, L.fogEnd));
    glUniform1f(lit.ShadowOn, shadowOn ? 1.f : 0.f);
    glUniform1i(lit.Tex, 0); glUniform1i(lit.Shadow, 1);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, shadowTex); glActiveTexture(GL_TEXTURE0);

    Part ground{M_CUBE, {0, -.05f, 0}, {2000.f, .1f, 2000.f}, {0, 0, 0}, false, {.23f, .24f, .26f}, 0};   // lantai dunia
    drawPart(Mat4::identity(), ground, nullptr, false, 1.f);

    if (opt.grid) {                                              // grid 4 m + garis tebal tiap 20 m
        glUseProgram(gridProg);
        glUniformMatrix4fv(gridVP, 1, GL_FALSE, vp.m);
        glUniform3f(gridEye, cam.eye.x, cam.eye.y, cam.eye.z);
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
        glBindVertexArray(emptyVao); glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        glDepthMask(GL_TRUE); glDisable(GL_BLEND);
        glUseProgram(lit.p);
    }

    drawEntities(scene, false, false);
    drawPlayer(opt, false);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_FALSE);
    drawEntities(scene, false, true);
    glDepthMask(GL_TRUE); glDisable(GL_BLEND);

    glBindVertexArray(0); glUseProgram(0);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, 0); glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, 0);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

}  // namespace kyzn
