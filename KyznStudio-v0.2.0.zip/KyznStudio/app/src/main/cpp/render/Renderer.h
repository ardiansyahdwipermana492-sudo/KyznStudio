// KyznStudio - renderer OpenGL ES 3.0: shadow map PCF, fog, sky, grid, texture prosedural
#pragma once
#include <GLES3/gl3.h>
#include <string>
#include <vector>
#include "../core/Camera.h"
#include "../core/Scene.h"

namespace kyzn {

struct RenderTarget {
    GLuint fbo = 0, color = 0, depth = 0;
    int w = 0, h = 0;
    bool resize(int nw, int nh);
    void destroy();
    void forget() { fbo = color = depth = 0; w = h = 0; }   // konteks GL hilang: lepas id tanpa memanggil GL
};

struct RenderOpts {
    bool grid = true;
    bool player = false;
    Vec3 playerPos;
    float playerYaw = 0;
};

class Renderer {
public:
    bool init();
    void shutdown();
    void render(const Scene& scene, const Camera& cam, RenderTarget& rt, const RenderOpts& opt);
    GLuint textureId(int index) const { return (index >= 1 && index <= 4) ? tex[index - 1] : 0; }   // 1..3 preset, 4 = container
    const std::string& error() const { return err; }

private:
    struct Mesh { GLuint vao = 0, vbo = 0, ibo = 0; int count = 0; };
    struct Lit {
        GLuint p = 0;
        GLint VP, Model, Nrm, LightVP, Color, Rough, Metal, Alpha, Emis, UseTex, UvScale, Eye, LightDir, LightCol, AmbSky, AmbGround, FogCol, FogNear, FogFar, ShadowOn, Tex, Shadow;
    };
    enum { M_CUBE, M_SPHERE, M_CYL, M_CONE, M_ROCK, M_COUNT };
    struct Part { int mesh; Vec3 pos, scale, rot; bool tint; Vec3 color; int texIdx; };

    bool buildMesh(Mesh& m, const std::vector<float>& v, const std::vector<unsigned short>& i);
    void makeMeshes();
    void makeTextures();
    bool makeShadow();
    GLuint program(const char* vs, const char* fs, const char* name);
    void drawMesh(int m);
    void drawEntities(const Scene& s, bool shadowPass, bool transparent);
    void drawPlayer(const RenderOpts& o, bool shadowPass);
    void drawPart(const Mat4& model, const Part& p, const Entity* e, bool shadowPass, float alpha);
    const std::vector<Part>& parts(Kind k) const;

    Mesh meshes[M_COUNT];
    Lit lit;
    GLuint depthProg = 0, skyProg = 0, gridProg = 0, emptyVao = 0;
    GLint depthVP = 0, depthModel = 0;
    GLint skyInv = 0, skyEye = 0, skyHor = 0, skyTop = 0, gridVP = 0, gridEye = 0;
    GLuint tex[4] = {0, 0, 0, 0}, shadowTex = 0, shadowFbo = 0;
    static constexpr int kShadowSize = 2048;
    Mat4 lightVP = Mat4::identity();
    std::string err;
    std::vector<Part> empty;
};

}  // namespace kyzn
