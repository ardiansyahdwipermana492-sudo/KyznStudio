// KyznStudio - runtime game (APK hasil publish): memuat game/main.scene.json lalu memainkannya layar penuh
#pragma once
#include <map>
#include <string>
#include <vector>
#include "../core/Game.h"
#include "../core/Project.h"
#include "../render/Renderer.h"
#include "Editor.h"

namespace kyzn {

class Runtime {
public:
    bool load(const std::string& sceneJson, const std::string& publishJson, std::string& err);
    void attach(Renderer* r) { rd = r; }
    void releaseGL() { rt.destroy(); rd = nullptr; }
    void frame(float dt, const Touch& t, float W, float H, float ui);
    const PublishSettings& settings() const { return pub; }

private:
    Scene scene;
    GameSession game;
    PublishSettings pub;
    Renderer* rd = nullptr;
    RenderTarget rt;
    std::map<int, float> lookPrev;
    std::vector<std::string> logs;
    bool started = false;
};

}  // namespace kyzn
