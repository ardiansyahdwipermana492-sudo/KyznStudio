// KyznStudio - editor (ImGui): Scene View, Hierarchy, Inspector, Project, Console, Game Preview, Publish
#pragma once
#include <functional>
#include <map>
#include <string>
#include <vector>
#include "../core/Camera.h"
#include "../core/Game.h"
#include "../core/Project.h"
#include "../render/Renderer.h"

namespace kyzn {

struct Touch { int count = 0; int id[5] = {}; float x[5] = {}, y[5] = {}; };   // multi-touch mentah (piksel layar)

struct Platform {
    std::function<void(const std::string&)> setClipboard;   // clipboard sistem (JNI)
    std::function<void(const std::string&)> sfx;            // efek suara (opsional)
    std::string dataDir;                                     // folder data app (autosave, export)
    float ui = 1.f;                                          // skala UI (dp)
};

struct View;   // info viewport Scene View per-frame (internal)

class Editor {
public:
    explicit Editor(Platform& p);
    void attach(Renderer* r) { rd = r; }
    void releaseGL();                                        // panggil saat konteks GL masih aktif, sebelum dihancurkan
    void style();                                            // panggil setelah ImGui::CreateContext() dan font dimuat
    void frame(float dt, const Touch& t, float dispW, float dispH);
    bool save(const std::string& path);
    bool load(const std::string& path);
    void autosave();
    void autoload();
    void log(const std::string& s);

private:
    friend struct View;
    Platform& pf;
    Renderer* rd = nullptr;
    Scene scene;
    History hist;
    GameSession game;
    OrbitCamera orbit;
    PublishSettings pub;
    RenderTarget svRT, gameRT;
    std::vector<int> sel;
    bool selLighting = false;
    int tool = 0;                                            // 0 pilih, 1 geser, 2 skala, 3 putar, 4 tangan
    bool snap = true, grid = true, stats = false;
    bool playing = false, paused = false, stepReq = false;
    std::string snapshot, preEdit;
    bool edited = false;
    std::vector<std::string> logs;
    std::vector<Entity> prefabs;
    std::vector<Kind> imported;
    std::string clipJson;
    bool showHier = true, showInsp = true, showProj = false, showGame = false, showStore = false, showScript = false, showPublish = false;
    int projDir = 3, projTab = 0;
    bool projGrid = true;
    int scriptId = 0, scriptBufId = -1;
    char hierSearch[64] = "", projSearch[64] = "";
    char scriptBuf[32768] = "";
    char bufName[64] = "", bufPkg[96] = "", bufVer[32] = "";
    std::vector<Issue> issues;
    std::vector<std::string> exportMsgs;
    float menuH = 0, transH = 0, statH = 0, fps = 60, fpsAcc = 0;
    int fpsN = 0;
    float ui() const { return pf.ui; }
    // interaksi viewport
    enum class Drag { None, Orbit, Joystick, Move, Scale, Rotate, Plane, Pan, Up, Down } drag = Drag::None;
    int dragAxis = -1;
    float dragMoved = 0, lastPinch = -1;
    float pressX = 0, pressY = 0, joyX = 0, joyY = 0;
    Vec3 dragStartPos, dragStartRot, dragStartScale, dragStartWorld, dragAxisDir, dragPlaneOffset;
    float dragAxisLen = 1;
    float dragAx = 0, dragAy = 0;                            // arah sumbu di layar (piksel) saat mulai
    GameInput gi;
    std::map<int, float> lookPrev;
    bool gameJoy = false;

    // util
    Entity* primary() { return sel.empty() ? nullptr : scene.find(sel[0]); }
    bool isSel(int id) const;
    void select(const std::vector<int>& ids);
    void markEdit();
    void commit();
    int createKind(Kind k);
    void deleteSel();
    void copySel();
    void pasteSel();
    void groupSel();
    void duplicateSel();
    void undoOp();
    void redoOp();
    void startPlay();
    void stopPlay();
    Camera gameCamera() const;
    // UI
    void drawMenu();
    void drawTransport(float dispW);
    void drawSceneView(float dt, const Touch& t, float dispW, float dispH);
    void drawHierarchy();
    void hierNode(int id);
    void drawInspector();
    void drawProject();
    void drawGame(const Touch& t);
    void drawStore();
    void drawScript();
    void drawPublish();
    void drawStatus(float dispW, float dispH);
    void viewInput(const View& v, bool pressed, bool active, const Touch& t, float dt);
    void drawGizmo(const View& v);
    int pick(const View& v, float mx, float my) const;
    void doDrag(const View& v, float mx, float my, float dx, float dy);
};

}  // namespace kyzn
