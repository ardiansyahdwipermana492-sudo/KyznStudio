#include "Editor.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "imgui.h"

namespace kyzn {

// ============================================================ helper kecil
static ImVec2 V(float x, float y) { return ImVec2(x, y); }
static ImVec4 C(float r, float g, float b, float a = 1.f) { return ImVec4(r, g, b, a); }
static float distSeg(float px, float py, ImVec2 a, ImVec2 b) {
    float vx = b.x - a.x, vy = b.y - a.y, wx = px - a.x, wy = py - a.y, l2 = vx * vx + vy * vy;
    float t = l2 > 1e-6f ? std::max(0.f, std::min(1.f, (wx * vx + wy * vy) / l2)) : 0.f;
    float dx = px - (a.x + vx * t), dy = py - (a.y + vy * t);
    return std::sqrt(dx * dx + dy * dy);
}
static void touchScroll() {      // geser konten dengan jari (title bar tetap untuk memindah jendela)
    if (ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows) && ImGui::IsMouseDragging(0, 6.f) && !ImGui::IsAnyItemActive())
        ImGui::SetScrollY(ImGui::GetScrollY() - ImGui::GetIO().MouseDelta.y);
}
static const char* kTemplateLua =
    "-- Berjalan saat Play. API: find(nama) getpos setpos move getrot setrot rotate setscale setcolor\n"
    "-- setvisible destroy input() player() time() sfx(nama) print(...)   Hook: onStart(), onUpdate(dt)\n"
    "local blok = find(\"Block\")\n\n"
    "function onStart()\n  print(\"Game mulai!\")\nend\n\n"
    "function onUpdate(dt)\n  if blok then rotate(blok, 0, 90 * dt, 0) end\nend\n";
static const char* kBaseKinds[] = {"Block", "Sphere", "Cylinder", "Cone", "Floor", "Spawn"};
struct Pack { const char* name; const char* desc; std::vector<Kind> kinds; };
static const std::vector<Pack>& packs() {
    static const std::vector<Pack> P = {{"Nature Pack", "Pohon dan batu", {Kind::Tree, Kind::Rock}},
                                        {"City Pack", "Rumah, tiang listrik, peti, drum", {Kind::House, Kind::Pole, Kind::Crate, Kind::Barrel}},
                                        {"Industrial Pack", "Tangki dan container", {Kind::Tank, Kind::Container}}};
    return P;
}
static const char* kMats[] = {"Plastic", "Metal", "Wood", "Grass", "Concrete", "Neon"};
static const char* kTex[] = {"None", "Checker", "Stripes", "Noise"};
static const char* kAnim[] = {"none", "spin", "bob", "patrol"};
static const char* kTags[] = {"Untagged", "Player", "Enemy", "Item", "Respawn"};
static const char* kLayers[] = {"Default", "Ground", "Water", "UI", "Player"};
static int indexOf(const char* const* arr, int n, const std::string& v) { for (int i = 0; i < n; i++) if (v == arr[i]) return i; return 0; }
#define ARR(a) ((int)(sizeof(a) / sizeof((a)[0])))

struct View { ImVec2 p, sz; Camera cam; Mat4 vp; float aspect = 1; };
static bool toScreen(const View& v, const Vec3& w, ImVec2& o) {
    Vec2 s; if (!projectToScreen(v.vp, w, v.sz.x, v.sz.y, s)) return false;
    o = V(v.p.x + s.x, v.p.y + s.y); return true;
}

// ============================================================ umum
Editor::Editor(Platform& p) : pf(p) {
    std::snprintf(bufName, sizeof bufName, "%s", pub.appName.c_str());
    std::snprintf(bufPkg, sizeof bufPkg, "%s", pub.package.c_str());
    std::snprintf(bufVer, sizeof bufVer, "%s", pub.versionName.c_str());
}
void Editor::releaseGL() { svRT.destroy(); gameRT.destroy(); rd = nullptr; }
void Editor::log(const std::string& s) { logs.push_back(s); if (logs.size() > 300) logs.erase(logs.begin(), logs.begin() + 50); }
bool Editor::isSel(int id) const { return std::find(sel.begin(), sel.end(), id) != sel.end(); }
void Editor::select(const std::vector<int>& ids) { sel = ids; selLighting = false; scriptBufId = -1; }
void Editor::markEdit() { if (!edited && !preEdit.empty() && !playing) { hist.push(preEdit); edited = true; } }
void Editor::commit() { if (playing) return; hist.push(scene.toJson().dump()); edited = true; }

void Editor::style() {
    ImGuiStyle& s = ImGui::GetStyle();
    s = ImGuiStyle();
    ImGui::StyleColorsDark();
    s.WindowPadding = V(14, 12); s.FramePadding = V(12, 9); s.ItemSpacing = V(12, 10); s.ItemInnerSpacing = V(8, 6);
    s.IndentSpacing = 22; s.ScrollbarSize = 18; s.GrabMinSize = 22; s.TouchExtraPadding = V(4, 4);
    s.WindowRounding = 12; s.ChildRounding = 10; s.FrameRounding = 8; s.PopupRounding = 10; s.ScrollbarRounding = 9; s.GrabRounding = 8; s.TabRounding = 8;
    s.WindowBorderSize = 1; s.FrameBorderSize = 0; s.PopupBorderSize = 1; s.WindowTitleAlign = V(0.f, .5f);
    s.ScaleAllSizes(pf.ui);
    ImVec4* c = s.Colors;
    c[ImGuiCol_Text] = C(.90f, .93f, .98f); c[ImGuiCol_TextDisabled] = C(.55f, .64f, .78f);
    c[ImGuiCol_WindowBg] = C(.06f, .11f, .21f, .97f); c[ImGuiCol_ChildBg] = C(.04f, .08f, .16f, 1.f); c[ImGuiCol_PopupBg] = C(.09f, .16f, .30f, .99f);
    c[ImGuiCol_Border] = C(.13f, .21f, .39f); c[ImGuiCol_FrameBg] = C(.04f, .07f, .15f); c[ImGuiCol_FrameBgHovered] = C(.09f, .16f, .30f); c[ImGuiCol_FrameBgActive] = C(.12f, .21f, .40f);
    c[ImGuiCol_TitleBg] = C(.08f, .15f, .30f); c[ImGuiCol_TitleBgActive] = C(.10f, .19f, .38f); c[ImGuiCol_TitleBgCollapsed] = C(.06f, .11f, .21f);
    c[ImGuiCol_MenuBarBg] = C(.05f, .09f, .19f);
    c[ImGuiCol_Button] = C(.10f, .18f, .34f); c[ImGuiCol_ButtonHovered] = C(.17f, .30f, .55f); c[ImGuiCol_ButtonActive] = C(.18f, .45f, .90f);
    c[ImGuiCol_Header] = C(.11f, .31f, .61f); c[ImGuiCol_HeaderHovered] = C(.15f, .38f, .72f); c[ImGuiCol_HeaderActive] = C(.18f, .45f, .90f);
    c[ImGuiCol_CheckMark] = C(.35f, .68f, 1.f); c[ImGuiCol_SliderGrab] = C(.25f, .58f, 1.f); c[ImGuiCol_SliderGrabActive] = C(.40f, .70f, 1.f);
    c[ImGuiCol_Tab] = C(.09f, .17f, .33f); c[ImGuiCol_TabHovered] = C(.18f, .45f, .90f);
    c[ImGuiCol_ResizeGrip] = C(.25f, .58f, 1.f, .45f); c[ImGuiCol_ResizeGripHovered] = C(.25f, .58f, 1.f, .8f); c[ImGuiCol_ResizeGripActive] = C(.35f, .68f, 1.f);
    c[ImGuiCol_Separator] = C(.13f, .21f, .39f); c[ImGuiCol_ScrollbarBg] = C(.04f, .07f, .15f, .6f); c[ImGuiCol_ScrollbarGrab] = C(.20f, .34f, .60f);
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigWindowsMoveFromTitleBarOnly = true;     // seret isi = scroll, seret judul = pindah jendela
    io.IniFilename = nullptr;
}

int Editor::createKind(Kind k) {
    commit();
    int id = scene.create(k);
    Entity* e = scene.find(id);
    if (kindInfo(k).geometry) {
        e->pos = {snap ? std::round(orbit.target.x * 2) / 2 : orbit.target.x, e->scale.y * .5f, snap ? std::round(orbit.target.z * 2) / 2 : orbit.target.z};
        if (k == Kind::Spawn) e->pos.y = .2f;
    }
    if (k == Kind::Script) e->code = kTemplateLua;
    select({id});
    return id;
}
void Editor::deleteSel() {
    if (sel.empty()) return;
    commit();
    for (int id : sel) scene.destroy(id);
    sel.clear();
}
void Editor::copySel() {
    Json arr = Json::array();
    Scene tmp;
    for (int id : sel) {
        const Entity* e = scene.find(id); if (!e) continue;
        tmp.entities.push_back(*e); tmp.entities.back().parent = 0;
    }
    clipJson = tmp.toJson().dump();
    log("[editor] " + std::to_string(tmp.entities.size()) + " object disalin");
}
void Editor::pasteSel() {
    Json j; Scene tmp;
    if (clipJson.empty() || !Json::parse(clipJson, j) || !tmp.fromJson(j)) { log("[editor] clipboard kosong"); return; }
    commit();
    std::vector<int> ids;
    for (auto& e : tmp.entities) {
        Entity c = e; c.id = scene.nextId++; c.name = scene.uniqueName(e.name); c.parent = 0; c.attached = 0;
        c.pos.x += 2; c.pos.z += 2;
        scene.entities.push_back(c); ids.push_back(c.id);
    }
    select(ids);
}
void Editor::groupSel() {
    if (sel.size() < 2) { log("[editor] pilih minimal 2 object (tombol All) untuk Group"); return; }
    commit();
    int g = scene.group(sel);
    if (g) select({g}); else log("[editor] Group gagal: hanya object tanpa parent yang bisa digrup");
}
void Editor::duplicateSel() {
    if (sel.empty()) return;
    commit();
    std::vector<int> ids;
    for (int id : sel) if (int d = scene.duplicate(id)) ids.push_back(d);
    select(ids);
}
void Editor::undoOp() { if (playing) return; if (hist.undo(scene)) { sel.erase(std::remove_if(sel.begin(), sel.end(), [&](int i) { return !scene.find(i); }), sel.end()); log("[editor] undo"); } }
void Editor::redoOp() { if (playing) return; if (hist.redo(scene)) { sel.erase(std::remove_if(sel.begin(), sel.end(), [&](int i) { return !scene.find(i); }), sel.end()); log("[editor] redo"); } }

void Editor::startPlay() {
    if (playing) return;
    snapshot = scene.toJson().dump();
    log("[play] mulai");
    game.start(scene, [this](const std::string& m) { log(m); }, [this](const std::string& m) { log("[sfx] " + m); if (pf.sfx) pf.sfx(m); });
    playing = true; paused = false; showGame = true;
}
void Editor::stopPlay() {
    if (!playing) return;
    game.stop();
    Json j;
    if (Json::parse(snapshot, j)) scene.fromJson(j);
    playing = false; paused = false;
    sel.erase(std::remove_if(sel.begin(), sel.end(), [&](int i) { return !scene.find(i); }), sel.end());
    log("[play] berhenti, scene dikembalikan");
}
Camera Editor::gameCamera() const {
    if (playing) { CamPose p = game.camera(); Camera c; c.eye = p.eye; c.target = p.target; return c; }
    Vec3 base(0, 0, 0);
    for (auto& e : scene.entities) { Vec3 mn, mx; if (e.kind == Kind::Spawn && scene.worldBounds(e.id, mn, mx)) { base = {(mn.x + mx.x) * .5f, mx.y, (mn.z + mx.z) * .5f}; break; } }
    Camera c; c.target = base + Vec3(0, 1.2f, 0); c.eye = base + Vec3(std::sin(.9f) * 9.f, 5.f, std::cos(.9f) * 9.f); return c;
}

// ============================================================ menu & transport
void Editor::drawMenu() {
    if (!ImGui::BeginMainMenuBar()) return;
    menuH = ImGui::GetWindowHeight();
    if (ImGui::BeginMenu("File")) {
        if (ImGui::MenuItem("Scene Baru")) { if (!playing) { commit(); scene = Scene(); sel.clear(); log("[file] scene baru"); } }
        if (ImGui::MenuItem("Simpan")) { autosave(); log("[file] tersimpan"); }
        if (ImGui::MenuItem("Muat")) { autoload(); log("[file] dimuat"); }
        ImGui::Separator();
        if (ImGui::MenuItem("Publish / Build Settings...")) showPublish = true;
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Edit")) {
        if (ImGui::MenuItem("Undo", nullptr, false, hist.undoSize() > 0)) undoOp();
        if (ImGui::MenuItem("Redo", nullptr, false, hist.redoSize() > 0)) redoOp();
        ImGui::Separator();
        if (ImGui::MenuItem("Duplicate")) duplicateSel();
        if (ImGui::MenuItem("Copy")) copySel();
        if (ImGui::MenuItem("Paste")) pasteSel();
        if (ImGui::MenuItem("Group")) groupSel();
        if (ImGui::MenuItem("Delete")) deleteSel();
        if (ImGui::MenuItem("Select All")) { sel.clear(); for (auto& e : scene.entities) if (kindInfo(e.kind).geometry) sel.push_back(e.id); }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("View")) {
        ImGui::MenuItem("Hierarchy", nullptr, &showHier); ImGui::MenuItem("Inspector", nullptr, &showInsp);
        ImGui::MenuItem("Project / Console", nullptr, &showProj); ImGui::MenuItem("Game Preview", nullptr, &showGame);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("GameObject")) {
        for (const char* n : kBaseKinds) { Kind k; if (kindFromName(n, k) && ImGui::MenuItem(n)) createKind(k); }
        for (Kind k : imported) if (ImGui::MenuItem(kindInfo(k).name)) createKind(k);
        ImGui::Separator();
        if (ImGui::MenuItem("Group Selected")) groupSel();
        if (ImGui::MenuItem("Sound")) createKind(Kind::Sound);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Component")) {
        if (ImGui::MenuItem("Add Script")) { int id = createKind(Kind::Script); scriptId = id; showScript = true; }
        if (ImGui::MenuItem("Script Editor...")) showScript = true;
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Tools")) {
        ImGui::MenuItem("Grid Snap", nullptr, &snap); ImGui::MenuItem("Tampilkan Grid", nullptr, &grid); ImGui::MenuItem("Statistik", nullptr, &stats);
        if (ImGui::MenuItem("Fokus ke Object")) { if (Entity* e = primary()) orbit.target = scene.world(e->id).position(); }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Window")) {
        ImGui::MenuItem("Asset Store", nullptr, &showStore); ImGui::MenuItem("Script Editor", nullptr, &showScript); ImGui::MenuItem("Publish", nullptr, &showPublish);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Help")) {
        ImGui::TextWrapped("Tap object: pilih. Alat Geser/Skala/Putar: tarik gizmo. Cubit: zoom. Joystick kiri bawah: gerak kamera.");
        ImGui::EndMenu();
    }
    ImGui::EndMainMenuBar();
}

void Editor::drawTransport(float W) {
    float h = transH > 1 ? transH : ImGui::GetFrameHeight() * 1.9f;
    ImGui::SetNextWindowPos(V(0, menuH)); ImGui::SetNextWindowSize(V(W, h));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, C(.05f, .09f, .19f, 1.f));
    ImGui::Begin("##transport", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_HorizontalScrollbar);
    if (playing) ImGui::PushStyleColor(ImGuiCol_Button, C(.78f, .22f, .22f)); else ImGui::PushStyleColor(ImGuiCol_Button, C(.12f, .38f, .80f));
    if (ImGui::Button(playing ? "Stop" : "Play")) { if (playing) stopPlay(); else startPlay(); }
    ImGui::PopStyleColor();
    ImGui::SameLine();
    if (paused) ImGui::PushStyleColor(ImGuiCol_Button, C(.70f, .47f, .12f));
    if (ImGui::Button("Pause") && playing) paused = !paused;
    if (paused) ImGui::PopStyleColor();
    ImGui::SameLine();
    if (ImGui::Button("Step") && playing) { paused = true; stepReq = true; }
    ImGui::SameLine(0, 24 * ui());
    ImGui::Text("Android"); ImGui::SameLine();
    static const char* kRes[] = {"1080 x 1920", "720 x 1280", "1280 x 720", "1920 x 1080"};
    static const int kW[] = {1080, 720, 1280, 1920}, kH[] = {1920, 1280, 720, 1080};
    int cur = 0; for (int i = 0; i < 4; i++) if (kW[i] == pub.resW && kH[i] == pub.resH) cur = i;
    ImGui::SetNextItemWidth(170 * ui());
    if (ImGui::Combo("##res", &cur, kRes, 4)) { pub.resW = kW[cur]; pub.resH = kH[cur]; pub.orientation = pub.resW > pub.resH ? "landscape" : "portrait"; }
    ImGui::SameLine(0, 24 * ui());
    if (ImGui::Button("Undo")) undoOp();
    ImGui::SameLine(); if (ImGui::Button("Redo")) redoOp();
    ImGui::SameLine(0, 24 * ui()); if (ImGui::Button("Publish")) showPublish = true;
    transH = ImGui::GetFrameHeight() + ImGui::GetStyle().WindowPadding.y * 2.f + ImGui::GetStyle().ScrollbarSize;
    ImGui::End();
    ImGui::PopStyleColor(); ImGui::PopStyleVar();
}

void Editor::drawStatus(float W, float H) {
    float h = ImGui::GetFrameHeight() * 1.1f; statH = h;
    ImGui::SetNextWindowPos(V(0, H - h)); ImGui::SetNextWindowSize(V(W, h));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, V(12 * ui(), 4 * ui())); ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, C(.03f, .06f, .13f, 1.f));
    ImGui::Begin("##status", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoScrollbar);
    long rssPages = 0; if (FILE* f = std::fopen("/proc/self/statm", "r")) { long a; if (std::fscanf(f, "%ld %ld", &a, &rssPages) != 2) rssPages = 0; std::fclose(f); }
    ImGui::TextDisabled("Kyzn Game Studio  v0.2.0");
    ImGui::SameLine(0, 20 * ui()); ImGui::TextColored(C(.3f, .85f, .5f), "Android Build Ready");
    ImGui::SameLine(0, 20 * ui()); ImGui::TextDisabled("Memory: %ld MB   FPS: %.0f   Objects: %d", rssPages * 4 / 1024, fps, (int)scene.entities.size());
    ImGui::End();
    ImGui::PopStyleColor(); ImGui::PopStyleVar(2);
}

void Editor::frame(float dt, const Touch& t, float W, float H) {
    if (ImGui::IsMouseClicked(0)) { preEdit = scene.toJson().dump(); edited = false; }
    fpsAcc += dt; fpsN++;
    if (fpsAcc >= .5f) { fps = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0; }
    GameInput cur = gi; gi = GameInput();
    if (playing && (!paused || stepReq)) { game.update(scene, stepReq ? 1.f / 60.f : dt, cur); stepReq = false; }
    sel.erase(std::remove_if(sel.begin(), sel.end(), [&](int i) { return !scene.find(i); }), sel.end());
    drawMenu(); drawTransport(W); drawSceneView(dt, t, W, H);
    if (showHier) drawHierarchy();
    if (showInsp) drawInspector();
    if (showProj) drawProject();
    if (showGame) drawGame(t);
    if (showStore) drawStore();
    if (showScript) drawScript();
    if (showPublish) drawPublish();
    drawStatus(W, H);
}

// ---------------------------------------------------------------- simpan/muat proyek
bool Editor::save(const std::string& path) {
    Json j = Json::object();
    j.set("scene", scene.toJson()); j.set("publish", pub.toJson());
    Json im = Json::array(); for (Kind k : imported) im.push(kindInfo(k).name); j.set("imported", im);
    Json pf_ = Json::array(); for (auto& e : prefabs) { Scene t; t.entities.push_back(e); pf_.push(t.toJson()); } j.set("prefabs", pf_);
    return writeFile(path, j.dump(1));
}
bool Editor::load(const std::string& path) {
    std::string txt; Json j;
    if (!readFile(path, txt) || !Json::parse(txt, j)) return false;
    Scene s; if (!s.fromJson(j["scene"])) return false;
    scene = s; pub = PublishSettings::fromJson(j["publish"]);
    imported.clear(); for (auto& n : j["imported"].items()) { Kind k; if (kindFromName(n.str(), k)) imported.push_back(k); }
    prefabs.clear(); for (auto& pj : j["prefabs"].items()) { Scene t; if (t.fromJson(pj) && !t.entities.empty()) prefabs.push_back(t.entities[0]); }
    std::snprintf(bufName, sizeof bufName, "%s", pub.appName.c_str()); std::snprintf(bufPkg, sizeof bufPkg, "%s", pub.package.c_str()); std::snprintf(bufVer, sizeof bufVer, "%s", pub.versionName.c_str());
    sel.clear(); hist = History();
    return true;
}
void Editor::autosave() { if (!playing) save(pf.dataDir + "/autosave.kyzn.json"); }
void Editor::autoload() { load(pf.dataDir + "/autosave.kyzn.json"); }

// ============================================================ Scene View
int Editor::pick(const View& v, float mx, float my) const {
    float nx = (mx - v.p.x) / v.sz.x * 2.f - 1.f, ny = 1.f - (my - v.p.y) / v.sz.y * 2.f;
    Ray r = v.cam.ray(v.aspect, nx, ny);
    int best = 0; float bt = 1e30f;
    for (auto& e : scene.entities) {
        if (!e.visible || !kindInfo(e.kind).geometry) continue;
        float t;
        if (rayObb(r, scene.world(e.id), t) && t < bt) { bt = t; best = e.id; }
    }
    return best;
}

void Editor::drawGizmo(const View& v) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float u = ui();
    // kotak seleksi (OBB) untuk semua object terpilih
    for (int id : sel) {
        const Entity* e = scene.find(id);
        if (!e || !kindInfo(e->kind).geometry) continue;
        Mat4 w = scene.world(id); ImVec2 q[8]; bool ok = true;
        for (int i = 0; i < 8; i++) ok &= toScreen(v, w.point({(i & 1) ? .5f : -.5f, (i & 2) ? .5f : -.5f, (i & 4) ? .5f : -.5f}), q[i]);
        if (!ok) continue;
        static const int E[12][2] = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        for (auto& ed : E) dl->AddLine(q[ed[0]], q[ed[1]], id == sel[0] ? IM_COL32(80, 190, 255, 255) : IM_COL32(80, 190, 255, 140), 2.f * u * .6f);
    }
    const Entity* e = primary();
    if (!e || tool < 1 || tool > 3) return;
    Mat4 w = scene.world(e->id);
    Vec3 c = w.position();
    float len = length(v.cam.eye - c) * .17f;
    ImVec2 sc; if (!toScreen(v, c, sc)) return;
    static const ImU32 col[3] = {IM_COL32(235, 80, 80, 255), IM_COL32(90, 215, 90, 255), IM_COL32(80, 140, 255, 255)};
    Vec3 dir[3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    if (tool == 2) for (int i = 0; i < 3; i++) dir[i] = normalize(w.dir(dir[i]));      // skala: sumbu lokal
    for (int i = 0; i < 3; i++) {
        bool act = (drag == Drag::Move || drag == Drag::Scale || drag == Drag::Rotate) && dragAxis == i;
        ImU32 cl = act ? IM_COL32(255, 230, 80, 255) : col[i];
        if (tool == 3) {                                                             // cincin rotasi di sekeliling sumbu i
            Vec3 a = i == 0 ? Vec3(0, 1, 0) : (i == 1 ? Vec3(0, 0, 1) : Vec3(1, 0, 0)), b = cross(dir[i], a);
            ImVec2 prev; bool hp = false;
            for (int s = 0; s <= 48; s++) {
                float th = 2 * kPi * s / 48; ImVec2 pt;
                bool ok = toScreen(v, c + (a * std::cos(th) + b * std::sin(th)) * len, pt);
                if (ok && hp) dl->AddLine(prev, pt, cl, 3.f * u * .7f);
                prev = pt; hp = ok;
            }
        } else {
            ImVec2 se; if (!toScreen(v, c + dir[i] * len, se)) continue;
            dl->AddLine(sc, se, cl, 4.f * u * .7f);
            if (tool == 1) dl->AddCircleFilled(se, 9.f * u, cl, 16);
            else dl->AddRectFilled(V(se.x - 8 * u, se.y - 8 * u), V(se.x + 8 * u, se.y + 8 * u), cl);
        }
    }
    dl->AddCircleFilled(sc, 7.f * u, IM_COL32(240, 240, 240, 255), 16);
}

void Editor::doDrag(const View& v, float mx, float my, float dx, float dy) {
    Entity* e = primary();
    if (drag == Drag::Orbit) { orbit.orbit(dx, dy); return; }
    if (drag == Drag::Pan) { orbit.pan(dx, dy); return; }
    if (!e || playing) return;
    markEdit();
    Mat4 pw = e->parent ? scene.world(e->parent) : Mat4::identity();
    if (drag == Drag::Plane) {                                       // geser bebas di bidang tanah
        float nx = (mx - v.p.x) / v.sz.x * 2.f - 1.f, ny = 1.f - (my - v.p.y) / v.sz.y * 2.f;
        Ray r = v.cam.ray(v.aspect, nx, ny);
        if (std::fabs(r.d.y) > 1e-4f) {
            float t = (dragStartWorld.y - r.o.y) / r.d.y;
            if (t > 0) {
                Vec3 hit = r.o + r.d * t + dragPlaneOffset;
                if (snap) { hit.x = std::round(hit.x * 2) / 2; hit.z = std::round(hit.z * 2) / 2; }
                e->pos = pw.inverse().point({hit.x, dragStartWorld.y, hit.z});
            }
        }
        return;
    }
    float d2 = dragAx * dragAx + dragAy * dragAy;
    float s = d2 > 1e-4f ? ((mx - pressX) * dragAx + (my - pressY) * dragAy) / d2 : 0.f;   // 1.0 = panjang sumbu di layar
    if (drag == Drag::Move && dragAxis >= 0) {
        Vec3 nw = dragStartWorld + dragAxisDir * (s * dragAxisLen);
        if (snap) nw[dragAxis] = std::round(nw[dragAxis] * 2) / 2;
        e->pos = pw.inverse().point(nw);
    } else if (drag == Drag::Scale) {
        if (dragAxis >= 0) e->scale[dragAxis] = std::max(.05f, dragStartScale[dragAxis] * (1.f + s));
        else { float f = std::max(.05f, 1.f - (my - pressY) * .004f); e->scale = dragStartScale * f; }
    } else if (drag == Drag::Rotate && dragAxis >= 0) {
        float a = dragStartRot[dragAxis] + (mx - pressX) * .6f;
        if (snap) a = std::round(a / 5.f) * 5.f;
        e->rot[dragAxis] = a;
    }
}

void Editor::viewInput(const View& v, bool pressed, bool active, const Touch& t, float dt) {
    ImGuiIO& io = ImGui::GetIO();
    float mx = io.MousePos.x, my = io.MousePos.y, u = ui();
    if (t.count >= 2) {                                              // cubit = zoom, geser 2 jari = pan
        float d = std::hypot(t.x[0] - t.x[1], t.y[0] - t.y[1]);
        if (lastPinch > 0 && d > 1) orbit.zoom(lastPinch / d);
        lastPinch = d; drag = Drag::None; return;
    }
    lastPinch = -1;
    ImVec2 jc = V(v.p.x + 110 * u, v.p.y + v.sz.y - 110 * u);
    float jr = 62 * u;
    if (pressed) {
        pressX = mx; pressY = my; dragMoved = 0; dragAxis = -1; drag = Drag::None;
        if (std::hypot(mx - jc.x, my - jc.y) < jr * 1.35f) drag = Drag::Joystick;
        else if (Entity* e = primary(); e && tool >= 1 && tool <= 3 && !playing) {
            Mat4 w = scene.world(e->id); Vec3 c = w.position(); float len = length(v.cam.eye - c) * .17f;
            ImVec2 sc;
            if (toScreen(v, c, sc)) {
                float best = 28.f * u; int bi = -1; bool center = false;
                if (std::hypot(mx - sc.x, my - sc.y) < 18.f * u) { center = true; best = 18.f * u; }
                Vec3 dir[3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
                if (tool == 2) for (int i = 0; i < 3; i++) dir[i] = normalize(w.dir(dir[i]));
                for (int i = 0; i < 3; i++) {
                    float dd = 1e9f;
                    if (tool == 3) {
                        Vec3 a = i == 0 ? Vec3(0, 1, 0) : (i == 1 ? Vec3(0, 0, 1) : Vec3(1, 0, 0)), b = cross(dir[i], a);
                        ImVec2 prev, pt; bool hp = false;
                        for (int s = 0; s <= 48; s++) {
                            float th = 2 * kPi * s / 48;
                            bool ok = toScreen(v, c + (a * std::cos(th) + b * std::sin(th)) * len, pt);
                            if (ok && hp) dd = std::min(dd, distSeg(mx, my, prev, pt));
                            prev = pt; hp = ok;
                        }
                    } else { ImVec2 se; if (toScreen(v, c + dir[i] * len, se)) dd = distSeg(mx, my, sc, se); }
                    if (dd < best) { best = dd; bi = i; center = false; }
                }
                dragStartPos = e->pos; dragStartRot = e->rot; dragStartScale = e->scale; dragStartWorld = c;
                if (bi >= 0) {
                    dragAxis = bi; dragAxisDir = dir[bi]; dragAxisLen = len;
                    ImVec2 se; toScreen(v, c + dir[bi] * len, se); dragAx = se.x - sc.x; dragAy = se.y - sc.y;
                    drag = tool == 1 ? Drag::Move : (tool == 2 ? Drag::Scale : Drag::Rotate);
                } else if (center) {
                    if (tool == 1) {                                  // titik tengah = geser bebas di tanah
                        drag = Drag::Plane;
                        float nx = (mx - v.p.x) / v.sz.x * 2.f - 1.f, ny = 1.f - (my - v.p.y) / v.sz.y * 2.f;
                        Ray r = v.cam.ray(v.aspect, nx, ny);
                        dragPlaneOffset = {0, 0, 0};
                        if (std::fabs(r.d.y) > 1e-4f) { float tt = (c.y - r.o.y) / r.d.y; if (tt > 0) dragPlaneOffset = c - (r.o + r.d * tt); }
                    } else if (tool == 2) drag = Drag::Scale;       // titik tengah = skala seragam
                }
            }
        }
        if (drag == Drag::None) drag = tool == 4 ? Drag::Pan : Drag::Orbit;
    }
    if (active && drag != Drag::None) {
        dragMoved += std::fabs(io.MouseDelta.x) + std::fabs(io.MouseDelta.y);
        if (drag == Drag::Joystick) {
            float dx = (mx - jc.x) / jr, dy = (my - jc.y) / jr, l = std::hypot(dx, dy);
            if (l > 1) { dx /= l; dy /= l; }
            joyX = dx; joyY = -dy;
        } else doDrag(v, mx, my, io.MouseDelta.x, io.MouseDelta.y);
    }
    if (drag == Drag::Joystick && active) orbit.move(joyX, joyY, 0, dt);
    if (!active && drag != Drag::None) {                              // jari diangkat
        if (drag == Drag::Orbit && dragMoved < 10.f * u) {            // tap = pilih / batal pilih
            int id = pick(v, pressX, pressY);
            select(id ? std::vector<int>{id} : std::vector<int>{});
        }
        drag = Drag::None; joyX = joyY = 0;
    }
}

void Editor::drawSceneView(float dt, const Touch& t, float W, float H) {
    float top = menuH + transH, h = H - top - statH, u = ui();
    ImGui::SetNextWindowPos(V(0, top)); ImGui::SetNextWindowSize(V(W, h));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, V(0, 0)); ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f); ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.f);
    ImGui::Begin("Scene View", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PopStyleVar(3);
    View v; v.p = ImGui::GetCursorScreenPos(); v.sz = ImGui::GetContentRegionAvail();
    if (v.sz.x < 16 || v.sz.y < 16) { ImGui::End(); return; }
    v.aspect = v.sz.x / v.sz.y; v.cam = orbit.toCamera(); v.vp = v.cam.viewProj(v.aspect);
    if (rd && svRT.resize((int)v.sz.x, (int)v.sz.y)) {
        RenderOpts o; o.grid = grid; o.player = playing; o.playerPos = game.player.pos; o.playerYaw = game.player.yaw;
        rd->render(scene, v.cam, svRT, o);
    }
    ImGui::SetCursorScreenPos(v.p);
    ImGui::InvisibleButton("##view", v.sz);
    bool pressed = ImGui::IsItemActivated(), active = ImGui::IsItemActive();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddImage((ImTextureID)(intptr_t)svRT.color, v.p, V(v.p.x + v.sz.x, v.p.y + v.sz.y), V(0, 1), V(1, 0));
    viewInput(v, pressed, active, t, dt);
    drawGizmo(v);

    // sumbu orientasi (kanan atas)
    {
        Mat4 vw = v.cam.view(); Vec3 R(vw.m[0], vw.m[4], vw.m[8]), U(vw.m[1], vw.m[5], vw.m[9]);
        ImVec2 c0 = V(v.p.x + v.sz.x - 56 * u, v.p.y + 62 * u);
        dl->AddCircleFilled(c0, 40 * u, IM_COL32(8, 18, 40, 150), 32);
        struct A { Vec3 d; ImU32 c; const char* n; } ax[3] = {{{1, 0, 0}, IM_COL32(235, 80, 80, 255), "X"}, {{0, 1, 0}, IM_COL32(90, 215, 90, 255), "Y"}, {{0, 0, 1}, IM_COL32(80, 140, 255, 255), "Z"}};
        for (auto& a : ax) {
            ImVec2 e1 = V(c0.x + dot(a.d, R) * 26 * u, c0.y - dot(a.d, U) * 26 * u);
            dl->AddLine(c0, e1, a.c, 3.f * u * .7f); dl->AddCircleFilled(e1, 9 * u, a.c, 16);
            dl->AddText(V(e1.x - 4 * u, e1.y - 7 * u), IM_COL32(255, 255, 255, 255), a.n);
        }
    }
    // joystick kamera (kiri bawah)
    {
        ImVec2 jc = V(v.p.x + 110 * u, v.p.y + v.sz.y - 110 * u);
        dl->AddCircleFilled(jc, 62 * u, IM_COL32(0, 0, 0, 70), 32); dl->AddCircle(jc, 62 * u, IM_COL32(255, 255, 255, 190), 32, 3.f);
        dl->AddCircleFilled(V(jc.x + joyX * 40 * u, jc.y - joyY * 40 * u), 26 * u, IM_COL32(0, 0, 0, 170), 24);
    }
    if (stats && rd) {
        char b[96]; std::snprintf(b, sizeof b, "FPS %.0f   Object %d", fps, (int)scene.entities.size());
        dl->AddText(V(v.p.x + 120 * u, v.p.y + v.sz.y - 24 * u), IM_COL32(255, 255, 255, 220), b);
    }

    // palet alat (kiri atas)
    static const char* tn[5] = {"Pilih", "Geser", "Skala", "Putar", "Tangan"};
    for (int i = 0; i < 5; i++) {
        ImGui::SetCursorScreenPos(V(v.p.x + 10 * u, v.p.y + 10 * u + i * 62 * u));
        bool on = tool == i;
        if (on) ImGui::PushStyleColor(ImGuiCol_Button, C(.18f, .45f, .90f)); else ImGui::PushStyleColor(ImGuiCol_Button, C(.05f, .09f, .19f, .85f));
        if (ImGui::Button(tn[i], V(86 * u, 52 * u))) tool = i;
        ImGui::PopStyleColor();
    }
    // bar atas: tampilan kamera + opsi
    ImGui::SetCursorScreenPos(V(v.p.x + 110 * u, v.p.y + 10 * u));
    ImGui::PushStyleColor(ImGuiCol_Button, C(.05f, .09f, .19f, .85f));
    if (ImGui::Button("Perspective")) ImGui::OpenPopup("##persp");
    if (ImGui::BeginPopup("##persp")) {
        if (ImGui::Selectable("Perspective")) { orbit.yaw = .8f; orbit.pitch = .35f; }
        if (ImGui::Selectable("Atas (Top)")) { orbit.pitch = 1.5f; }
        if (ImGui::Selectable("Depan (Front)")) { orbit.yaw = 0; orbit.pitch = .06f; }
        if (ImGui::Selectable("Kanan (Right)")) { orbit.yaw = kPi / 2; orbit.pitch = .06f; }
        ImGui::EndPopup();
    }
    ImGui::SameLine(); if (ImGui::Button(snap ? "Snap: on" : "Snap: off")) snap = !snap;
    ImGui::SameLine(); if (ImGui::Button(grid ? "Grid: on" : "Grid: off")) grid = !grid;
    ImGui::SameLine(); if (ImGui::Button("Fokus")) { if (Entity* e = primary()) orbit.target = scene.world(e->id).position(); }
    ImGui::PopStyleColor();
    // naik/turun kamera (kanan bawah)
    ImGui::PushStyleColor(ImGuiCol_Button, C(0.f, 0.f, 0.f, .55f));
    ImGui::SetCursorScreenPos(V(v.p.x + v.sz.x - 66 * u, v.p.y + v.sz.y - 130 * u));
    ImGui::Button("Naik", V(56 * u, 56 * u)); if (ImGui::IsItemActive()) orbit.move(0, 0, 1, dt);
    ImGui::SetCursorScreenPos(V(v.p.x + v.sz.x - 66 * u, v.p.y + v.sz.y - 66 * u));
    ImGui::Button("Turun", V(56 * u, 56 * u)); if (ImGui::IsItemActive()) orbit.move(0, 0, -1, dt);
    ImGui::PopStyleColor();
    ImGui::End();
}

// ============================================================ Hierarchy
void Editor::hierNode(int id) {
    Entity* e = scene.find(id);
    if (!e) return;
    std::string q = hierSearch; std::string nm = e->name;
    auto lower = [](std::string s) { for (auto& c : s) c = (char)std::tolower((unsigned char)c); return s; };
    std::vector<int> kids = scene.childrenOf(id);
    if (!q.empty() && kids.empty() && lower(nm).find(lower(q)) == std::string::npos) return;
    ImGuiTreeNodeFlags f = ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_SpanAvailWidth | ImGuiTreeNodeFlags_DefaultOpen;
    if (kids.empty()) f |= ImGuiTreeNodeFlags_Leaf;
    if (isSel(id)) f |= ImGuiTreeNodeFlags_Selected;
    ImGui::PushID(id);
    bool open = ImGui::TreeNodeEx("##n", f, "%s", nm.c_str());
    if (ImGui::IsItemClicked() && !ImGui::IsItemToggledOpen()) {
        if (e->kind == Kind::Group) { std::vector<int> ids = {id}; for (int k : kids) ids.push_back(k); select(ids); }
        else select({id});
    }
    if (ImGui::BeginDragDropSource()) { ImGui::SetDragDropPayload("KYZN_ENT", &id, sizeof(int)); ImGui::Text("%s", nm.c_str()); ImGui::EndDragDropSource(); }
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("KYZN_ENT")) {
            int src = *(const int*)pl->Data;
            if (src != id) { commit(); if (!scene.setParent(src, id)) log("[hierarchy] tidak bisa memindah ke dalam anaknya sendiri"); }
        }
        ImGui::EndDragDropTarget();
    }
    if (kindInfo(e->kind).geometry) {
        ImGui::SameLine(ImGui::GetWindowWidth() - 78 * ui());
        if (ImGui::SmallButton(e->visible ? "tampil" : "sembunyi")) { markEdit(); commit(); e->visible = !e->visible; }
    }
    if (open) { for (int k : kids) hierNode(k); ImGui::TreePop(); }
    ImGui::PopID();
}

void Editor::drawHierarchy() {
    float u = ui();
    ImGui::SetNextWindowPos(V(104 * u, menuH + transH + 12 * u), ImGuiCond_FirstUseEver); ImGui::SetNextWindowSize(V(300 * u, 420 * u), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Hierarchy", &showHier)) { ImGui::End(); return; }
    ImGui::SetNextItemWidth(-1);
    ImGui::InputTextWithHint("##hs", "Cari object...", hierSearch, sizeof hierSearch);
    if (ImGui::Button("Duplicate")) duplicateSel();
    ImGui::SameLine();
    if (ImGui::Button("Copy")) copySel();
    ImGui::SameLine();
    if (ImGui::Button("Paste")) pasteSel();
    if (ImGui::Button("Group")) groupSel();
    ImGui::SameLine();
    if (ImGui::Button("Delete")) deleteSel();
    ImGui::SameLine();
    if (ImGui::Button("All")) { sel.clear(); for (auto& e : scene.entities) if (kindInfo(e.kind).geometry) sel.push_back(e.id); }
    ImGui::Separator();
    ImGui::TextDisabled("World"); ImGui::Indent();
    ImGui::TextDisabled("Scene"); ImGui::SameLine(ImGui::GetWindowWidth() - 70 * u);
    if (ImGui::Button("+")) ImGui::OpenPopup("##add");
    if (ImGui::BeginPopup("##add")) {
        for (const char* n : kBaseKinds) { Kind k; if (kindFromName(n, k) && ImGui::Selectable(n)) createKind(k); }
        for (Kind k : imported) if (ImGui::Selectable(kindInfo(k).name)) createKind(k);
        ImGui::Separator();
        if (ImGui::Selectable("Script")) { scriptId = createKind(Kind::Script); showScript = true; }
        if (ImGui::Selectable("Sound")) createKind(Kind::Sound);
        ImGui::EndPopup();
    }
    if (ImGui::Selectable("Lighting", selLighting)) { sel.clear(); selLighting = true; }
    for (auto& e : scene.entities) if (e.parent == 0) hierNode(e.id);
    ImGui::Dummy(V(0, 18 * u));
    ImGui::Selectable("(lepas ke root: tarik object ke sini)", false, ImGuiSelectableFlags_Disabled);
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("KYZN_ENT")) { commit(); scene.setParent(*(const int*)pl->Data, 0); }
        ImGui::EndDragDropTarget();
    }
    ImGui::Unindent();
    touchScroll();
    ImGui::End();
}

// ============================================================ Inspector
void Editor::drawInspector() {
    float u = ui();
    ImGui::SetNextWindowPos(V(ImGui::GetIO().DisplaySize.x - 340 * u - 12 * u, menuH + transH + 12 * u), ImGuiCond_FirstUseEver); ImGui::SetNextWindowSize(V(340 * u, 520 * u), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Inspector", &showInsp)) { ImGui::End(); return; }
    auto F3 = [&](const char* l, Vec3& v3) { float a[3] = {v3.x, v3.y, v3.z}; ImGui::SetNextItemWidth(-1); ImGui::TextDisabled("%s", l); if (ImGui::InputFloat3((std::string("##") + l).c_str(), a, "%.2f")) { markEdit(); v3 = {a[0], a[1], a[2]}; } };
    auto CB = [&](const char* l, bool& b) { if (ImGui::Checkbox(l, &b)) markEdit(); };
    auto FL = [&](const char* l, float& f) { ImGui::SetNextItemWidth(-1); ImGui::TextDisabled("%s", l); if (ImGui::InputFloat((std::string("##") + l).c_str(), &f, .1f, 1.f, "%.2f")) markEdit(); };
    if (selLighting) {
        Lighting& L = scene.lighting;
        if (ImGui::CollapsingHeader("Lighting", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::TextDisabled("Brightness"); ImGui::SetNextItemWidth(-1); if (ImGui::SliderFloat("##br", &L.brightness, 0.f, 2.f)) markEdit();
            ImGui::TextDisabled("ClockTime"); ImGui::SetNextItemWidth(-1); if (ImGui::SliderFloat("##ct", &L.clockTime, 0.f, 24.f)) markEdit();
            ImGui::TextDisabled("Ambient"); if (ImGui::ColorEdit3("##amb", &L.ambient.x, ImGuiColorEditFlags_NoInputs)) markEdit();
            FL("FogEnd", L.fogEnd); CB("Shadows", L.shadows);
        }
        touchScroll(); ImGui::End(); return;
    }
    Entity* e = primary();
    if (!e) { ImGui::TextWrapped("Dunia masih kosong. Tekan + di Hierarchy atau menu GameObject untuk menambah object, lalu pilih object untuk melihat Inspector."); touchScroll(); ImGui::End(); return; }
    char nb[64]; std::snprintf(nb, sizeof nb, "%s", e->name.c_str());
    ImGui::SetNextItemWidth(-1);
    if (ImGui::InputText("##name", nb, sizeof nb)) { markEdit(); e->name = nb; }
    if (e->kind == Kind::Script) {
        CB("Enabled", e->enabled);
        ImGui::TextDisabled("Attached: %s", scene.find(e->attached) ? scene.find(e->attached)->name.c_str() : "Global");
        if (ImGui::Button("Edit Script", V(-1, 0))) { scriptId = e->id; showScript = true; }
        touchScroll(); ImGui::End(); return;
    }
    if (e->kind == Kind::Sound) {
        static const char* clips[] = {"explosion", "footstep", "jump"};
        int ci = indexOf(clips, 3, e->clip); ImGui::SetNextItemWidth(-1);
        if (ImGui::Combo("##clip", &ci, clips, 3)) { markEdit(); e->clip = clips[ci]; }
        CB("PlayOnStart", e->playOnStart);
        if (ImGui::Button("Test", V(-1, 0))) { log("[sfx] " + e->clip); if (pf.sfx) pf.sfx(e->clip); }
        touchScroll(); ImGui::End(); return;
    }
    int ti = indexOf(kTags, ARR(kTags), e->tag), li = indexOf(kLayers, ARR(kLayers), e->layer);
    ImGui::TextDisabled("Tag"); ImGui::SetNextItemWidth(-1); if (ImGui::Combo("##tag", &ti, kTags, ARR(kTags))) { markEdit(); e->tag = kTags[ti]; }
    ImGui::TextDisabled("Layer"); ImGui::SetNextItemWidth(-1); if (ImGui::Combo("##layer", &li, kLayers, ARR(kLayers))) { markEdit(); e->layer = kLayers[li]; }
    CB("Visible", e->visible);
    if (ImGui::CollapsingHeader("Transform", ImGuiTreeNodeFlags_DefaultOpen)) { F3("Position", e->pos); F3("Rotation", e->rot); F3(e->kind == Kind::Group ? "Scale" : "Size", e->scale); }
    if (kindInfo(e->kind).geometry) {
        if (ImGui::CollapsingHeader("Mesh Renderer", ImGuiTreeNodeFlags_DefaultOpen)) {
            int mi = (int)e->mat; ImGui::TextDisabled("Material"); ImGui::SetNextItemWidth(-1);
            if (ImGui::Combo("##mat", &mi, kMats, ARR(kMats))) { markEdit(); e->mat = (MatType)mi; }
            ImGui::TextDisabled("Color"); if (ImGui::ColorEdit3("##col", &e->color.x, ImGuiColorEditFlags_NoInputs)) markEdit();
            ImGui::TextDisabled("Texture"); ImGui::SetNextItemWidth(-1); if (ImGui::Combo("##tex", &e->tex, kTex, ARR(kTex))) markEdit();
            FL("Transparency", e->transparency); FL("Reflectance", e->reflectance);
            e->transparency = clampf(e->transparency, 0.f, .95f); e->reflectance = clampf(e->reflectance, 0.f, 1.f);
            CB("Cast Shadows", e->castShadow); CB("Receive Shadows", e->receiveShadow);
        }
        if (ImGui::CollapsingHeader("Physics Body", ImGuiTreeNodeFlags_DefaultOpen)) {
            CB("Rigidbody", e->rigidbody); FL("Mass", e->mass); CB("Kinematic", e->kinematic); CB("Use Gravity", e->useGravity); CB("Collider", e->collider);
        }
        if (ImGui::CollapsingHeader("Animation")) {
            int ai = (int)e->anim; ImGui::SetNextItemWidth(-1);
            if (ImGui::Combo("##anim", &ai, kAnim, ARR(kAnim))) { markEdit(); e->anim = (AnimType)ai; }
            FL("Speed", e->animSpeed); FL("Amount", e->animAmount);
            ImGui::TextDisabled("spin: berputar, bob: naik-turun, patrol: bolak-balik (saat Play)");
        }
    }
    if (ImGui::CollapsingHeader("Custom Scripts", ImGuiTreeNodeFlags_DefaultOpen)) {
        for (auto& s : scene.entities) {
            if (s.kind != Kind::Script || s.attached != e->id) continue;
            ImGui::PushID(s.id);
            if (ImGui::Selectable(s.name.c_str(), false, 0, V(ImGui::GetContentRegionAvail().x - 70 * u, 0))) { scriptId = s.id; showScript = true; }
            ImGui::SameLine(); if (ImGui::SmallButton("lepas")) { commit(); s.attached = 0; }
            ImGui::PopID();
        }
        if (ImGui::Button("+ Add Script", V(-1, 0))) ImGui::OpenPopup("##attach");
        if (ImGui::BeginPopup("##attach")) {
            for (auto& s : scene.entities) if (s.kind == Kind::Script && ImGui::Selectable(s.name.c_str())) { commit(); s.attached = e->id; }
            if (ImGui::Selectable("Script baru")) { int eid = e->id; int nid = createKind(Kind::Script); if (Entity* ns = scene.find(nid)) { ns->attached = eid; scriptId = nid; showScript = true; } }
            ImGui::EndPopup();
        }
    }
    if (kindInfo(e->kind).geometry && ImGui::Button("Create Prefab", V(-1, 0))) { prefabs.push_back(*e); prefabs.back().parent = 0; log("[prefab] " + e->name + ".prefab dibuat"); }
    touchScroll();
    ImGui::End();
}

// ============================================================ Project + Console
static bool containsCI(const std::string& hay, const char* needle) {
    std::string h = hay, n = needle;
    for (auto& c : h) c = (char)std::tolower((unsigned char)c);
    for (auto& c : n) c = (char)std::tolower((unsigned char)c);
    return h.find(n) != std::string::npos;
}

void Editor::drawProject() {
    float u = ui(); ImVec2 ds = ImGui::GetIO().DisplaySize;
    float w = std::min(780.f * u, ds.x - 24 * u), h = 330 * u;
    ImGui::SetNextWindowPos(V(std::max(12 * u, ds.x * .5f - w * .5f), ds.y - statH - h - 12 * u), ImGuiCond_FirstUseEver); ImGui::SetNextWindowSize(V(w, h), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Project", &showProj)) { ImGui::End(); return; }
    if (ImGui::BeginTabBar("##ptabs")) {
        if (ImGui::BeginTabItem("Project")) {
            static const char* dirs[] = {"Scenes", "Scripts", "Prefabs", "Models", "Materials", "Textures", "Audio", "Builds"};
            ImGui::BeginChild("##folders", V(ImGui::GetContentRegionAvail().x * .28f, 0), ImGuiChildFlags_Border);
            for (int i = 0; i < 8; i++) if (ImGui::Selectable(dirs[i], projDir == i, 0, V(0, 36 * u))) projDir = i;
            touchScroll(); ImGui::EndChild(); ImGui::SameLine();
            ImGui::BeginChild("##assets", V(0, 0), ImGuiChildFlags_Border);
            ImGui::TextDisabled("Assets > %s", dirs[projDir]); ImGui::SameLine(ImGui::GetWindowWidth() - 90 * u);
            if (ImGui::SmallButton(projGrid ? "Daftar" : "Grid")) projGrid = !projGrid;
            ImGui::SetNextItemWidth(-1); ImGui::InputTextWithHint("##ps", "Cari asset...", projSearch, sizeof projSearch);
            struct Item { std::string label; ImVec4 col; GLuint tex; int act; int data; };
            std::vector<Item> items;
            auto pushItem = [&](const std::string& l, ImVec4 c, GLuint t, int a, int d) { if (!projSearch[0] || containsCI(l, projSearch)) items.push_back({l, c, t, a, d}); };
            switch (projDir) {
                case 0: pushItem("Main.scene", C(.2f, .35f, .6f), 0, 0, 0); break;
                case 1: for (auto& e : scene.entities) if (e.kind == Kind::Script) pushItem(e.name + ".lua", C(.18f, .4f, .7f), 0, 1, e.id); break;
                case 2: for (size_t i = 0; i < prefabs.size(); i++) pushItem(prefabs[i].name + ".prefab", C(prefabs[i].color.x, prefabs[i].color.y, prefabs[i].color.z), 0, 2, (int)i); break;
                case 3: {
                    for (const char* n : kBaseKinds) { Kind k; kindFromName(n, k); pushItem(n, C(kindInfo(k).color.x, kindInfo(k).color.y, kindInfo(k).color.z), 0, 3, (int)k); }
                    for (Kind k : imported) pushItem(kindInfo(k).name, C(kindInfo(k).color.x * .8f, kindInfo(k).color.y * .8f, kindInfo(k).color.z * .8f), 0, 3, (int)k);
                    break;
                }
                case 4: for (int i = 0; i < ARR(kMats); i++) { Vec3 c = matInfo((MatType)i).color; pushItem(kMats[i], C(c.x, c.y, c.z), 0, 4, i); } break;
                case 5: for (int i = 1; i < ARR(kTex); i++) pushItem(kTex[i], C(1, 1, 1), rd ? rd->textureId(i) : 0, 5, i); break;
                case 6: { static const char* au[] = {"explosion.wav", "footstep.wav", "jump.wav"}; for (int i = 0; i < 3; i++) pushItem(au[i], C(.45f, .3f, .7f), 0, 6, i); break; }
                case 7: for (auto& m : exportMsgs) pushItem(m, C(.2f, .5f, .3f), 0, 0, 0); break;
            }
            float tile = 84 * u, sp = ImGui::GetStyle().ItemSpacing.x;
            int cols = projGrid ? std::max(1, (int)((ImGui::GetContentRegionAvail().x + sp) / (tile + sp))) : 1;
            for (size_t i = 0; i < items.size(); i++) {
                Item& it = items[i];
                if (projGrid && i % cols != 0) ImGui::SameLine();
                ImGui::PushID((int)i); ImGui::BeginGroup();
                bool click;
                if (!projGrid) click = ImGui::Selectable(it.label.c_str(), false, 0, V(0, 38 * u));
                else {
                    if (it.tex) click = ImGui::ImageButton("##b", (ImTextureID)(intptr_t)it.tex, V(tile, tile));
                    else { ImGui::PushStyleColor(ImGuiCol_Button, it.col); click = ImGui::Button("##b", V(tile + 16 * u, tile)); ImGui::PopStyleColor(); }
                    ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + tile); ImGui::TextWrapped("%s", it.label.c_str()); ImGui::PopTextWrapPos();
                }
                ImGui::EndGroup(); ImGui::PopID();
                if (!click || playing) continue;
                switch (it.act) {
                    case 1: scriptId = it.data; showScript = true; break;
                    case 2: { commit(); Entity c = prefabs[it.data]; c.id = scene.nextId++; c.name = scene.uniqueName(c.name); c.pos.x = std::round(orbit.target.x); c.pos.z = std::round(orbit.target.z); scene.entities.push_back(c); select({c.id}); break; }
                    case 3: createKind((Kind)it.data); break;
                    case 4: if (!sel.empty()) { commit(); for (int id : sel) if (Entity* e = scene.find(id)) if (kindInfo(e->kind).geometry) { e->mat = (MatType)it.data; Vec3 c = matInfo(e->mat).color; e->color = c; } } else log("[project] pilih object dulu"); break;
                    case 5: if (!sel.empty()) { commit(); for (int id : sel) if (Entity* e = scene.find(id)) if (kindInfo(e->kind).geometry) e->tex = it.data; } else log("[project] pilih object dulu"); break;
                    case 6: log(std::string("[sfx] ") + it.label); if (pf.sfx) pf.sfx(it.label); break;
                    default: break;
                }
            }
            if (items.empty()) ImGui::TextDisabled("Kosong");
            touchScroll(); ImGui::EndChild();
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("Console")) {
            if (ImGui::Button("Clear")) logs.clear();
            ImGui::BeginChild("##log", V(0, 0), ImGuiChildFlags_Border);
            for (auto& l : logs) {
                bool bad = l.find("rror") != std::string::npos || l.find("gagal") != std::string::npos;
                if (bad) ImGui::PushStyleColor(ImGuiCol_Text, C(1.f, .45f, .45f));
                ImGui::TextWrapped("%s", l.c_str());
                if (bad) ImGui::PopStyleColor();
            }
            if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 8) ImGui::SetScrollHereY(1.f);
            touchScroll(); ImGui::EndChild();
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
}

// ============================================================ Game Preview
void Editor::drawGame(const Touch& t) {
    float u = ui(); ImVec2 ds = ImGui::GetIO().DisplaySize;
    float aspect = (float)pub.resW / (float)pub.resH;
    ImGui::SetNextWindowPos(V(ds.x * .5f - 130 * u, menuH + transH + 14 * u), ImGuiCond_FirstUseEver); ImGui::SetNextWindowSize(V(aspect < 1 ? 280 * u : 460 * u, aspect < 1 ? 560 * u : 330 * u), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Game Preview", &showGame)) { ImGui::End(); return; }
    ImGui::TextDisabled("Android %d x %d  %s", pub.resW, pub.resH, playing ? (paused ? "(pause)" : "(Play)") : "(tekan Play)");
    ImVec2 avail = ImGui::GetContentRegionAvail();
    float w = avail.x, h = w / aspect;
    if (h > avail.y) { h = avail.y; w = h * aspect; }
    if (w < 40 || h < 40) { ImGui::End(); return; }
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + (avail.x - w) * .5f);
    ImVec2 p = ImGui::GetCursorScreenPos();
    int rw = aspect < 1 ? (int)(640 * aspect) : 640, rh = aspect < 1 ? 640 : (int)(640 / aspect);
    if (rd && gameRT.resize(rw, rh)) {
        Camera cam = gameCamera();
        RenderOpts o; o.grid = false; o.player = true;
        o.playerPos = playing ? game.player.pos : cam.target - Vec3(0, 1.2f, 0); o.playerYaw = playing ? game.player.yaw : 0;
        rd->render(scene, cam, gameRT, o);
    }
    ImGui::Image((ImTextureID)(intptr_t)gameRT.color, V(w, h), V(0, 1), V(1, 0));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 jc = V(p.x + w * .2f, p.y + h * .82f), kc = V(p.x + w * .82f, p.y + h * .8f);
    float jr = std::min(w, h) * .14f, kr = std::min(w, h) * .09f;
    dl->AddCircleFilled(jc, jr, IM_COL32(0, 0, 0, 70), 32); dl->AddCircle(jc, jr, IM_COL32(255, 255, 255, 190), 32, 3.f);
    dl->AddCircleFilled(kc, kr, IM_COL32(47, 134, 255, 190), 24); dl->AddText(V(kc.x - 16 * u, kc.y - 8 * u), IM_COL32(255, 255, 255, 255), "Jump");
    if (playing) {
        std::map<int, float> seen; Vec2 mv;
        for (int i = 0; i < t.count; i++) {
            float x = t.x[i], y = t.y[i];
            if (x < p.x || x > p.x + w || y < p.y || y > p.y + h) continue;
            float dj = std::hypot(x - jc.x, y - jc.y), dk = std::hypot(x - kc.x, y - kc.y);
            if (dj < jr * 1.7f) { mv.x = clampf((x - jc.x) / jr, -1.f, 1.f); mv.y = clampf(-(y - jc.y) / jr, -1.f, 1.f); dl->AddCircleFilled(V(jc.x + mv.x * jr * .7f, jc.y - mv.y * jr * .7f), jr * .45f, IM_COL32(0, 0, 0, 170), 24); }
            else if (dk < kr * 1.5f) gi.jump = true;
            else { auto it = lookPrev.find(t.id[i]); if (it != lookPrev.end()) game.look((x - it->second) * .008f); seen[t.id[i]] = x; }
        }
        gi.move = mv; lookPrev = seen;
    }
    ImGui::End();
}

// ============================================================ Asset Store
void Editor::drawStore() {
    float u = ui();
    ImGui::SetNextWindowPos(V(120 * u, menuH + transH + 40 * u), ImGuiCond_FirstUseEver); ImGui::SetNextWindowSize(V(420 * u, 380 * u), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Asset Store", &showStore)) { ImGui::End(); return; }
    for (auto& pk : packs()) {
        bool all = true; for (Kind k : pk.kinds) if (std::find(imported.begin(), imported.end(), k) == imported.end()) all = false;
        ImGui::PushID(pk.name);
        ImGui::BeginGroup(); ImGui::Text("%s", pk.name); ImGui::TextDisabled("%s", pk.desc); ImGui::EndGroup();
        ImGui::SameLine(ImGui::GetWindowWidth() - 150 * u);
        if (all) ImGui::TextDisabled("Terpasang");
        else if (ImGui::Button("Import")) { for (Kind k : pk.kinds) if (std::find(imported.begin(), imported.end(), k) == imported.end()) imported.push_back(k); log(std::string("[store] ") + pk.name + " diimpor ke Project > Models"); }
        ImGui::Separator(); ImGui::PopID();
    }
    touchScroll();
    ImGui::End();
}

// ============================================================ Script Editor
void Editor::drawScript() {
    float u = ui();
    ImGui::SetNextWindowPos(V(140 * u, menuH + transH + 30 * u), ImGuiCond_FirstUseEver); ImGui::SetNextWindowSize(V(520 * u, 560 * u), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Script Editor", &showScript)) { ImGui::End(); return; }
    std::vector<int> ids; for (auto& e : scene.entities) if (e.kind == Kind::Script) ids.push_back(e.id);
    if (ids.empty()) {
        ImGui::TextWrapped("Belum ada script."); if (ImGui::Button("Buat Script", V(-1, 0))) { if (!playing) scriptId = createKind(Kind::Script); }
        ImGui::End(); return;
    }
    Entity* s = scene.find(scriptId);
    if (!s || s->kind != Kind::Script) { scriptId = ids[0]; s = scene.find(scriptId); }
    ImGui::SetNextItemWidth(-1);
    if (ImGui::BeginCombo("##scr", s->name.c_str())) {
        for (int id : ids) if (ImGui::Selectable(scene.find(id)->name.c_str(), id == scriptId)) { scriptId = id; scriptBufId = -1; }
        ImGui::EndCombo();
    }
    s = scene.find(scriptId);
    if (scriptBufId != scriptId) { std::snprintf(scriptBuf, sizeof scriptBuf, "%s", s->code.c_str()); scriptBufId = scriptId; }
    if (ImGui::InputTextMultiline("##code", scriptBuf, sizeof scriptBuf, V(-1, 280 * u), ImGuiInputTextFlags_AllowTabInput)) { markEdit(); s->code = scriptBuf; }
    if (ImGui::Button("Cek Script")) { std::string er = ScriptRuntime::check(s->code); log(er.empty() ? "[Lua] OK: " + s->name : "[Lua] error " + s->name + ": " + er); }
    ImGui::SameLine(); if (ImGui::Button("Contoh")) { commit(); s->code = kTemplateLua; scriptBufId = -1; }
    ImGui::SameLine(); if (ImGui::Button("Script Baru") && !playing) scriptId = createKind(Kind::Script);
    ImGui::TextDisabled(ScriptRuntime::available() ? "Lua 5.4 aktif. Hook: onStart(), onUpdate(dt)" : "Build ini tanpa Lua (script hanya diperiksa, tidak dijalankan)");
    ImGui::BeginChild("##slog", V(0, 0), ImGuiChildFlags_Border);
    size_t from = logs.size() > 12 ? logs.size() - 12 : 0;
    for (size_t i = from; i < logs.size(); i++) ImGui::TextWrapped("%s", logs[i].c_str());
    touchScroll(); ImGui::EndChild();
    ImGui::End();
}

// ============================================================ Publish
void Editor::drawPublish() {
    float u = ui();
    ImGui::SetNextWindowPos(V(100 * u, menuH + transH + 20 * u), ImGuiCond_FirstUseEver); ImGui::SetNextWindowSize(V(480 * u, 640 * u), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Publish ke Android", &showPublish)) { ImGui::End(); return; }
    ImGui::TextDisabled("Nama App"); ImGui::SetNextItemWidth(-1); if (ImGui::InputText("##an", bufName, sizeof bufName)) pub.appName = bufName;
    ImGui::TextDisabled("Package"); ImGui::SetNextItemWidth(-1); if (ImGui::InputText("##pk", bufPkg, sizeof bufPkg)) pub.package = bufPkg;
    ImGui::TextDisabled("Version Name"); ImGui::SetNextItemWidth(-1); if (ImGui::InputText("##vn", bufVer, sizeof bufVer)) pub.versionName = bufVer;
    ImGui::TextDisabled("Version Code"); ImGui::SetNextItemWidth(-1); ImGui::InputInt("##vc", &pub.versionCode);
    static const char* sdkMin[] = {"21", "23", "24", "26", "28", "30"}, *sdkTgt[] = {"33", "34", "35"}, *ori[] = {"portrait", "landscape", "auto"}, *fmt[] = {"apk", "aab"}, *sgn[] = {"debug", "release"};
    int a = indexOf(sdkMin, 6, std::to_string(pub.minSdk)), b = indexOf(sdkTgt, 3, std::to_string(pub.targetSdk)), c = indexOf(ori, 3, pub.orientation), d = indexOf(fmt, 2, pub.format), e = indexOf(sgn, 2, pub.signing);
    ImGui::TextDisabled("Min SDK"); ImGui::SetNextItemWidth(-1); if (ImGui::Combo("##mn", &a, sdkMin, 6)) pub.minSdk = std::atoi(sdkMin[a]);
    ImGui::TextDisabled("Target SDK"); ImGui::SetNextItemWidth(-1); if (ImGui::Combo("##tg", &b, sdkTgt, 3)) pub.targetSdk = std::atoi(sdkTgt[b]);
    ImGui::TextDisabled("Orientasi"); ImGui::SetNextItemWidth(-1); if (ImGui::Combo("##or", &c, ori, 3)) pub.orientation = ori[c];
    ImGui::TextDisabled("Format"); ImGui::SetNextItemWidth(-1); if (ImGui::Combo("##fm", &d, fmt, 2)) pub.format = fmt[d];
    ImGui::TextDisabled("Signing"); ImGui::SetNextItemWidth(-1); if (ImGui::Combo("##sg", &e, sgn, 2)) pub.signing = sgn[e];
    ImGui::Separator();
    if (ImGui::Button("Validasi", V(-1, 0))) { issues = validate(scene, pub); if (issues.empty()) log("[publish] validasi OK"); }
    for (auto& i : issues) { ImGui::PushStyleColor(ImGuiCol_Text, i.error ? C(1.f, .45f, .45f) : C(1.f, .8f, .4f)); ImGui::TextWrapped("%s %s", i.error ? "[Error]" : "[Peringatan]", i.text.c_str()); ImGui::PopStyleColor(); }
    if (ImGui::Button("Export paket game", V(-1, 0))) {
        issues = validate(scene, pub);
        if (hasErrors(issues)) log("[publish] export dibatalkan: perbaiki error dulu");
        else {
            std::string safe; for (char ch : pub.appName) safe += std::isalnum((unsigned char)ch) ? ch : '_';
            std::vector<std::string> written; std::string er;
            if (exportGame(scene, pub, pf.dataDir + "/Projects/" + safe, written, er)) { for (auto& w : written) { log("[publish] ditulis: " + w); exportMsgs.push_back(w); } }
            else log("[publish] export gagal: " + er);
        }
    }
    if (ImGui::Button("Salin main.scene.json", V(-1, 0)) && pf.setClipboard) { pf.setClipboard(scene.toJson().dump(1)); log("[publish] main.scene.json disalin ke clipboard"); }
    if (ImGui::Button("Salin publish.json", V(-1, 0)) && pf.setClipboard) { pf.setClipboard(pub.toJson().dump(1)); log("[publish] publish.json disalin ke clipboard"); }
    ImGui::Separator();
    ImGui::TextWrapped("Alur publish: 1) Salin kedua file ini ke folder game/ di repo GitHub (main.scene.json dan publish.json). 2) Jalankan workflow \"Publish Game\" di tab Actions. 3) Unduh APK/AAB dari Artifacts.");
    touchScroll();
    ImGui::End();
}

}  // namespace kyzn
