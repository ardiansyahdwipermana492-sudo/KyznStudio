#include "Runtime.h"
#include <cmath>
#include "imgui.h"

namespace kyzn {

bool Runtime::load(const std::string& sceneJson, const std::string& publishJson, std::string& err) {
    Json js, jp;
    if (!Json::parse(sceneJson, js, &err)) return false;
    if (!scene.fromJson(js, &err)) return false;
    if (Json::parse(publishJson, jp)) pub = PublishSettings::fromJson(jp);
    return true;
}

void Runtime::frame(float dt, const Touch& t, float W, float H, float ui) {
    if (!started) {
        game.start(scene, [this](const std::string& m) { logs.push_back(m); if (logs.size() > 6) logs.erase(logs.begin()); }, [](const std::string&) {});
        started = true;
    }
    float jr = std::min(W, H) * .13f, kr = jr * .62f;
    ImVec2 jc(W * .06f + jr * 1.2f, H - jr * 1.5f), kc(W - kr * 2.f, H - jr * 1.5f);
    GameInput gi; Vec2 mv; std::map<int, float> seen;
    for (int i = 0; i < t.count; i++) {
        float x = t.x[i], y = t.y[i];
        float dj = std::hypot(x - jc.x, y - jc.y), dk = std::hypot(x - kc.x, y - kc.y);
        if (dj < jr * 1.8f) { mv.x = clampf((x - jc.x) / jr, -1.f, 1.f); mv.y = clampf(-(y - jc.y) / jr, -1.f, 1.f); }
        else if (dk < kr * 1.6f) gi.jump = true;
        else { auto it = lookPrev.find(t.id[i]); if (it != lookPrev.end()) game.look((x - it->second) * .008f); seen[t.id[i]] = x; }
    }
    lookPrev = seen; gi.move = mv;
    game.update(scene, dt, gi);
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    if (rd && rt.resize((int)(W * .75f), (int)(H * .75f))) {
        CamPose cp = game.camera(); Camera cam; cam.eye = cp.eye; cam.target = cp.target;
        RenderOpts o; o.grid = false; o.player = true; o.playerPos = game.player.pos; o.playerYaw = game.player.yaw;
        rd->render(scene, cam, rt, o);
        dl->AddImage((ImTextureID)(intptr_t)rt.color, ImVec2(0, 0), ImVec2(W, H), ImVec2(0, 1), ImVec2(1, 0));
    }
    dl->AddCircleFilled(jc, jr, IM_COL32(0, 0, 0, 70), 32); dl->AddCircle(jc, jr, IM_COL32(255, 255, 255, 190), 32, 3.f * ui);
    dl->AddCircleFilled(ImVec2(jc.x + mv.x * jr * .6f, jc.y - mv.y * jr * .6f), jr * .4f, IM_COL32(0, 0, 0, 170), 24);
    dl->AddCircleFilled(kc, kr, IM_COL32(47, 134, 255, 190), 24); dl->AddText(ImVec2(kc.x - 14 * ui, kc.y - 8 * ui), IM_COL32(255, 255, 255, 255), "Jump");
    float y = 8 * ui;
    for (auto& l : logs) { dl->AddText(ImVec2(10 * ui, y), IM_COL32(255, 220, 140, 255), l.c_str()); y += 18 * ui; }
}

}  // namespace kyzn
