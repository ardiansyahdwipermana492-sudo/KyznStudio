# Kyzn Game Studio v0.2.0

Studio pembuat game Android yang berjalan **di HP**, ditulis dengan **C++17 + NativeActivity murni** (tanpa Java/Kotlin).
UI memakai Dear ImGui (jendela yang bisa digeser dan diubah ukurannya), render OpenGL ES 3.0, scripting Lua 5.4.

## Fitur
| Bagian | Isi |
|---|---|
| Scene View | dunia kosong + grid 4 m, langit, fog, shadow map PCF, orbit/cubit-zoom/pan, joystick kamera, pilih object dengan tap |
| Gizmo | Geser (sumbu X/Y/Z + titik tengah geser bebas di tanah), Skala (per sumbu / seragam), Putar (cincin per sumbu), snap 0,5 m / 5° |
| Hierarchy | pohon dengan parent-child (drag-drop untuk memindah), cari, tampil/sembunyi, Group, Duplicate, Copy/Paste, Delete, All |
| Inspector | Tag/Layer, Transform, Mesh Renderer (material, warna, texture, transparansi), Physics Body, Animation, Custom Scripts, Lighting |
| Project / Console | Scenes, Scripts, Prefabs, Models, Materials, Textures, Audio, Builds + pencarian + tampilan grid/daftar; Console |
| Game Preview | resolusi Android (1080x1920, 720x1280, 1280x720, 1920x1080), joystick + tombol Lompat multi-touch |
| Play | fisika AABB (gravitasi, tumpukan, step-up, lompat), animasi spin/bob/patrol, Pause/Step, scene dikembalikan saat Stop |
| Script | Lua 5.4 tersandbox: `find getpos setpos move getrot setrot rotate setscale setcolor setvisible destroy input player time sfx print`; hook `onStart()` / `onUpdate(dt)` |
| Undo/Redo | berbasis snapshot JSON |
| Asset Store | pack Nature / City / Industrial (menambah model ke Project > Models) |
| Publish | validasi (package, versi, SDK, script, dunia kosong), export `game/main.scene.json` + `game/publish.json`, salin ke clipboard |
| Autosave | otomatis saat app dijeda/ditutup, dimuat saat dibuka |

## Status verifikasi (jujur)
* **Lulus dan dites di sini** (`bash tests/run_tests.sh`, dengan ASan + UBSan): matematika, JSON, scene/hierarki/group/duplicate, undo/redo, fisika, animasi, validasi + export publish, sesi game, kamera/picking; renderer dijalankan headless dengan stub GL.
* **Hanya dicek sintaks** terhadap stub (belum pernah dikompilasi dengan ImGui/NDK/Lua asli): `editor/Editor.cpp`, `editor/Runtime.cpp`, `core/Script.cpp` (Lua), `platform/main.cpp`. Build pertama di GitHub Actions bisa saja menemukan error kompilasi kecil atau perbedaan API; kirim lognya dan saya perbaiki.
* Belum diuji di perangkat: tampilan, performa, soft keyboard, clipboard JNI.

## Build di GitHub Actions (cukup dari HP)
1. Buat repo GitHub, unggah isi folder ini (mis. lewat Termux: `git init`, `git add .`, `git commit`, `git push`).
2. Tab **Actions** > **Build Editor APK** > Run workflow. Tes inti berjalan dulu, lalu APK debug muncul di **Artifacts** (`KyznStudio-editor-debug`).
3. Pasang APK, buka. Dunia mulai kosong.

## Publish game
1. Di editor: **Publish** > isi data > **Validasi** > **Export** (atau **Salin main.scene.json** / **Salin publish.json**).
2. Tempel isinya ke `game/main.scene.json` dan `game/publish.json` di repo (editor file di web GitHub).
3. Tab Actions > **Publish Game** > Run. Unduh APK/AAB dari Artifacts.
4. Untuk tanda tangan release isi Secrets: `KYZN_KEYSTORE_BASE64`, `KYZN_KEYSTORE_PASSWORD`, `KYZN_KEY_ALIAS`, `KYZN_KEY_PASSWORD`, dan pilih Signing = release. Tanpa itu APK memakai tanda tangan debug (bisa diinstal, tidak untuk Play Store).

APK hasil publish otomatis berjalan sebagai game layar penuh (tanpa editor) karena memuat `game/main.scene.json` dari assets.

## Kontrol
* Tap object = pilih. Drag kosong = putar kamera. Cubit = zoom. Joystick kiri bawah = gerak kamera, tombol Naik/Turun = tinggi kamera.
* Alat (kiri atas): Pilih, Geser, Skala, Putar, Tangan (geser kamera).
* Ketuk dua kali kolom angka untuk mengetik; Hierarchy: tarik baris ke baris lain untuk memindah parent.

## Struktur
```
app/src/main/cpp/
  core/     Math, Json, Scene (+History), Physics, Game (sesi), Script (Lua), Project (publish), Camera   <- tanpa dependensi Android, dites
  render/   Renderer GLES3 (shader, mesh prosedural, shadow map, grid, sky)
  editor/   Editor (ImGui), Runtime (game hasil publish)
  platform/ main.cpp (EGL, input multi-touch, JNI clipboard & unicode)
tests/      core_test.cpp, render_smoke.cpp, stub GLES3/ImGui/Lua untuk cek di PC
.github/workflows/  android.yml (editor), publish.yml (game)
```

## Batasan saat ini
Audio belum ada mesin suara (`sfx` hanya mencatat ke Console), Terrain (Sculpt/Paint) belum ada karena dunia dibuat kosong, tabrakan memakai kotak (AABB), tidak ada import model/gambar eksternal.
Versi dependensi: ImGui v1.90.9, Lua v5.4.6, AGP 8.5.2, Gradle 8.7, NDK 26.1.10909125, minSdk 24, targetSdk 34.
