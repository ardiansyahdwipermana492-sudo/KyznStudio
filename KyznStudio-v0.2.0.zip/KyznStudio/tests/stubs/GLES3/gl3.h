// Stub GLES3 untuk uji kompilasi/jalan headless di PC (semua fungsi no-op). BUKAN bagian build Android.
#pragma once
#include <cstddef>
typedef unsigned int GLuint; typedef int GLint; typedef unsigned int GLenum; typedef int GLsizei; typedef ptrdiff_t GLsizeiptr;
typedef unsigned char GLboolean; typedef float GLfloat; typedef char GLchar; typedef unsigned int GLbitfield;
#define GLC(n, v) static const GLenum n = v;
GLC(GL_VERTEX_SHADER, 1) GLC(GL_FRAGMENT_SHADER, 2) GLC(GL_COMPILE_STATUS, 3) GLC(GL_LINK_STATUS, 4) GLC(GL_ARRAY_BUFFER, 5) GLC(GL_ELEMENT_ARRAY_BUFFER, 6)
GLC(GL_STATIC_DRAW, 7) GLC(GL_FLOAT, 8) GLC(GL_TEXTURE_2D, 9) GLC(GL_RGBA8, 10) GLC(GL_RGBA, 11) GLC(GL_UNSIGNED_BYTE, 12) GLC(GL_LINEAR_MIPMAP_LINEAR, 13)
GLC(GL_LINEAR, 14) GLC(GL_TEXTURE_MIN_FILTER, 15) GLC(GL_TEXTURE_MAG_FILTER, 16) GLC(GL_TEXTURE_WRAP_S, 17) GLC(GL_TEXTURE_WRAP_T, 18) GLC(GL_REPEAT, 19)
GLC(GL_CLAMP_TO_EDGE, 20) GLC(GL_DEPTH_COMPONENT24, 21) GLC(GL_DEPTH_COMPONENT, 22) GLC(GL_UNSIGNED_INT, 23) GLC(GL_TEXTURE_COMPARE_MODE, 24)
GLC(GL_COMPARE_REF_TO_TEXTURE, 25) GLC(GL_TEXTURE_COMPARE_FUNC, 26) GLC(GL_LEQUAL, 27) GLC(GL_FRAMEBUFFER, 28) GLC(GL_DEPTH_ATTACHMENT, 29) GLC(GL_NONE, 30)
GLC(GL_FRAMEBUFFER_COMPLETE, 31) GLC(GL_RENDERBUFFER, 32) GLC(GL_COLOR_ATTACHMENT0, 33) GLC(GL_TRIANGLES, 34) GLC(GL_UNSIGNED_SHORT, 35) GLC(GL_DEPTH_TEST, 36)
GLC(GL_BLEND, 37) GLC(GL_CULL_FACE, 38) GLC(GL_SCISSOR_TEST, 39) GLC(GL_POLYGON_OFFSET_FILL, 40) GLC(GL_DEPTH_BUFFER_BIT, 41) GLC(GL_COLOR_BUFFER_BIT, 42)
GLC(GL_SRC_ALPHA, 43) GLC(GL_ONE_MINUS_SRC_ALPHA, 44) GLC(GL_TRIANGLE_STRIP, 45) GLC(GL_TEXTURE0, 46) GLC(GL_TEXTURE1, 47)
static const GLboolean GL_FALSE = 0, GL_TRUE = 1;
inline int g_gl_calls = 0, g_gl_id = 1;
#define GLF(ret, name, params, body) static inline ret name params { g_gl_calls++; body }
GLF(GLuint, glCreateShader, (GLenum), return (GLuint)g_gl_id++;) GLF(void, glShaderSource, (GLuint, GLsizei, const GLchar* const*, const GLint*), ) GLF(void, glCompileShader, (GLuint), )
GLF(void, glGetShaderiv, (GLuint, GLenum, GLint* p), *p = 1;) GLF(void, glGetShaderInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*), ) GLF(void, glDeleteShader, (GLuint), )
GLF(GLuint, glCreateProgram, (), return (GLuint)g_gl_id++;) GLF(void, glAttachShader, (GLuint, GLuint), ) GLF(void, glLinkProgram, (GLuint), )
GLF(void, glGetProgramiv, (GLuint, GLenum, GLint* p), *p = 1;) GLF(void, glGetProgramInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*), ) GLF(void, glDeleteProgram, (GLuint), )
GLF(GLint, glGetUniformLocation, (GLuint, const GLchar*), return 1;) GLF(void, glGenVertexArrays, (GLsizei, GLuint* a), *a = g_gl_id++;)
GLF(void, glGenBuffers, (GLsizei, GLuint* a), *a = g_gl_id++;) GLF(void, glBindVertexArray, (GLuint), ) GLF(void, glBindBuffer, (GLenum, GLuint), )
GLF(void, glBufferData, (GLenum, GLsizeiptr, const void*, GLenum), ) GLF(void, glEnableVertexAttribArray, (GLuint), )
GLF(void, glVertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*), ) GLF(void, glDeleteVertexArrays, (GLsizei, const GLuint*), )
GLF(void, glDeleteBuffers, (GLsizei, const GLuint*), ) GLF(void, glGenTextures, (GLsizei, GLuint* a), *a = g_gl_id++;) GLF(void, glBindTexture, (GLenum, GLuint), )
GLF(void, glTexImage2D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*), ) GLF(void, glGenerateMipmap, (GLenum), )
GLF(void, glTexParameteri, (GLenum, GLenum, GLint), ) GLF(void, glDeleteTextures, (GLsizei, const GLuint*), ) GLF(void, glGenFramebuffers, (GLsizei, GLuint* a), *a = g_gl_id++;)
GLF(void, glBindFramebuffer, (GLenum, GLuint), ) GLF(void, glFramebufferTexture2D, (GLenum, GLenum, GLenum, GLuint, GLint), ) GLF(void, glDrawBuffers, (GLsizei, const GLenum*), )
GLF(void, glReadBuffer, (GLenum), ) GLF(GLenum, glCheckFramebufferStatus, (GLenum), return GL_FRAMEBUFFER_COMPLETE;) GLF(void, glDeleteFramebuffers, (GLsizei, const GLuint*), )
GLF(void, glGenRenderbuffers, (GLsizei, GLuint* a), *a = g_gl_id++;) GLF(void, glBindRenderbuffer, (GLenum, GLuint), ) GLF(void, glRenderbufferStorage, (GLenum, GLenum, GLsizei, GLsizei), )
GLF(void, glFramebufferRenderbuffer, (GLenum, GLenum, GLenum, GLuint), ) GLF(void, glDeleteRenderbuffers, (GLsizei, const GLuint*), ) GLF(void, glDrawElements, (GLenum, GLsizei, GLenum, const void*), )
GLF(void, glDrawArrays, (GLenum, GLint, GLsizei), ) GLF(void, glUseProgram, (GLuint), ) GLF(void, glViewport, (GLint, GLint, GLsizei, GLsizei), )
GLF(void, glDepthMask, (GLboolean), ) GLF(void, glEnable, (GLenum), ) GLF(void, glDisable, (GLenum), ) GLF(void, glClear, (GLbitfield), ) GLF(void, glPolygonOffset, (GLfloat, GLfloat), )
GLF(void, glDepthFunc, (GLenum), ) GLF(void, glClearColor, (GLfloat, GLfloat, GLfloat, GLfloat), ) GLF(void, glBlendFunc, (GLenum, GLenum), ) GLF(void, glActiveTexture, (GLenum), )
GLF(void, glUniformMatrix4fv, (GLint, GLsizei, GLboolean, const GLfloat*), ) GLF(void, glUniformMatrix3fv, (GLint, GLsizei, GLboolean, const GLfloat*), )
GLF(void, glUniform1f, (GLint, GLfloat), ) GLF(void, glUniform1i, (GLint, GLint), ) GLF(void, glUniform2f, (GLint, GLfloat, GLfloat), ) GLF(void, glUniform3f, (GLint, GLfloat, GLfloat, GLfloat), )
