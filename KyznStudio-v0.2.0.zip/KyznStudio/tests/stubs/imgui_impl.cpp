// Implementasi no-op stub ImGui untuk smoke test headless Editor (BUKAN bagian build Android).
#include "imgui.h"
#include <cstdarg>
namespace ImGui {
static ImGuiIO io; static ImGuiStyle st; static ImDrawList dl;
static struct Init { Init() { io.DisplaySize = ImVec2(1080, 1920); } } init_;
bool Begin(const char*, bool*, ImGuiWindowFlags) { return true; } void End() {}
bool BeginChild(const char*, const ImVec2&, ImGuiChildFlags, ImGuiWindowFlags) { return true; } void EndChild() {}
bool BeginPopup(const char*, ImGuiWindowFlags) { return false; } void EndPopup() {} void OpenPopup(const char*) {}
bool BeginCombo(const char*, const char*, ImGuiComboFlags) { return false; } void EndCombo() {}
bool BeginMainMenuBar() { return true; } void EndMainMenuBar() {} bool BeginMenu(const char*, bool) { return true; } void EndMenu() {}
bool MenuItem(const char*, const char*, bool, bool) { return false; } bool MenuItem(const char*, const char*, bool*, bool) { return false; }
bool BeginTabBar(const char*, int) { return true; } void EndTabBar() {} bool BeginTabItem(const char*, bool*, int) { return true; } void EndTabItem() {}
void BeginGroup() {} void EndGroup() {}
bool Button(const char*, const ImVec2&) { return false; } bool SmallButton(const char*) { return false; } bool InvisibleButton(const char*, const ImVec2&, ImGuiButtonFlags) { return false; }
bool Checkbox(const char*, bool*) { return false; } bool CollapsingHeader(const char*, ImGuiTreeNodeFlags) { return true; }
bool ColorEdit3(const char*, float*, ImGuiColorEditFlags) { return false; } bool Combo(const char*, int*, const char* const*, int, int) { return false; }
bool InputFloat(const char*, float*, float, float, const char*, ImGuiInputTextFlags) { return false; } bool InputFloat3(const char*, float*, const char*, ImGuiInputTextFlags) { return false; }
bool InputInt(const char*, int*, int, int, ImGuiInputTextFlags) { return false; } bool InputText(const char*, char*, size_t, ImGuiInputTextFlags, void*, void*) { return false; }
bool InputTextMultiline(const char*, char*, size_t, const ImVec2&, ImGuiInputTextFlags, void*, void*) { return false; } bool InputTextWithHint(const char*, const char*, char*, size_t, ImGuiInputTextFlags, void*, void*) { return false; }
bool SliderFloat(const char*, float*, float, float, const char*, int) { return false; } bool Selectable(const char*, bool, ImGuiSelectableFlags, const ImVec2&) { return false; }
bool TreeNodeEx(const char*, ImGuiTreeNodeFlags, const char*, ...) { return true; } void TreePop() {}
void Text(const char*, ...) {} void TextDisabled(const char*, ...) {} void TextWrapped(const char*, ...) {} void TextColored(const ImVec4&, const char*, ...) {}
void Image(ImTextureID, const ImVec2&, const ImVec2&, const ImVec2&, const ImVec4&, const ImVec4&) {} bool ImageButton(const char*, ImTextureID, const ImVec2&, const ImVec2&, const ImVec2&, const ImVec4&, const ImVec4&) { return false; }
void Separator() {} void Dummy(const ImVec2&) {} void Indent(float) {} void Unindent(float) {} void SameLine(float, float) {}
void PushID(int) {} void PushID(const char*) {} void PopID() {} void PushStyleColor(ImGuiCol, ImU32) {} void PushStyleColor(ImGuiCol, const ImVec4&) {} void PopStyleColor(int) {}
void PushStyleVar(ImGuiStyleVar, float) {} void PushStyleVar(ImGuiStyleVar, const ImVec2&) {} void PopStyleVar(int) {} void PushTextWrapPos(float) {} void PopTextWrapPos() {}
void SetNextItemWidth(float) {} void SetNextWindowPos(const ImVec2&, ImGuiCond, const ImVec2&) {} void SetNextWindowSize(const ImVec2&, ImGuiCond) {}
void SetCursorPosX(float) {} void SetCursorScreenPos(const ImVec2&) {} float GetCursorPosX() { return 0; } float GetCursorPosY() { return 0; } ImVec2 GetCursorScreenPos() { return ImVec2(0, 100); }
ImVec2 GetContentRegionAvail() { return ImVec2(800, 600); } float GetFrameHeight() { return 40; } float GetWindowHeight() { return 40; } float GetWindowWidth() { return 400; }
float GetScrollY() { return 0; } float GetScrollMaxY() { return 0; } void SetScrollY(float) {} void SetScrollHereY(float) {}
ImDrawList* GetBackgroundDrawList() { return &dl; } ImGuiIO& GetIO() { return io; } ImGuiStyle& GetStyle() { return st; } ImDrawList* GetWindowDrawList() { return &dl; } void StyleColorsDark(ImGuiStyle*) {}
bool IsAnyItemActive() { return false; } bool IsItemActivated() { return false; } bool IsItemActive() { return false; } bool IsItemClicked(ImGuiMouseButton) { return false; } bool IsItemToggledOpen() { return false; }
bool IsMouseClicked(ImGuiMouseButton, bool) { return true; } bool IsMouseDragging(ImGuiMouseButton, float) { return false; } bool IsWindowHovered(ImGuiHoveredFlags) { return false; }
bool BeginDragDropSource(ImGuiDragDropFlags) { return false; } bool SetDragDropPayload(const char*, const void*, size_t, ImGuiCond) { return false; } void EndDragDropSource() {}
bool BeginDragDropTarget() { return false; } const ImGuiPayload* AcceptDragDropPayload(const char*, ImGuiDragDropFlags) { return nullptr; } void EndDragDropTarget() {}
}
