// Stub ImGui (signature v1.90.9) hanya untuk cek sintaks Editor.cpp di PC. BUKAN bagian build Android.
#pragma once
#include <cstddef>
#include <cstdint>
typedef unsigned int ImU32; typedef void* ImTextureID; typedef int ImGuiCol; typedef int ImGuiCond; typedef int ImGuiStyleVar; typedef int ImGuiWindowFlags;
typedef int ImGuiTreeNodeFlags; typedef int ImGuiColorEditFlags; typedef int ImGuiInputTextFlags; typedef int ImGuiSelectableFlags; typedef int ImGuiHoveredFlags;
typedef int ImGuiChildFlags; typedef int ImGuiDragDropFlags; typedef int ImGuiButtonFlags; typedef int ImGuiComboFlags; typedef int ImGuiMouseButton;
struct ImVec2 { float x = 0, y = 0; ImVec2() {} ImVec2(float X, float Y) : x(X), y(Y) {} };
struct ImVec4 { float x = 0, y = 0, z = 0, w = 0; ImVec4() {} ImVec4(float X, float Y, float Z, float W) : x(X), y(Y), z(Z), w(W) {} };
#define IM_COL32(R, G, B, A) (((ImU32)(A) << 24) | ((ImU32)(B) << 16) | ((ImU32)(G) << 8) | (ImU32)(R))
enum { ImGuiCol_Text, ImGuiCol_TextDisabled, ImGuiCol_WindowBg, ImGuiCol_ChildBg, ImGuiCol_PopupBg, ImGuiCol_Border, ImGuiCol_FrameBg, ImGuiCol_FrameBgHovered, ImGuiCol_FrameBgActive,
       ImGuiCol_TitleBg, ImGuiCol_TitleBgActive, ImGuiCol_TitleBgCollapsed, ImGuiCol_MenuBarBg, ImGuiCol_ScrollbarBg, ImGuiCol_ScrollbarGrab, ImGuiCol_CheckMark, ImGuiCol_SliderGrab,
       ImGuiCol_SliderGrabActive, ImGuiCol_Button, ImGuiCol_ButtonHovered, ImGuiCol_ButtonActive, ImGuiCol_Header, ImGuiCol_HeaderHovered, ImGuiCol_HeaderActive, ImGuiCol_Separator,
       ImGuiCol_ResizeGrip, ImGuiCol_ResizeGripHovered, ImGuiCol_ResizeGripActive, ImGuiCol_Tab, ImGuiCol_TabHovered, ImGuiCol_COUNT };
enum { ImGuiStyleVar_WindowPadding = 1, ImGuiStyleVar_WindowRounding, ImGuiStyleVar_WindowBorderSize };
enum { ImGuiCond_FirstUseEver = 4 };
enum { ImGuiWindowFlags_NoScrollbar = 1 << 3, ImGuiWindowFlags_NoMove = 1 << 2, ImGuiWindowFlags_NoScrollWithMouse = 1 << 4, ImGuiWindowFlags_NoSavedSettings = 1 << 8,
       ImGuiWindowFlags_HorizontalScrollbar = 1 << 11, ImGuiWindowFlags_NoBringToFrontOnFocus = 1 << 13, ImGuiWindowFlags_NoDecoration = 43 };
enum { ImGuiTreeNodeFlags_Selected = 1, ImGuiTreeNodeFlags_DefaultOpen = 32, ImGuiTreeNodeFlags_OpenOnArrow = 128, ImGuiTreeNodeFlags_Leaf = 256, ImGuiTreeNodeFlags_SpanAvailWidth = 2048 };
enum { ImGuiColorEditFlags_NoInputs = 1 << 5, ImGuiInputTextFlags_AllowTabInput = 1 << 10, ImGuiSelectableFlags_Disabled = 1 << 3, ImGuiHoveredFlags_ChildWindows = 1, ImGuiChildFlags_Border = 1 };
struct ImGuiPayload { void* Data = nullptr; };
struct ImGuiStyle {
    ImVec2 WindowPadding, FramePadding, ItemSpacing, ItemInnerSpacing, TouchExtraPadding, WindowTitleAlign; ImVec4 Colors[ImGuiCol_COUNT];
    float IndentSpacing = 0, ScrollbarSize = 0, GrabMinSize = 0, WindowRounding = 0, ChildRounding = 0, FrameRounding = 0, PopupRounding = 0, ScrollbarRounding = 0, GrabRounding = 0, TabRounding = 0;
    float WindowBorderSize = 0, FrameBorderSize = 0, PopupBorderSize = 0;
    void ScaleAllSizes(float) {}
};
struct ImGuiIO { ImVec2 MousePos, MouseDelta, DisplaySize; bool ConfigWindowsMoveFromTitleBarOnly = false; const char* IniFilename = nullptr; };
struct ImDrawList {
    void AddLine(const ImVec2&, const ImVec2&, ImU32, float thickness = 1.f) {}
    void AddCircleFilled(const ImVec2&, float, ImU32, int n = 0) {}
    void AddCircle(const ImVec2&, float, ImU32, int n = 0, float th = 1.f) {}
    void AddRectFilled(const ImVec2&, const ImVec2&, ImU32, float r = 0.f, int fl = 0) {}
    void AddText(const ImVec2&, ImU32, const char*, const char* e = nullptr) {}
    void AddImage(ImTextureID, const ImVec2&, const ImVec2&, const ImVec2& a = ImVec2(0, 0), const ImVec2& b = ImVec2(1, 1), ImU32 c = 0xffffffff) {}
};
namespace ImGui {
bool Begin(const char*, bool* p_open = nullptr, ImGuiWindowFlags f = 0); void End();
bool BeginChild(const char*, const ImVec2& s = ImVec2(0, 0), ImGuiChildFlags cf = 0, ImGuiWindowFlags wf = 0); void EndChild();
bool BeginPopup(const char*, ImGuiWindowFlags f = 0); void EndPopup(); void OpenPopup(const char*);
bool BeginCombo(const char*, const char*, ImGuiComboFlags f = 0); void EndCombo();
bool BeginMainMenuBar(); void EndMainMenuBar(); bool BeginMenu(const char*, bool e = true); void EndMenu();
bool MenuItem(const char*, const char* sc = nullptr, bool sel = false, bool en = true); bool MenuItem(const char*, const char*, bool*, bool en = true);
bool BeginTabBar(const char*, int f = 0); void EndTabBar(); bool BeginTabItem(const char*, bool* o = nullptr, int f = 0); void EndTabItem();
void BeginGroup(); void EndGroup();
bool Button(const char*, const ImVec2& s = ImVec2(0, 0)); bool SmallButton(const char*); bool InvisibleButton(const char*, const ImVec2&, ImGuiButtonFlags f = 0);
bool Checkbox(const char*, bool*); bool CollapsingHeader(const char*, ImGuiTreeNodeFlags f = 0);
bool ColorEdit3(const char*, float col[3], ImGuiColorEditFlags f = 0);
bool Combo(const char*, int*, const char* const items[], int n, int h = -1);
bool InputFloat(const char*, float*, float s = 0.f, float sf = 0.f, const char* fmt = "%.3f", ImGuiInputTextFlags f = 0);
bool InputFloat3(const char*, float v[3], const char* fmt = "%.3f", ImGuiInputTextFlags f = 0);
bool InputInt(const char*, int*, int s = 1, int sf = 100, ImGuiInputTextFlags f = 0);
bool InputText(const char*, char*, size_t, ImGuiInputTextFlags f = 0, void* cb = nullptr, void* ud = nullptr);
bool InputTextMultiline(const char*, char*, size_t, const ImVec2& s = ImVec2(0, 0), ImGuiInputTextFlags f = 0, void* cb = nullptr, void* ud = nullptr);
bool InputTextWithHint(const char*, const char*, char*, size_t, ImGuiInputTextFlags f = 0, void* cb = nullptr, void* ud = nullptr);
bool SliderFloat(const char*, float*, float, float, const char* fmt = "%.3f", int f = 0);
bool Selectable(const char*, bool sel = false, ImGuiSelectableFlags f = 0, const ImVec2& s = ImVec2(0, 0));
bool TreeNodeEx(const char*, ImGuiTreeNodeFlags, const char* fmt, ...); void TreePop();
void Text(const char*, ...); void TextDisabled(const char*, ...); void TextWrapped(const char*, ...); void TextColored(const ImVec4&, const char*, ...);
void Image(ImTextureID, const ImVec2&, const ImVec2& a = ImVec2(0, 0), const ImVec2& b = ImVec2(1, 1), const ImVec4& t = ImVec4(1, 1, 1, 1), const ImVec4& bc = ImVec4(0, 0, 0, 0));
bool ImageButton(const char*, ImTextureID, const ImVec2&, const ImVec2& a = ImVec2(0, 0), const ImVec2& b = ImVec2(1, 1), const ImVec4& bg = ImVec4(0, 0, 0, 0), const ImVec4& t = ImVec4(1, 1, 1, 1));
void Separator(); void Dummy(const ImVec2&); void Indent(float w = 0.f); void Unindent(float w = 0.f); void SameLine(float off = 0.f, float sp = -1.f);
void PushID(int); void PushID(const char*); void PopID(); void PushStyleColor(ImGuiCol, ImU32); void PushStyleColor(ImGuiCol, const ImVec4&); void PopStyleColor(int n = 1);
void PushStyleVar(ImGuiStyleVar, float); void PushStyleVar(ImGuiStyleVar, const ImVec2&); void PopStyleVar(int n = 1); void PushTextWrapPos(float w = 0.f); void PopTextWrapPos();
void SetNextItemWidth(float); void SetNextWindowPos(const ImVec2&, ImGuiCond c = 0, const ImVec2& pv = ImVec2(0, 0)); void SetNextWindowSize(const ImVec2&, ImGuiCond c = 0);
void SetCursorPosX(float); void SetCursorScreenPos(const ImVec2&); float GetCursorPosX(); float GetCursorPosY(); ImVec2 GetCursorScreenPos(); ImVec2 GetContentRegionAvail();
float GetFrameHeight(); float GetWindowHeight(); float GetWindowWidth(); float GetScrollY(); float GetScrollMaxY(); void SetScrollY(float); void SetScrollHereY(float r = .5f);
ImDrawList* GetBackgroundDrawList(); ImGuiIO& GetIO(); ImGuiStyle& GetStyle(); ImDrawList* GetWindowDrawList(); void StyleColorsDark(ImGuiStyle* d = nullptr);
bool IsAnyItemActive(); bool IsItemActivated(); bool IsItemActive(); bool IsItemClicked(ImGuiMouseButton b = 0); bool IsItemToggledOpen();
bool IsMouseClicked(ImGuiMouseButton, bool r = false); bool IsMouseDragging(ImGuiMouseButton, float t = -1.f); bool IsWindowHovered(ImGuiHoveredFlags f = 0);
bool BeginDragDropSource(ImGuiDragDropFlags f = 0); bool SetDragDropPayload(const char*, const void*, size_t, ImGuiCond c = 0); void EndDragDropSource();
bool BeginDragDropTarget(); const ImGuiPayload* AcceptDragDropPayload(const char*, ImGuiDragDropFlags f = 0); void EndDragDropTarget();
}
