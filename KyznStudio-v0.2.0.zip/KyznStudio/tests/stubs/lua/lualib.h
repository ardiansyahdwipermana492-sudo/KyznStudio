#pragma once
#include "lua.h"
int luaopen_base(lua_State*); int luaopen_math(lua_State*); int luaopen_string(lua_State*); int luaopen_table(lua_State*);
