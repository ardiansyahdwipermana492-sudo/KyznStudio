// Stub Lua 5.4 (hanya cek sintaks Script.cpp di PC)
#pragma once
#include <cstddef>
typedef struct lua_State lua_State; typedef struct lua_Debug lua_Debug; typedef int (*lua_CFunction)(lua_State*); typedef void (*lua_Hook)(lua_State*, lua_Debug*);
typedef long long lua_Integer; typedef double lua_Number;
#define LUA_OK 0
#define LUA_REGISTRYINDEX (-1001000)
#define LUA_NOREF (-2)
#define LUA_MASKCOUNT 8
#define lua_upvalueindex(i) (LUA_REGISTRYINDEX - (i))
lua_State* luaL_newstate(); void lua_close(lua_State*); int lua_gettop(lua_State*); void lua_settop(lua_State*, int);
#define lua_pop(L, n) lua_settop(L, -(n)-1)
#define lua_newtable(L) lua_createtable(L, 0, 0)
void lua_createtable(lua_State*, int, int); void lua_pushlightuserdata(lua_State*, void*); void lua_pushcclosure(lua_State*, lua_CFunction, int);
void lua_setfield(lua_State*, int, const char*); int lua_getfield(lua_State*, int, const char*); int lua_getglobal(lua_State*, const char*);
void lua_pushinteger(lua_State*, lua_Integer); void lua_pushnumber(lua_State*, lua_Number); void lua_pushnil(lua_State*); void lua_pushvalue(lua_State*, int);
const char* lua_setupvalue(lua_State*, int, int); int lua_pcall(lua_State*, int, int, int);
void* lua_touserdata(lua_State*, int); int lua_isfunction_(lua_State*, int);
#define lua_isfunction(L, n) lua_isfunction_(L, n)
int lua_rawgeti(lua_State*, int, lua_Integer); void lua_sethook(lua_State*, lua_Hook, int, int); const char* lua_tostring_(lua_State*, int);
#define lua_tostring(L, i) lua_tostring_(L, i)
int lua_toboolean(lua_State*, int);
