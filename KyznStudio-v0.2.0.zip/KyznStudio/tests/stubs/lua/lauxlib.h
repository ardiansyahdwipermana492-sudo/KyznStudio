#pragma once
#include "lua.h"
lua_Integer luaL_checkinteger(lua_State*, int); lua_Number luaL_checknumber(lua_State*, int); const char* luaL_checkstring_(lua_State*, int);
#define luaL_checkstring(L, n) luaL_checkstring_(L, n)
const char* luaL_tolstring(lua_State*, int, size_t*); int luaL_error(lua_State*, const char*, ...); int luaL_loadstring(lua_State*, const char*);
int luaL_ref(lua_State*, int); void luaL_unref(lua_State*, int, int); void luaL_requiref(lua_State*, const char*, lua_CFunction, int);
