// Uji unit inti KyznStudio (jalan di PC/CI tanpa Android): g++ -std=c++17 tests/core_test.cpp app/src/main/cpp/core/*.cpp
#include <cstdio>
#include <cstdlib>
#include "../app/src/main/cpp/core/Camera.h"
#include "../app/src/main/cpp/core/Game.h"
#include "../app/src/main/cpp/core/Project.h"
using namespace kyzn;

static int fails = 0, total = 0;
#define CHECK(c) do { total++; if (!(c)) { fails++; std::printf("GAGAL %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)
static bool near(float a, float b, float e = 1e-3f) { return std::fabs(a - b) < e; }

static void testMath() {
    Mat4 m = Mat4::trs({1, 2, 3}, {20, 35, -15}, {2, 1, .5f});
    Mat4 i = m * m.inverse();
    for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) CHECK(near(i.m[c * 4 + r], c == r ? 1.f : 0.f, 1e-4f));
    Vec3 p = m.point({.3f, -.2f, .9f}), q = m.inverse().point(p);
    CHECK(near(q.x, .3f) && near(q.y, -.2f) && near(q.z, .9f));
    Mat4 ry = Mat4::rotY(90); Vec3 d = ry.dir({1, 0, 0});
    CHECK(near(d.x, 0) && near(d.z, -1));                       // rotY(90): +X -> -Z
    float t; Ray r{{0, 0, 10}, {0, 0, -1}};
    CHECK(rayObb(r, Mat4::trs({0, 0, 0}, {0, 45, 0}, {2, 2, 2}), t) && near(t, 10 - std::sqrt(2.f), 1e-2f));
    CHECK(!rayObb(Ray{{5, 0, 10}, {0, 0, -1}}, Mat4::identity(), t));
    Mat4 P = Mat4::perspective(60, 1.5f, .1f, 100); Vec3 clip = P.point({0, 0, -10});
    CHECK(clip.z > -1 && clip.z < 1);
}
static void testJson() {
    Json j; std::string err;
    CHECK(Json::parse("{\"a\":[1,2.5,true,null,\"x\\n\\u0041\"],\"b\":{\"c\":-3e2}}", j, &err));
    CHECK(j["a"].size() == 5 && near((float)j["a"].at(1).num(), 2.5f) && j["a"].at(2).boolean() && j["a"].at(4).str() == "x\nA");
    CHECK(near((float)j["b"]["c"].num(), -300));
    Json k; CHECK(Json::parse(j.dump(), k) && k.dump() == j.dump());
    CHECK(!Json::parse("{\"a\":", k, &err) && !err.empty());
    CHECK(!Json::parse("[1,2", k) && !Json::parse("{} x", k));
}
static void testScene() {
    Scene s;
    int a = s.create(Kind::Block), b = s.create(Kind::Block), c = s.create(Kind::Tree);
    CHECK(s.find(a)->name == "Block" && s.find(b)->name == "Block2" && s.find(c)->name == "Tree");
    s.find(a)->pos = {2, 0, 0}; s.find(b)->pos = {4, 0, 2};
    int g = s.group({a, b, a, 999});
    CHECK(g && s.find(a)->parent == g && near(s.find(g)->pos.x, 3));
    CHECK(near(s.world(a).position().x, 2) && near(s.world(b).position().z, 2));
    s.find(g)->pos.y = 5; CHECK(near(s.world(a).position().y, 5));
    CHECK(!s.setParent(g, a));                                  // siklus ditolak
    int d = s.duplicate(g);
    CHECK(s.childrenOf(d).size() == 2 && s.childrenOf(g).size() == 2);
    s.destroy(g);                                               // group dibubarkan, anak naik, posisi dunia tetap
    CHECK(s.find(a)->parent == 0 && near(s.world(a).position().y, 5) && near(s.world(a).position().x, 2));
    Vec3 mn, mx; CHECK(s.worldBounds(c, mn, mx) && near(mx.y - mn.y, 8));
    int sc = s.create(Kind::Script); s.find(sc)->code = "print('hai')\n\"kutip\""; s.find(sc)->attached = c;
    s.destroy(c); CHECK(s.find(sc)->attached == 0);
    Json j = s.toJson(); Scene t; std::string err;
    CHECK(t.fromJson(j, &err) && t.toJson().dump() == j.dump());
    CHECK(t.find(sc)->code == s.find(sc)->code);
    Json bad = Json::object(); CHECK(!t.fromJson(bad, &err));
    Json j2 = j; Json es = Json::array(); Json e1 = Json::object(); e1.set("id", 1); e1.set("kind", "Nope"); es.push(e1); j2.set("entities", es);
    CHECK(!t.fromJson(j2, &err));
}
static void testHistory() {
    Scene s; History h;
    int a = s.create(Kind::Block);
    h.push(s.toJson().dump()); s.find(a)->pos.x = 10;
    h.push(s.toJson().dump()); s.find(a)->pos.x = 20;
    CHECK(h.undo(s) && near(s.find(a)->pos.x, 10));
    CHECK(h.undo(s) && near(s.find(a)->pos.x, 0));
    CHECK(!h.undo(s));
    CHECK(h.redo(s) && near(s.find(a)->pos.x, 10) && h.redo(s) && near(s.find(a)->pos.x, 20) && !h.redo(s));
    h.undo(s); h.push(s.toJson().dump()); CHECK(h.redoSize() == 0);
}
static void testPhysics() {
    Scene s;
    int fl = s.create(Kind::Floor); s.find(fl)->pos = {0, 1, 0};           // permukaan atas y = 1.25
    int cr = s.create(Kind::Crate); s.find(cr)->pos = {0, 10, 0}; s.find(cr)->rigidbody = true;
    Physics ph;
    for (int i = 0; i < 240; i++) { ph.rebuild(s); ph.stepBodies(s, 1 / 60.f); }
    Vec3 mn, mx; s.worldBounds(cr, mn, mx);
    CHECK(near(mn.y, 1.25f, 1e-2f));
    int w = s.create(Kind::Block); s.find(w)->pos = {3, 2, 0}; s.find(w)->scale = {1, 4, 6};   // dinding tinggi
    ph.rebuild(s); PlayerState p; p.pos = {0, 1.25f, 0};
    for (int i = 0; i < 120; i++) ph.stepPlayer(p, {1, 0, 0}, false, 1 / 60.f);
    CHECK(p.pos.x < 2.1f && p.grounded);                                    // terhalang dinding
    PlayerState q; q.pos = {0, 1.25f, 5};
    for (int i = 0; i < 20; i++) ph.stepPlayer(q, {0, 0, 0}, i == 3, 1 / 60.f);
    CHECK(q.pos.y > 1.25f + .3f);                                           // lompat
    PlayerState f; f.pos = {20, 0, 20};
    for (int i = 0; i < 60; i++) ph.stepPlayer(f, {0, 0, 0}, false, 1 / 60.f);
    CHECK(near(f.pos.y, 0) && f.grounded);                                  // tanah y=0
}
static void testAnim() {
    Scene s; int a = s.create(Kind::Block); Entity* e = s.find(a);
    e->pos = {1, 2, 3}; e->anim = AnimType::Bob; e->animAmount = 2; e->animSpeed = 1; s.beginPlay();
    s.animate(3.14159f / 4, .016f); CHECK(near(e->pos.y, 2 + 2 * std::sin(3.14159f / 2), 1e-3f));
    e->anim = AnimType::Spin; e->rot.y = 0; s.animate(0, .5f); CHECK(near(e->rot.y, 30));
}
static void testProject() {
    CHECK(validPackage("com.kyzn.mygame") && validPackage("a.b") && validPackage("com.k_1.app"));
    CHECK(!validPackage("single") && !validPackage("com..x") && !validPackage("1com.x") && !validPackage("com.x-y") && !validPackage(""));
    Scene s; PublishSettings ps;
    CHECK(hasErrors(validate(s, ps)));                                      // dunia kosong
    s.create(Kind::Block);
    auto v = validate(s, ps); CHECK(!hasErrors(v));                         // hanya peringatan (tanpa Spawn)
    ps.package = "bad"; ps.versionCode = 0; ps.minSdk = 30; ps.targetSdk = 28;
    int errs = 0; for (auto& i : validate(s, ps)) errs += i.error; CHECK(errs == 3);
    ps = PublishSettings(); ps.format = "aab"; bool w = false; for (auto& i : validate(s, ps)) if (!i.error && i.text.find("AAB") != std::string::npos) w = true; CHECK(w);
    PublishSettings r = PublishSettings::fromJson(ps.toJson()); CHECK(r.package == ps.package && r.format == "aab" && r.versionCode == 1);
    std::vector<std::string> out; std::string err;
    CHECK(exportGame(s, ps, "/tmp/kyzn_export_test/a/b", out, err) && out.size() == 2);
    std::string txt; CHECK(readFile(out[0], txt)); Json j; Scene t; CHECK(Json::parse(txt, j) && t.fromJson(j) && t.entities.size() == 1);
}
static void testGame() {
    Scene s;
    int fl = s.create(Kind::Floor); s.find(fl)->pos = {0, -.25f, 0};
    int sp = s.create(Kind::Spawn); s.find(sp)->pos = {5, .2f, 5};
    int sp2 = s.create(Kind::Block); s.find(sp2)->anim = AnimType::Spin;
    std::vector<std::string> logs; GameSession g;
    g.start(s, [&](const std::string& m) { logs.push_back(m); }, [&](const std::string& m) { logs.push_back("sfx " + m); });
    CHECK(near(g.player.pos.x, 5) && near(g.player.pos.z, 5) && near(g.player.pos.y, .4f));
    g.yaw = 0;                                                              // kamera di +Z menghadap -Z
    for (int i = 0; i < 60; i++) g.update(s, 1 / 60.f, {{0, 1}, false});    // maju = -Z
    CHECK(g.player.pos.z < 5 - 5 && std::fabs(g.player.pos.x - 5) < .01f);
    float x0 = g.player.pos.x;
    for (int i = 0; i < 30; i++) g.update(s, 1 / 60.f, {{1, 0}, false});    // kanan = +X
    CHECK(g.player.pos.x > x0 + 2);
    CamPose c = g.camera(); CHECK(c.eye.z > c.target.z && c.eye.y > c.target.y);
    CHECK(s.find(sp2)->rot.y > 0);
    g.stop(); CHECK(!g.running());
}

static void testCamera() {
    OrbitCamera oc; oc.yaw = 1.1f; oc.pitch = .5f; oc.dist = 30; oc.target = {4, 1, -3};
    Camera c = oc.toCamera();
    CHECK(near(length(c.eye - c.target), 30, 1e-2f));
    float aspect = 1.6f; Vec2 sp;
    Vec3 p = c.target + Vec3(1.5f, .5f, -2);
    CHECK(projectToScreen(c.viewProj(aspect), p, 800, 500, sp));
    Ray r = c.ray(aspect, sp.x / 800 * 2 - 1, 1 - sp.y / 500 * 2);              // ray dari piksel harus melewati p
    float t = dot(p - r.o, r.d); Vec3 closest = r.o + r.d * t;
    CHECK(length(closest - p) < 5e-2f);
    CHECK(!projectToScreen(c.viewProj(aspect), c.eye - (c.target - c.eye), 800, 500, sp));   // di belakang kamera
    Vec3 f = oc.forwardXZ(), rt = oc.rightXZ(); CHECK(near(dot(f, rt), 0) && near(cross(rt, f).y, 1));   // kanan x maju = atas
    Vec3 t0 = oc.target; oc.pan(100, 0); CHECK(dot(oc.target - t0, rt) < 0);
}

int main() {
    testCamera(); testMath(); testJson(); testScene(); testHistory(); testPhysics(); testAnim(); testProject(); testGame();
    std::printf("%d/%d pengecekan lulus, %d gagal\n", total - fails, total, fails);
    return fails ? 1 : 0;
}
