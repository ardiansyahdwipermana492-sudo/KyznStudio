// Smoke test Editor headless (stub ImGui + stub GL): muat scene, jalankan banyak frame, simpan/muat ulang. Menangkap crash/ASan.
#include <cstdio>
#include "../app/src/main/cpp/editor/Editor.h"
using namespace kyzn;
int main() {
    Platform pf; pf.dataDir = "/tmp/kyzn_editor_smoke"; pf.ui = 2.f;
    makeDirs(pf.dataDir);
    Scene s;
    int a = s.create(Kind::Block), b = s.create(Kind::Tree), c = s.create(Kind::Container); s.create(Kind::Spawn);
    s.group({a, b}); int sc = s.create(Kind::Script); s.find(sc)->code = "function onUpdate(dt) end"; s.find(sc)->attached = c;
    s.find(c)->anim = AnimType::Spin; s.find(c)->tex = 2; s.find(c)->transparency = .3f;
    Json j = Json::object(); j.set("scene", s.toJson()); j.set("publish", PublishSettings().toJson());
    writeFile(pf.dataDir + "/autosave.kyzn.json", j.dump());
    Renderer r; r.init();
    Editor ed(pf); ed.style(); ed.attach(&r);
    if (!ed.load(pf.dataDir + "/autosave.kyzn.json")) { std::printf("load gagal\n"); return 1; }
    Touch t; t.count = 2; t.x[0] = 100; t.y[0] = 100; t.x[1] = 300; t.y[1] = 120;
    for (int i = 0; i < 120; i++) { t.x[1] += 1; ed.frame(1.f / 60.f, t, 1080, 1920); }
    t.count = 0; for (int i = 0; i < 30; i++) ed.frame(1.f / 60.f, t, 720, 1280);
    ed.autosave(); ed.log("tes");
    if (!ed.load(pf.dataDir + "/autosave.kyzn.json")) { std::printf("muat ulang gagal\n"); return 2; }
    ed.releaseGL(); r.shutdown();
    std::printf("editor smoke ok\n");
    return 0;
}
