#!/usr/bin/env bash
# Menjalankan semua tes yang tidak butuh Android: inti C++ (+ smoke test renderer dengan stub GL).
set -euo pipefail
cd "$(dirname "$0")/.."
CORE=app/src/main/cpp/core
g++ -std=c++17 -Wall -Wextra -O1 -fsanitize=address,undefined -g tests/core_test.cpp $CORE/*.cpp -o /tmp/kyzn_core_test
/tmp/kyzn_core_test
g++ -std=c++17 -Wall -Wextra -Itests/stubs -fsanitize=address,undefined -g tests/render_smoke.cpp app/src/main/cpp/render/Renderer.cpp $CORE/Scene.cpp -o /tmp/kyzn_render_smoke
/tmp/kyzn_render_smoke
g++ -std=c++17 -Wall -Wextra -Wno-unused-parameter -Itests/stubs -Iapp/src/main/cpp/editor -fsanitize=address,undefined -g tests/editor_smoke.cpp tests/stubs/imgui_impl.cpp app/src/main/cpp/editor/Editor.cpp app/src/main/cpp/render/Renderer.cpp $CORE/*.cpp -o /tmp/kyzn_editor_smoke_bin
/tmp/kyzn_editor_smoke_bin
