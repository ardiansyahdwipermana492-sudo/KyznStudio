// Smoke test renderer dengan GL stub: memastikan alur init/render/resize tidak crash dan jumlah draw masuk akal.
#include <cstdio>
#include "../app/src/main/cpp/render/Renderer.h"
using namespace kyzn;
int main() {
    Renderer r; RenderTarget rt;
    if (!r.init()) { std::printf("init gagal: %s\n", r.error().c_str()); return 1; }
    if (!rt.resize(640, 360)) return 2;
    Scene s; s.create(Kind::Tree); s.create(Kind::House); s.create(Kind::Container); int b = s.create(Kind::Block); s.find(b)->transparency = .5f;
    s.find(b)->tex = 2; s.create(Kind::Script);
    Camera c; RenderOpts o; o.player = true;
    int before = g_gl_calls; r.render(s, c, rt, o);
    std::printf("render ok, panggilan GL: %d, texture container=%u\n", g_gl_calls - before, r.textureId(4));
    s.lighting.shadows = false; o.grid = false; r.render(s, c, rt, o);
    rt.resize(1280, 720); rt.destroy(); r.shutdown();
    return 0;
}
