Folder ini diisi hasil export editor: main.scene.json dan publish.json.
Workflow "Publish Game" membaca kedua file ini lalu membangun APK/AAB game.
